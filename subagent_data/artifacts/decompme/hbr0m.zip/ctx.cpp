/* "src\kart\KartState.cpp" line 0 "rk_types.h" */
#pragma once

/* "include\rk_types.h" line 2 "stdint.h" */
#pragma once

typedef unsigned long long uint64_t;
typedef signed long long int64_t;

typedef unsigned long uint32_t;
typedef signed long int32_t;

typedef unsigned short uint16_t;
typedef signed short int16_t;

typedef unsigned char uint8_t;
typedef signed char int8_t;
/* end "stdint.h" */
/* "include\rk_types.h" line 3 "stddef.h" */
#pragma once

#ifdef __INTELLISENSE__
#define offsetof(type, m) __builtin_offsetof(type,m)
#else
#define offsetof(type, m) ((size_t) & (((type*)0)->m))
#endif

#ifndef NULL
#define NULL 0
#endif

#ifndef SIZE_T_DEFINE
#define SIZE_T_DEFINE
typedef unsigned long size_t;
#endif
/* end "stddef.h" */
/* "include\rk_types.h" line 4 "macros.h" */
#pragma once

#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define MIN(x, y) ((x) < (y) ? (x) : (y))

#define CLAMP(low, high, x)                                                    \
    ((x) > (high) ? (high) : ((x) < (low) ? (low) : (x)))

#define ROUND_UP(x, align) (((x) + (align) - 1) & (-(align)))
#define ROUND_UP_PTR(x, align)                                                 \
    ((void*)((((u32)(x)) + (align) - 1) & (~((align) - 1))))

#define ROUND_DOWN(x, align) ((x) & (-(align)))
#define ROUND_DOWN_PTR(x, align) ((void*)(((u32)(x)) & (~((align) - 1))))

#define ARRAY_SIZE(x) (sizeof((x)) / sizeof((x)[0]))

#define MEMCLR(x) __memclr((x), sizeof(*(x)))

#define ALIGN(x) __attribute__((aligned(x)))

#define DECL_SECTION(x) __declspec(section x)
#define DECL_WEAK __declspec(weak)

#define DECLTYPE(x) __decltype__(x)

// https://github.com/DarkRTA/rb3/blob/235050f88a263fec0387b7c618dda76a8bb24d2c/src/sdk/RVL_SDK/revolution/os/OSUtils.h#L13-L17
#if defined(__CWCC__) && !defined(__INTELLISENSE__)
#define AT_ADDRESS(addr) : (addr)
#else
#define AT_ADDRESS(addr)
#endif

// For VSCode
#ifdef __INTELLISENSE__
#define asm
#define __attribute__(x)
#define __declspec(x)
#endif
/* end "macros.h" */

//! Describes an unknown 32 bit value
typedef int unk32;
//! Describes an unknown 16 bit value
typedef short unk16;
//! Describes an unknown 8 bit value
typedef unsigned char unk8;
//! Unknown value of unknown size
typedef unk32 unk;

// Necesary for CW
#if __cplusplus < 201103L && !defined(_WIN32)
#define override
#define noexcept
#define nullptr NULL
#endif

#define ensures(cond)
#define expects(cond)

#ifdef __CWCC__
#define MWREG register
#define CONST_MWREG register

#define WPOPT volatile
#define MW_PRAG_NOINLINE _Pragma("push") _Pragma("dont_inline on")
#define MW_PRAG_OPT_S _Pragma("push") _Pragma("optimize_for_size on")
#define MW_PRAG_NO_WARN_10216 _Pragma("push") _Pragma("warning off(10216)")
#define MW_PRAG_PACKED _Pragma("push") _Pragma("options align=packed")

#define MW_PRAG_END _Pragma("pop")
#define DECOMP // TODO: Move to build

#define FORCE_INLINE __inline
#define NEVER_INLINE __attribute__((never_inline))

#else
#define MWREG
#define CONST_MWREG const
#define MW_PRAG_NOINLINE
#define MW_PRAG_END
#define MW_PRAG_OPT_S
#define MW_PRAG_PACKED
#define MW_PRAG_NO_WARN_10216

#define FORCE_INLINE __forceinline
#define NEVER_INLINE
#endif

// A function that does nothing
#define NULLSUB void

// We know it's release stripped usually from context. i.e. allocated on debug
// heap
#define RELEASE_STRIPPED_ALL NULLSUB

#define UNUSED_PARAM(x) (void)(x); // EPPC:#pragma unused
#define UNUSED

#ifdef DECOMP

#define LOCALREF(key, type, data, ref) extern type key;
#else
#define LINKED_ELSEWHERE

#define LOCALREF(key, type, data, ref) type key = data;
#endif

// Standard types
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;

typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;

enum { FALSE, TRUE };
typedef int BOOL;

#ifdef __cplusplus
#define restrict

class NonCopyable {
public:
  inline NonCopyable() {}

private:
  inline NonCopyable(const NonCopyable&) {}
};


// Main static assert macro
#if defined(__INTELLISENSE__)
  #if !__has_extension(c_static_assert)
    #error "language server lacks `_Static_assert` support"
  #endif
  #define static_assert(cond) \
    _Pragma("clang diagnostic push") \
    _Pragma("clang diagnostic ignored \"-Wc++17-extensions\"") \
    _Static_assert(cond) \
    _Pragma("clang diagnostic pop")
#else
  #define STATIC_ASSERT_CONCAT(a, b) a##b
  #define STATIC_ASSERT_MAKE_NAME(line) STATIC_ASSERT_CONCAT(static_assertion_failed_at_line_, line)
  #define static_assert(cond) \
      typedef char STATIC_ASSERT_MAKE_NAME(__LINE__)[(cond) ? 1 : -1]
#endif

#endif // __cplusplus

#define INLINE_ELSEWHERE(x)

inline u32 min32(u32 a, u32 b) { return a <= b ? a : b; }
/* end "rk_types.h" */
/* "src\kart\KartState.cpp" line 1 "decomp.h" */
#pragma once

/* "include\decomp.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

typedef struct ps_f32 {
  f32 f0;
  f32 f1;
} ps_f32;

#ifdef __CWCC__

#pragma section RW "flow_check"
#define SECTION_FLOW_CHECK __declspec(section "flow_check")
#define MARK_FLOW_CHECK(start)                                                 \
  SECTION_FLOW_CHECK u32 __flow_check_##start = start             \
      __attribute__((force_export))


#define sdata_ps_f32 __declspec(section ".sdata") ps_f32
#define sdata2_ps_f32 __declspec(section ".sdata2") const ps_f32

#pragma section "garbage"
#define SECTION_GARBAGE
#define static_order_hints                                                     \
  SECTION_GARBAGE static void __garbage_ordering_hints(void)
#define order_hint_access(var) (void)(var)

#elif defined (__INTELLISENSE__)

#define sdata_ps_f32 ps_f32
#define sdata2_ps_f32 ps_f32

#define SECTION_FLOW_CHECK
#define MARK_FLOW_CHECK(start)
#define SECTION_GARBAGE
#define static_order_hints
#define order_hint_access(var) (void)(var)

#endif

#ifdef __clang__
#define __cntlzw(x) __builtin_clz(x)
#endif
/* end "decomp.h" */

/* "src\kart\KartState.cpp" line 3 "KartState.hpp" */
#pragma once

/* "src\kart\KartState.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartState.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartState.hpp" line 6 "kart/KartObjectProxy.hpp" */
#pragma once

/* "src\kart\KartObjectProxy.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartObjectProxy.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartObjectProxy.hpp" line 6 "egg/math/eggVector.hpp" */
/*!
 * @file
 * @brief TODO
 */

#pragma once

/* "lib\egg\math\eggVector.hpp" line 7 "float.h" */
#pragma once

#define FLT_EPSILON (1.0f / 8388608.0f)
#define FLT_MIN 1.175494351e-38F
/* end "float.h" */

/* "lib\egg\math\eggVector.hpp" line 9 "egg/math/eggMath.hpp" */
/*!
 * @file
 * @brief Provides a compile-time generic interface for performing basic math
 * operations on a certain type.
 */

#pragma once

/* "lib\egg\math\eggMath.hpp" line 8 "rk_types.h" */
/* end "rk_types.h" */
/* "lib\egg\math\eggMath.hpp" line 9 "math.h" */
#pragma once

/* "lib\MSL\include\math.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

#ifdef __cplusplus
extern "C" {
#endif

#define INFINITY 1.0f/0.0f

MW_PRAG_NO_WARN_10216

f64 sin(f64);
inline f32 sinf(f32 x) { return (float)sin(x); }

f64 cos(f64);
inline f32 cosf(f32 x) { return (float)cos(x); }

f64 tan(f64);
inline f32 tanf(f32 x) { return (float)tan(x); }

f64 sqrt(f64);
inline f32 sqrtf(f32 x) { return (f32)sqrt(x); }

f64 acos(f64);
inline f32 acosf(f32 x) { return (f32)acos(x); }

#ifdef __INTELLISENSE__
#define __fabsf(x) x
#define __fabs(x) x
#endif

f32 fabsf(f32);
inline f32 fabsf(f32 x) { return __fabsf(x); }
f64 fabs(f64);
inline f64 fabs(f64 x) { return __fabs(x); }

double frexp(double x, int* eptr);
double ldexp(double x, int exp);

double pow(double x, double y);

double copysign(double x, double y);

int __fpclassifyf(float);
int __fpclassifyd(double);
int __signbitd(double);

int isfinite(f32 x);
inline int isfinite(f32 x) { f32 inf = INFINITY; return inf != x; }
int isinf(f32 x);
inline int isinf(f32 x) { return !isfinite(x); }

MW_PRAG_END

#ifdef __cplusplus
} // extern "C"
#endif
/* end "math.h" */

#define DEG2RAD(X) 0.017453292f * X
//#define RAD2DEG(X) 57.2957795131f * X

namespace EGG {

#if 0
template <typename T> struct Math {
  static T sqrt(T);
  static T frsqrt(T);

  static T sin(T radians);
  static T cos(T radians);
  static T tan(T radians);
  static T asin(T radians);
  static T acos(T radians);
  static T atan2(T num, T denom);
};

typedef Math<float> Mathf;
#endif

namespace Mathf {
float sqrt(float);
float frsqrt(float);

inline f32 abs(f32 t) { return t > (f32)0 ? t : -t;}

float sin(float);
float cos(float);
float tan(float);
float asin(float);
float acos(float);
float atan2(float, float);

inline bool isNonNegative(f32 x) {return x > -FLT_MIN;}
} // namespace Mathf

} // namespace EGG
/* end "egg/math/eggMath.hpp" */
/* "lib\egg\math\eggVector.hpp" line 10 "nw4r/math/mathTypes.hpp" */
#pragma once

/* "lib\nw4r\math\mathTypes.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\nw4r\math\mathTypes.hpp" line 4 "rvl/mtx/mtx.h" */
#pragma once

/* "lib\rvl\mtx\mtx.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef GEKKO
#define MTX_USE_C
#undef  MTX_USE_PS
#endif

#if ( !defined(MTX_USE_PS) && !defined(MTX_USE_C) )
#ifndef _DEBUG
#define MTX_USE_PS
#endif
#endif

typedef struct {
  f32 x, y, z;
} Vec;

typedef struct {
  f32 x, y;
} Vec2;

typedef f32 Mtx[3][4];
typedef f32 (*MtxPtr)[4];

typedef f32 Mtx44[4][4];
typedef f32 (*Mtx44Ptr)[4];

typedef struct {
  f32 x, y, z, w;
} Quaternion;

// rvlMtx.c
void PSMTXIdentity(Mtx);
void PSMTXCopy(const Mtx, Mtx);
void PSMTXConcat(const Mtx, const Mtx, Mtx);
void PSMTXConcatArray(const Mtx, const Mtx*, Mtx*, u32);
u32 PSMTXInverse(const Mtx, Mtx);
u32 PSMTXInvXpose(const Mtx, Mtx);
void PSMTXRotRad(Mtx, char, f32);
void PSMTXRotTrig(Mtx, char, f32, f32);
void __PSMTXRotAxisRadInternal(Mtx, const Vec*, f32, f32);
void PSMTXRotAxisRad(Mtx, const Vec*, f32);
void PSMTXTrans(Mtx, f32, f32, f32);
void PSMTXTransApply(const Mtx, Mtx, f32, f32, f32);
void PSMTXScale(Mtx, f32, f32, f32);
void PSMTXScaleApply(const Mtx, Mtx, f32, f32, f32);
void PSMTXQuat(Mtx m, const Quaternion*);
void C_MTXLookAt(Mtx, const Vec*, const Vec*, const Vec*);
void C_MTXLightFrustum(Mtx, f32, f32, f32, f32, f32, f32, f32, f32, f32);
void C_MTXLightPerspective(Mtx, f32, f32, f32, f32, f32, f32);
void C_MTXLightOrtho(Mtx, f32, f32, f32, f32, f32, f32, f32, f32);
// not present in mkw
void C_MTXMultVec(const Mtx, const Vec*, Vec*);
void PSMTXMultVec(const Mtx, const Vec*, Vec*);
// not present in mkw
void C_MTXMultVecSR(const Mtx, const Vec*, Vec*);
void PSMTXMultVecSR(const Mtx, const Vec*, Vec*);

#ifdef MTX_USE_PS
#define MTXIdentity             PSMTXIdentity
#define MTXCopy                 PSMTXCopy
#define MTXConcat               PSMTXConcat
#define MTXConcatArray          PSMTXConcatArray
#define MTXTranspose            PSMTXTranspose
#define MTXInverse              PSMTXInverse
#define MTXInvXpose             PSMTXInvXpose
#else // MTX_USE_C
#define MTXIdentity             C_MTXIdentity
#define MTXCopy                 C_MTXCopy
#define MTXConcat               C_MTXConcat
#define MTXConcatArray          C_MTXConcatArray
#define MTXTranspose            C_MTXTranspose
#define MTXInverse              C_MTXInverse
#define MTXInvXpose             C_MTXInvXpose
#endif

#ifdef MTX_USE_PS
#define MTXMultVec              PSMTXMultVec
#define MTXMultVecArray         PSMTXMultVecArray
#define MTXMultVecSR            PSMTXMultVecSR
#define MTXMultVecArraySR       PSMTXMultVecArraySR
#else // MTX_USE_C
#define MTXMultVec              C_MTXMultVec
#define MTXMultVecArray         C_MTXMultVecArray
#define MTXMultVecSR            C_MTXMultVecSR
#define MTXMultVecArraySR       C_MTXMultVecArraySR
#endif

// rvlMtx2.c
void C_MTXFrustum(Mtx44, f32, f32, f32, f32, f32, f32);
void C_MTXPerspective(Mtx44, f32, f32, f32, f32);
void C_MTXOrtho(Mtx44, f32, f32, f32, f32, f32, f32);

#define MTXFrustum              C_MTXFrustum
#define MTXPerspective          C_MTXPerspective
#define MTXOrtho                C_MTXOrtho

// rvlVec.c
void PSVECAdd(const Vec*, const Vec*, Vec*);
void PSVECScale(const Vec*, Vec*, f32);
void PSVECNormalize(const Vec*, Vec*);
f32 PSVECMag(const Vec*);
f32 PSVECDotProduct(const Vec*, const Vec*);
void C_VECCrossProduct(const Vec*, const Vec*, Vec*);
void PSVECCrossProduct(const Vec*, const Vec*, Vec*);
void C_VECHalfAngle(const Vec*, const Vec*, Vec*);
f32 PSVECSquareDistance(const Vec*, const Vec*);

#ifdef MTX_USE_PS
#define VECAdd                  PSVECAdd
#define VECSubtract             PSVECSubtract
#define VECScale                PSVECScale
#define VECNormalize            PSVECNormalize
#define VECSquareMag            PSVECSquareMag
#define VECMag                  PSVECMag
#define VECDotProduct           PSVECDotProduct
#define VECCrossProduct         PSVECCrossProduct
#define VECSquareDistance       PSVECSquareDistance
#define VECDistance             PSVECDistance
#else // MTX_USE_C
#define VECAdd                  C_VECAdd
#define VECSubtract             C_VECSubtract
#define VECScale                C_VECScale
#define VECNormalize            C_VECNormalize
#define VECSquareMag            C_VECSquareMag
#define VECMag                  C_VECMag
#define VECDotProduct           C_VECDotProduct
#define VECCrossProduct         C_VECCrossProduct
#define VECSquareDistance       C_VECSquareDistance
#define VECDistance             C_VECDistance
#endif

#define VECReflect              C_VECReflect
#define VECHalfAngle            C_VECHalfAngle

// rvlQuat.c
void PSQUATMultiply(const Quaternion*, const Quaternion*, Quaternion*);
void PSQUATScale(const Quaternion*, Quaternion*, f32);
f32 PSQUATDotProduct(const Quaternion*, const Quaternion*);
void PSQUATNormalize(const Quaternion*, Quaternion*);
void PSQUATInverse(const Quaternion*, Quaternion*);
void C_QUATMtx(Quaternion*, const Mtx);
void C_QUATLerp(const Quaternion*, const Quaternion*, Quaternion*, f32);
void C_QUATSlerp(const Quaternion*, const Quaternion*, Quaternion*, f32);

#ifdef MTX_USE_PS
#define QUATAdd                 PSQUATAdd
#define QUATSubtract            PSQUATSubtract
#define QUATMultiply            PSQUATMultiply
#define QUATDivide              PSQUATDivide
#define QUATScale               PSQUATScale
#define QUATDotProduct          PSQUATDotProduct
#define QUATNormalize           PSQUATNormalize
#define QUATInverse             PSQUATInverse
#else // MTX_USE_C
#define QUATAdd                 C_QUATAdd
#define QUATSubtract            C_QUATSubtract
#define QUATMultiply            C_QUATMultiply
#define QUATDivide              C_QUATDivide
#define QUATScale               C_QUATScale
#define QUATDotProduct          C_QUATDotProduct
#define QUATNormalize           C_QUATNormalize
#define QUATInverse             C_QUATInverse
#endif

#define QUATExp                 C_QUATExp
#define QUATLogN                C_QUATLogN
#define QUATMakeClosest         C_QUATMakeClosest
#define QUATRotAxisRad          C_QUATRotAxisRad
#define QUATMtx                 C_QUATMtx
#define QUATLerp                C_QUATLerp
#define QUATSlerp               C_QUATSlerp
#define QUATSquad               C_QUATSquad
#define QUATCompA               C_QUATCompA

#ifdef __cplusplus
}
#endif
/* end "rvl/mtx/mtx.h" */

/* "lib\nw4r\math\mathTypes.hpp" line 6 "nw4r/math/config.h" */

#pragma once

#ifdef GEKKO
  #define NW4R_MATH_BROADWAY
#endif
/* end "nw4r/math/config.h" */

namespace nw4r {
namespace math {

struct _VEC2 {
  f32 x;
  f32 y;
};

struct _VEC3 {
  f32 x;
  f32 y;
  f32 z;
};

struct __MTX33 {
  f32 _00, _01, _02;
  f32 _10, _11, _12;
  f32 _20, _21, _22;
};

struct _MTX33 {
  union {
    struct __MTX33 e;
    f32 arr[9];
    f32 mtx[3][3];
  };
};

struct __MTX34 {
  f32 _00, _01, _02, _03;
  f32 _10, _11, _12, _13;
  f32 _20, _21, _22, _23;
};

struct _MTX34 {
  union {
    struct __MTX34 e;
    f32 arr[12];
    f32 mtx[3][4];
  };
};

struct _MTX44 {
  f32 arr[16];
};

// forward decls
struct VEC2;
struct VEC3;
struct MTX34;
struct MTX44;

struct VEC3 : public _VEC3 {
public:
  typedef VEC3 self_type;
  typedef f32  value_type;

  VEC3() {}
  VEC3(const f32* p) { x = p[0]; y = p[1]; z = p[2]; }
  VEC3(f32 fx, f32 fy, f32 fz) { x = fx; y = fy; z = fz; }
  VEC3(const _VEC3& v) { x = v.x; y = v.y; z = v.z; }
  VEC3(const Vec& v) { x = v.x; y = v.y; z = v.z; }

  operator f32*() { return &x; }
  operator const f32*() const { return &x; }

  operator Vec*() { return (Vec*)&x; }
  operator const Vec*() const { return (const Vec*)&x; }

  self_type& operator+=(const self_type& rhs);
  self_type& operator-=(const self_type& rhs);
  self_type& operator*=(f32 f);
  self_type& operator/=(f32 f) { return operator*=(1.f / f); }

  self_type operator+() const { return *this; }
  self_type operator-() const { return self_type(-x, -y, -z); }

  // The optimal implementation of binary operators depends on whether the return value is optimized.
  self_type operator+(const self_type& rhs) const;
  self_type operator-(const self_type& rhs) const;
  self_type operator*(f32 f) const;
  self_type operator/(f32 f) const { f32 r = 1.f / f; return operator*(r); }

  bool operator==(const VEC3& o) const {
    return x == o.x && y == o.y && z == o.z;
  }
  bool operator!=(const VEC3& o) const {
    return x != o.x || y != o.y || z != o.z;
  }
};

struct VEC2 : public _VEC2 {
  bool operator==(const VEC3& o) const { return x == o.x && y == o.y; }
  bool operator!=(const VEC3& o) const { return x != o.x || y != o.y; }
};

class MTX33 : public _MTX33 {
public:
  MTX33() {}
  MTX33(const f32* p);
  MTX33(const MTX34& rhs);
  MTX33(f32 x00, f32 x01, f32 x02, f32 x10, f32 x11, f32 x12, f32 x20, f32 x21,
        f32 x22) {
    e._00 = x00;
    e._01 = x01;
    e._02 = x02;
    e._10 = x10;
    e._11 = x11;
    e._12 = x12;
    e._20 = x20;
    e._21 = x21;
    e._22 = x22;
  }

  operator f32*() { return &e._00; }
  operator const f32*() const { return &e._00; }
};

struct MTX34 : public _MTX34 {
public:
  typedef f32 (*MtxPtr)[4];
  typedef const f32 (*ConstMtxPtr)[4];

public:
  MTX34() {}

  operator f32*() { return &e._00; }
  operator const f32*() const { return &e._00; }

  operator MtxPtr() { return (MtxPtr)&e._00; }
  operator ConstMtxPtr() const { return (ConstMtxPtr)&e._00; }
};

struct MTX44 : public _MTX44 {
public:
  typedef f32 (*Mtx44Ptr)[4];
  typedef const f32 (*ConstMtx44Ptr)[4];

public:
  MTX44() {}

  operator f32*() { return &arr[0]; }
  operator const f32*() const { return &arr[0]; }

  operator Mtx44Ptr() { return (Mtx44Ptr)&arr[0]; }
  operator ConstMtx44Ptr() const { return (ConstMtx44Ptr)&arr[0]; }
};

inline VEC3* VEC3Add(register VEC3* pOut, const register VEC3* p1, const register VEC3* p2)
{
#if defined(NW4R_MATH_BROADWAY)
    register f32 a, b, c;
    asm
    {
        psq_l a, 0(p1), 0, 0;
        psq_l b, 0(p2), 0, 0;
        ps_add c, a, b;
        psq_st c, 0(pOut), 0, 0;

        psq_l a, 8(p1), 1, 0;
        psq_l b, 8(p2), 1, 0;
        ps_add c, a, b;
        psq_st c, 8(pOut), 1, 0;
    }
#else
    pOut->x = p1->x + p2->x;
    pOut->y = p1->y + p2->y;
    pOut->z = p1->z + p2->z;
#endif
    return pOut;
}

inline VEC3* VEC3Sub(register VEC3* pOut, const register VEC3* p1, const register VEC3* p2)
{
#if defined(NW4R_MATH_BROADWAY)
    register f32 a, b, c;
    asm
    {
        psq_l a, 0(p1), 0, 0;
        psq_l b, 0(p2), 0, 0;
        ps_sub c, a, b;
        psq_st c, 0(pOut), 0, 0;

        psq_l a, 8(p1), 1, 0;
        psq_l b, 8(p2), 1, 0;
        ps_sub c, a, b;
        psq_st c, 8(pOut), 1, 0;
    }
#else
    pOut->x = p1->x - p2->x;
    pOut->y = p1->y - p2->y;
    pOut->z = p1->z - p2->z;
#endif
    return pOut;
}

inline VEC3* VEC3Scale(register VEC3* pOut, const register VEC3* p, register f32 scale)
{
#if defined(NW4R_MATH_BROADWAY)
    register f32 a, b;
    asm
    {
        psq_l    a, 0(p), 0, 0;
        ps_muls0 b, a, scale;
        psq_st   b, 0(pOut), 0, 0;

        psq_l    a, 8(p), 1, 0;
        ps_muls0 b, a, scale;
        psq_st   b, 8(pOut), 1, 0;
    }
#else
    pOut->x = p->x * scale;
    pOut->y = p->y * scale;
    pOut->z = p->z * scale;
#endif
    return pOut;
}

inline f32 VEC3Dot(const register VEC3* p1, const register VEC3* p2)
{
#if defined(NW4R_MATH_BROADWAY)
    register f32 _v1, _v2, _v3, _v4, _v5;
    asm
    {
        psq_l   _v2, 4(p1), 0, 0;
        psq_l   _v3, 4(p2), 0, 0;
        ps_mul  _v2, _v2, _v3;

        psq_l   _v5, 0(p1), 1, 0;
        psq_l   _v4, 0(p2), 1, 0;

        ps_madd _v3, _v5, _v4, _v2;
        ps_sum0 _v1, _v3, _v2, _v2;
    }
    return _v1;
#else
    return p1->x * p2->x + p1->y * p2->y + p1->z * p2->z;
#endif
}

inline f32 VEC3LenSq(const register VEC3* p)
{
#if defined(NW4R_MATH_BROADWAY)
    register f32 vxy, vzz, sqmag;

    asm
    {
        // load X | Y
        psq_l       vxy, 0(p), 0, 0
        // XX | YY
        ps_mul      vxy, vxy, vxy
        // load Z | Z
        lfs         vzz, 8(p)
        // XX + ZZ | YY + ZZ
        ps_madd     sqmag, vzz, vzz, vxy
        ps_sum0     sqmag, sqmag, vxy, vxy
    }

    return sqmag;
#else
    return p->x * p->x + p->y * p->y + p->z * p->z;
#endif
}

#if defined(NW4R_MATH_BROADWAY)
#define NW4R_VECCROSS      PSVECCrossProduct
#define NW4R_VECMAG        PSVECMag
#define NW4R_VECNORMALIZE  PSVECNormalize
#define NW4R_VECSQDIST     PSVECSquareDistance
#else
#define NW4R_VECCROSS      C_VECCrossProduct
#define NW4R_VECMAG        C_VECMag
#define NW4R_VECNORMALIZE  C_VECNormalize
#define NW4R_VECSQDIST     C_VECSquareDistance
#endif

inline VEC3* VEC3Cross(VEC3* pOut, const VEC3* p1, const VEC3* p2) { NW4R_VECCROSS(*p1, *p2, *pOut); return pOut; }

VEC3* VEC3Maximize(VEC3* pOut, const VEC3* p1, const VEC3* p2);
VEC3* VEC3Minimize(VEC3* pOut, const VEC3* p1, const VEC3* p2);

inline VEC3& VEC3::operator+=(const VEC3& rhs) { (void)VEC3Add(this, this, &rhs); return *this; }
inline VEC3& VEC3::operator-=(const VEC3& rhs) { (void)VEC3Sub(this, this, &rhs); return *this; }
inline VEC3& VEC3::operator*=(f32 f) { (void)VEC3Scale(this, this, f); return *this; }
inline VEC3 VEC3::operator+(const VEC3& rhs) const { VEC3 tmp; (void)VEC3Add(&tmp, this, &rhs); return tmp; }
inline VEC3 VEC3::operator-(const VEC3& rhs) const { VEC3 tmp; (void)VEC3Sub(&tmp, this, &rhs); return tmp; }

// PAL: 0x80085600
MTX33* MTX33Identity(MTX33*);
// PAL: 0x80085630
MTX33* MTX34ToMTX33(MTX33*, const MTX34*);
// PAL: 0x80085670
u32 MTX34InvTranspose(MTX33*, const MTX34*);
// PAL: 0x80085740
MTX34* MTX34Zero(MTX34*);
// PAL: 0x80085760
MTX34* MTX34Mult(MTX34*, const MTX34*, f32);
// PAL: 0x800857b0
MTX34* MTX34Scale(MTX34*, const MTX34*, const VEC3*);
// PAL: 0x80085810
MTX34* MTX34Trans(MTX34*, const MTX34*, const VEC3*);
// PAL: 0x80085880
MTX34* MTX34MAdd(MTX34*, f32, const MTX34*, const MTX34*);
// PAL: 0x80085900
MTX34* MTX34RotAxisFIdx(MTX34*, const VEC3*, f32);

// PAL: 0x80085b80
MTX44* MTX44Copy(MTX44*, MTX44*);

inline VEC3*
VEC3Transform(VEC3* pOut, const MTX34* pM, const VEC3* pV) { PSMTXMultVec(*pM, *pV, *pOut); return pOut; }
inline VEC3*
VEC3TransformSR(VEC3* pOut, const MTX34* pM, const VEC3* pV) { MTXMultVecSR(*pM, *pV, *pOut); return pOut; }

VEC3* VEC3TransformNormal(VEC3* pOut, const MTX34* pM, const VEC3* pV);

} // namespace math
} // namespace nw4r
/* end "nw4r/math/mathTypes.hpp" */

namespace EGG {
class Quatf;

struct Vector2f {
  float x;
  float y;

  float normalise();
  // uses fsqrt directly
  void normalise2();

  static Vector2f zero;
  // Basis vectors
  static const Vector2f ex, ey;

  inline Vector2f(float _x, float _y) : x(_x), y(_y) {}
  inline Vector2f() {}

  inline ~Vector2f() {}
};

struct Vector3f : public nw4r::math::VEC3 {
  float lenSq() const { return VEC3LenSq(this); }
  static float dot(const Vector3f& v1, const Vector3f& v2) { return VEC3Dot(&v1, &v2); }

  bool isSmall() const { return lenSq() <= FLT_EPSILON; }

  float normalise();
  // uses fsqrt directly
  void normalise2();
  void fromRotated(const Quatf& q, const Vector3f& v);
  static void projAndRej(Vector3f& proj, Vector3f& rej, const Vector3f& v1, const Vector3f& v2);

  static const Vector3f zero;
  // Basis vectors
  static const Vector3f ex, ey, ez;

  // Header fns
  inline Vector3f(float _x, float _y, float _z) {
    x = _x;
    y = _y;
    z = _z;
  }
  inline Vector3f() {}

  inline void setZero() {
    x = y = z = 0.0f;
  }

  inline void set(f32 val) {
    x = y = z = val;
  }

  inline void setOne() {
    x = y = z = 1.0f;
  }

  inline void setUp() {
    x = 0.0f;
    y = 1.0f;
    z = 0.0f;
  }

  Vector3f& operator+=(const Vector3f& rhs);
  Vector3f& operator*=(f32 rhs);
  Vector3f operator+(const Vector3f& rhs) const;
  Vector3f operator-(const Vector3f& rhs) const;
  Vector3f operator*(f32) const;
  Vector3f cross(const EGG::Vector3f& rhs) const {
    return Vector3f(y * rhs.z - z * rhs.y, z * rhs.x - x * rhs.z,
                    x * rhs.y - y * rhs.x);
  }
  float dot(const Vector3f& other) const { return x*other.x + y*other.y + z*other.z; }
  f32 squaredLength() const {
    return x * x + y * y + z * z;
  }
  static Vector3f cross(const EGG::Vector3f& lhs, const EGG::Vector3f& rhs) {
    return lhs.cross(rhs);
  }

  // for now
#ifndef REL
#ifndef VEC3_DTOR_INLINE
  // projection and rejection of v0 onto v1
  ~Vector3f();
#endif
#endif
};

inline Vector3f& Vector3f::operator+=(const Vector3f& rhs) { this->x += rhs.x; this->y += rhs.y; this->z += rhs.z; return *this; }
inline Vector3f& Vector3f::operator*=(f32 rhs) { this->x *= rhs; this->y *= rhs; this->z *= rhs; return *this; }
inline Vector3f Vector3f::operator+(const Vector3f& rhs) const { return Vector3f(x + rhs.x, y + rhs.y, z + rhs.z); }
inline Vector3f Vector3f::operator-(const Vector3f& rhs) const { Vector3f tmp; (void)VEC3Sub(&tmp, this, &rhs); return tmp; }
inline Vector3f Vector3f::operator*(f32 rhs) const { return Vector3f(x * rhs, y * rhs, z * rhs); }

// likely inline, I'll just put it here for now
bool isSphereContainedInOther(const EGG::Vector3f& p1, f32 r1, const EGG::Vector3f& p2, f32 r2);

} // namespace EGG
/* end "egg/math/eggVector.hpp" */

/* "src\kart\KartObjectProxy.hpp" line 8 "nw4r/ut/utList.hpp" */
#pragma once

/* "lib\nw4r\ut\utList.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

namespace nw4r {
namespace ut {

//! Bidirectional list node
struct Node {
  void* pred;
  void* succ;
};

// Unlike modern "std::list"-like structures, list nodes are directly inherited
// by children, which saves a level of indirection.
struct List {
  void* head;
  void* tail;
  u16 count;
  u16 intrusion_offset;
};

void List_Init(List* pList, u16 intrusion_offset);
void List_Append(List* pList, void* pObj);
void List_Insert(List* pList, void* pTgt, void* pObj);
void List_Remove(List* pList, void* pObj);
// PAL: 0x800af180
void* List_GetNext(const List*, const void*);
// PAL: 0x800af1a0
void* List_GetPrev(const List*, const void*);
// PAL: 0x800af1c0
void* List_GetNth(const List* pList, unsigned short);
inline void* List_GetFirst(const List* pList) {
  return List_GetNext(pList, nullptr);
}
// Seems to be not included as a symbol. Only inlined.
// void List_Prepend(List* pList, void* pObj);

} // namespace ut
} // namespace nw4r
/* end "nw4r/ut/utList.hpp" */

/* "src\kart\KartObjectProxy.hpp" line 10 "KartSettings.hpp" */
#pragma once

/* "src\kart\KartSettings.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartSettings.hpp" line 4 "system/ResourceManager.hpp" */
#pragma once

/* "src\system\ResourceManager.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */
/* "src\system\ResourceManager.hpp" line 3 "rk_common.h" */
#pragma once

#define MAX_PLAYER_COUNT 12
#define ARRAY_COUNT(array) (sizeof(array) / sizeof((array)[0]))

#define MAX_FRIEND_COUNT 30
/* end "rk_common.h" */

/* "src\system\ResourceManager.hpp" line 5 "decomp.h" */
/* end "decomp.h" */

/* "src\system\ResourceManager.hpp" line 7 "egg/core/eggDisposer.hpp" */
/**
 * @file
 * @brief Headers for EGG::Disposer.
 */

#pragma once

/* "lib\egg\core\eggDisposer.hpp" line 7 "nw4r/ut/utList.hpp" */
/* end "nw4r/ut/utList.hpp" */
/* "lib\egg\core\eggDisposer.hpp" line 8 "rk_types.h" */
/* end "rk_types.h" */

namespace EGG {

class Heap;

//! @brief Base class for garbage-collected objects.
//!
//! Scene-specific, heap-allocated resources in Mario Kart Wii are typically not explicitly
//! freed. This isn't a memory leak, though: when a Scene transitions, all
//! memory allocated within it is returned in one block. However, in C++, the
//! destructor of an object must be called when its lifetime
//! expires--otherwise, we could leak second-order resources and introduce
//! use-after-free bugs.
//!
//! Disposer solves this issue: when a heap is destroyed,
//! the linked list of disposers is traversed and each destructor is called
//! in-order.
//!
class Disposer : private NonCopyable {
  friend class Heap;

protected:
  //! @brief Disposer destructor: detach from heap.
  //!
  virtual ~Disposer();

  //! @brief Disposer constructor: attach to heap.
  //! @pre   Lifetime management is assumed if, and only if, the object is
  //! allocated within an EGG::Heap.
  //!
  Disposer();

public:
  //! Describes the lifetime of a derived object.
  enum eLifetime {
    //! This object is not allocated in an EGG::Heap; it acts as a regular C++
    //! object.
    LIFETIME_UNMANAGED,

    //! This object is garbage-collected; its lifetime is tied to its heap.
    LIFETIME_HEAP_GC
  };

  //! @brief Inspect the lifetime of this object.
  inline eLifetime getLifetime() const {
    return mContainHeap != nullptr ? LIFETIME_HEAP_GC : LIFETIME_UNMANAGED;
  }

private:
  // If null, Disposer is no-op.
  Heap* mContainHeap;
  // Otherwise, each Disposer object exists in a linked list owned by
  // mContainHeap.
  nw4r::ut::Node mLink;
};

} // namespace EGG
/* end "egg/core/eggDisposer.hpp" */
/* "src\system\ResourceManager.hpp" line 8 "egg/core/eggExpHeap.hpp" */
/*!
 * @file
 * @brief EGG wraper for expanded heaps header.
 */

#pragma once

/* "lib\egg\core\eggExpHeap.hpp" line 7 "egg/core/eggHeap.hpp" */
/**
 * @file
 * @brief Base Heap class.
 */

#pragma once

#ifndef HEAP_PRIVATE
#define HEAP_PRIVATE protected
#endif

/* "lib\egg\core\eggHeap.hpp" line 11 "egg/core/eggDisposer.hpp" */
/* end "egg/core/eggDisposer.hpp" */
/* "lib\egg\core\eggHeap.hpp" line 12 "nw4r/ut/utList.hpp" */
/* end "nw4r/ut/utList.hpp" */
/* "lib\egg\core\eggHeap.hpp" line 13 "rk_types.h" */
/* end "rk_types.h" */
/* "lib\egg\core\eggHeap.hpp" line 14 "rvl/os/osThread.h" */
#pragma once

/* "lib\rvl\os\osThread.h" line 2 "decomp.h" */
/* end "decomp.h" */
/* "lib\rvl\os\osThread.h" line 3 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\os\osThread.h" line 5 "os.h" */
#pragma once

/* "lib\rvl\os\os.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

#ifdef __cplusplus
extern "C" {
#endif

#define OSRoundUp32B(x) (((u32)(x) + 32 - 1) & ~(32 - 1))
#define OSRoundDown32B(x) (((u32)(x)) & ~(32 - 1))

static inline void OSInitFastCast(void) {
#ifdef __CWCC__
  asm {
    li r3, 4
    oris r3, r3, 4
    mtspr 0x392, r3
    li r3, 5
    oris r3, r3, 5
    mtspr 0x393, r3
    li r3, 6
    oris r3, r3, 6
    mtspr 0x394, r3
    li r3, 7
    oris r3, r3, 7
    mtspr 0x395, r3
  }
#endif
}

void OSRegisterVersion(const char* version);

typedef s64 OSTime;
typedef u32 OSTick;

typedef struct OSCalendarTime {
  int sec;
  int min;
  int hour;
  int mday;
  int mon;
  int year;
  int wday;
  int yday;

  int msec;
  int usec;
} OSCalendarTime;

#define OSTicksToSeconds(ticks) ((ticks) / OS_TIMER_CLOCK)
#define OSTicksToMilliseconds(ticks) ((ticks) / (OS_TIMER_CLOCK / 1000))

OSTick OSGetTick(void);
OSTime OSGetTime(void);

OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);

void __OSFPRInit(void);
void OSInit(void);
void __OSPSInit(void);
u32 __OSGetDIConfig(void);
void OSRegisterVersion(const char* ver);
const char* OSGetAppGamename(void);

#ifdef __cplusplus
}
#endif
/* end "os.h" */

#ifdef __cplusplus
extern "C" {
#endif
#ifndef RII_CLIENT

u32 __OSBusClock AT_ADDRESS(0x800000F8);

#define OS_TIMER_CLOCK (__OSBusClock >> 2)

#define OSMillisecondsToTicks(msec) ((msec) * (OS_TIMER_CLOCK / 1000))
#define OSSleepMilliseconds(msec)                                              \
  OSSleepTicks(OSMillisecondsToTicks((OSTime)msec))

typedef struct OSThread {
  char _00[0x304];
  char* stack_high; // 304
  char* stack_low;  // 308
  u32 error;        // 30C
  char _310[0x318 - 0x310];
} OSThread;

typedef struct OSThreadQueue OSThreadQueue;
struct OSThreadQueue {
  OSThread* head;
  OSThread* tail;
};


int OSCreateThread(OSThread* thread, void* (*callable)(void*), void* user_data,
                   void* stack, u32 stack_size, s32 prio, u16 flag);

                  
void OSCancelThread(OSThread*);

void OSDetachThread(OSThread*);

s32 OSResumeThread(OSThread*);

int OSIsThreadTerminated(OSThread*);

OSThread* OSGetCurrentThread();

typedef void (*OSSwitchFunction)(OSThread*, OSThread*);

OSSwitchFunction OSSetSwitchThreadCallback(OSSwitchFunction callable);

void OSSleepTicks(OSTime ticks);

void OSInitThreadQueue(struct OSThreadQueue*);

s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);

void __OSReschedule(void);

void OSYieldThread(void);
void OSExitThread(OSThread *thread);
BOOL OSJoinThread(OSThread *thread, void *val);

s32 OSSuspendThread(OSThread*);
void OSSleepThread(struct OSThreadQueue*);
void OSWakeupThread(struct OSThreadQueue*);

#endif
#ifdef __cplusplus
}
#endif
/* end "rvl/os/osThread.h" */
/* "lib\egg\core\eggHeap.hpp" line 15 "rvl/mem/memAllocator.h" */
#pragma once

/* "lib\rvl\mem\memAllocator.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\mem\memAllocator.h" line 4 "rvl/os/os.h" */
/* end "rvl/os/os.h" */
/* "lib\rvl\mem\memAllocator.h" line 5 "rvl/os/osInterrupt.h" */
#pragma once

/* "lib\rvl\os\osInterrupt.h" line 2 "decomp.h" */
/* end "decomp.h" */
/* "lib\rvl\os\osInterrupt.h" line 3 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\os\osInterrupt.h" line 5 "osContext.h" */
#pragma once

/* "lib\rvl\os\osContext.h" line 2 "decomp.h" */
/* end "decomp.h" */
/* "lib\rvl\os\osContext.h" line 3 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\os\osContext.h" line 5 "osThread.h" */
/* end "osThread.h" */

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
  OS_CONTEXT_STATE_FP_SAVED = (1 << 0),
} OSContextState;

typedef struct OSContext {
  // General-purpose registers
  u32 gpr[32];

  u32 cr;
  u32 lr;
  u32 ctr;
  u32 xer;

  // Floating-point registers
  f64 fpr[32];

  u32 fpscr_pad;
  u32 fpscr;

  // Exception handling registers
  u32 srr0;
  u32 srr1;

  // Context mode
  u16 mode;  // since UIMM is 16 bits in PPC
  u16 state; // OR-ed OS_CONTEXT_STATE_*

  // Place Gekko regs at the end so we have minimal changes to
  // existing code
  u32 gqr[8];
  u32 psf_pad;
  f64 psf[32];

} OSContext;

void OSLoadFPUContext(OSContext*);
void OSSaveFPUContext(OSContext* ctx);
void OSSetCurrentContext(OSContext* context);
OSContext* OSGetCurrentContext(void);
void OSLoadContext(OSContext* context);
u32 OSGetStackPointer(void);
void OSClearContext(OSContext* context);
void OSInitContext(OSContext* context, u32 pc, u32 sp);
void OSDumpContext(OSContext*);

#ifdef __cplusplus
}
#endif
/* end "osContext.h" */

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*__OSInterruptHandler)(s16 interrupt, OSContext* context);

int OSDisableInterrupts(void);
int OSEnableInterrupts(void);
int OSRestoreInterrupts(int level);
__OSInterruptHandler __OSSetInterruptHandler(s16 interrupt,
                                             __OSInterruptHandler handler);
__OSInterruptHandler __OSGetInterruptHandler(s16 interrupt);
void __OSInterruptInit(void);
u32 __OSMaskInterrupts(u32);
u32 __OSUnmaskInterrupts(u32);
void __OSDispatchInterrupt(u8 exception, OSContext* context);

extern volatile OSTime __OSLastInterruptTime;
extern volatile s16 __OSLastInterrupt;
extern volatile u32 __OSLastInterruptSrr0;

#ifdef __cplusplus
}
#endif
/* end "rvl/os/osInterrupt.h" */
/* "lib\rvl\mem\memAllocator.h" line 6 "rvl/os/osMutex.h" */
#pragma once

/* "lib\rvl\os\osMutex.h" line 2 "decomp.h" */
/* end "decomp.h" */
/* "lib\rvl\os\osMutex.h" line 3 "rk_types.h" */
/* end "rk_types.h" */

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  char _[0x18];
} OSMutex;

void OSInitMutex(OSMutex*);
void OSLockMutex(OSMutex*);
void OSUnlockMutex(OSMutex*);
s32 OSTryLockMutex(OSMutex*);

#ifdef __cplusplus
}
#endif
/* end "rvl/os/osMutex.h" */
/* "lib\rvl\mem\memAllocator.h" line 7 "rvlMemList.h" */
#pragma once

/* "lib\rvl\mem\rvlMemList.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

#ifdef __cplusplus
extern "C" {
#endif

//! Bidirectional list node
typedef struct {
  void* pred;
  void* succ;
} MEMLink;

// Unlike modern "std::list"-like structures, list nodes are directly inherited
// by children, which saves a level of indirection.
// Size: 0x0C
typedef struct {
  void* head;           // 0x00
  void* tail;           // 0x04
  u16 count;            // 0x08
  u16 intrusion_offset; // 0x0A
} MEMList;

MEMList* MEMInitList(MEMList*, u16);
MEMList* MEMAppendListObject(MEMList*, void*);
MEMList* MEMRemoveListObject(MEMList*, void*);
void* MEMGetNextListObject(MEMList*, void*);

#define rvlMemListGetNode(list, obj)                                           \
  ((MEMLink*)(((char*)obj) + (list)->intrusion_offset))

#ifdef __cplusplus
}
#endif
/* end "rvlMemList.h" */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef RII_CLIENT

typedef struct MEMAllocator MEMAllocator;

typedef void* (*MEMFuncAllocatorAlloc)(MEMAllocator*, u32);
typedef void (*MEMFuncAllocatorFree)(MEMAllocator*, void*);

typedef struct MEMAllocatorFunc MEMAllocatorFunc;
struct MEMAllocatorFunc {
  MEMFuncAllocatorAlloc alloc; // 0x00
  MEMFuncAllocatorFree free;   // 0x04
};

struct MEMAllocator {
  const MEMAllocatorFunc* func; // 0x00
  void* heap;                   // 0x04
  u32 _unk08;                   // 0x08
  u32 _unk0C;                   // 0x0C
};

typedef struct MEMiHeapHead MEMiHeapHead;

struct MEMiHeapHead {
  u32 _unk00;        // 0x00
  MEMLink link;      // 0x04
  MEMList list;      // 0x0c
  void* arena_start; // 0x18
  void* arena_end;   // 0x1C
  OSMutex mutex;     // 0x20
  // No idea what this is.
  union {
    u32 val; // 0x38
    struct {
      u32 _0_24 : 24; // 0x38
      u32 flags : 8;  // 0x38
    } parts;
  } _unk38;
};

typedef MEMiHeapHead* MEMHeapHandle;

void* MEM_AllocForExpHeap_(MEMAllocator* alloc, u32 size);
void MEM_FreeForExpHeap_(MEMAllocator* alloc, void* data);
void* MEM_AllocForUnitHeap(MEMAllocator* alloc, u32 size);
void MEM_FreeForUnitHeap(MEMAllocator* alloc, void* data);
void* MEMAllocFromAllocator(MEMAllocator* alloc, u32 size);
void MEMFreeToAllocator(MEMAllocator* alloc, void* data);
void MEMInitAllocatorForExpHeap(MEMAllocator*, MEMHeapHandle, int);
void MEMInitAllocatorForUnitHeap(MEMAllocator*, MEMHeapHandle);

MEMiHeapHead* MEMFindContainHeap(const void*);

#else
//#include <revolution/mem.h>
#endif

#ifdef __cplusplus
} // extern "C"
#endif
/* end "rvl/mem/memAllocator.h" */
/* "lib\egg\core\eggHeap.hpp" line 16 "egg/core/eggThread.hpp" */
/**
 * @file
 * @brief Thread class for extending.
 */

#pragma once

/* "lib\egg\core\eggThread.hpp" line 7 "nw4r/ut/utList.hpp" */
/* end "nw4r/ut/utList.hpp" */
/* "lib\egg\core\eggThread.hpp" line 8 "rk_types.h" */
/* end "rk_types.h" */
#ifndef RII_CLIENT
/* "lib\egg\core\eggThread.hpp" line 10 "rvl/os/osMessage.h" */
#pragma once

/* "lib\rvl\os\osMessage.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\os\osMessage.h" line 4 "decomp.h" */
/* end "decomp.h" */

#ifdef __cplusplus
extern "C" {
#endif

typedef void* OSMessage;

typedef struct OSMessageQueue {
  char _[0x20];
} OSMessageQueue;

#define OS_MESSAGE_NOBLOCK 0
#define OS_MESSAGE_BLOCK 1

void OSInitMessageQueue(OSMessageQueue* mq, OSMessage* msgArray, s32 msgCount);
int OSSendMessage(OSMessageQueue* mq, OSMessage msg, s32 flags);
int OSReceiveMessage(OSMessageQueue* mq, OSMessage* msg, s32 flags);

#ifdef __cplusplus
}
#endif
/* end "rvl/os/osMessage.h" */
/* "lib\egg\core\eggThread.hpp" line 11 "rvl/os/osThread.h" */
/* end "rvl/os/osThread.h" */
#endif

namespace EGG {

class Heap;

//---------------------------------------------------------------------------
//! @brief   Wrapper for OSThread.
//---------------------------------------------------------------------------
class Thread {
public:
  virtual ~Thread(); //!< [vt+0x08] Destroys the EGG Thread, freeing all used
                     //!< memory and canceling the OSThread

  virtual void* run();           //!< [vt+0x0C]
  virtual void onEnter(); /*{}*/ //!< [vt+0x14]
  virtual void onExit(); /*{}*/  //!< [vt+0x10]

  //! @brief   	A constructor.
  //!
  //! @details	Creates an EGG::Thread and OSThread from arguments.
  //!
  //! @param[in]	stackSize:	The size of the stack to create.
  //! @param[in] 	msgCount:	The maximum number of messages the
  //! buffer can hold.
  //! @param[in]	prio:		Priority of the OSThread to create. 0 is
  //! highest priority; 31 is lowest priority.
  //!							The default thread has a
  //! priority of 16.
  //!
  //! @param[in]	heap:		Heap to use for allocations.
  //!
  Thread(u32 stackSize, int msgCount, int prio, Heap* heap);

  //! @brief   	A constructor.
  //!
  //! @details	Creates an EGG::Thread to wrap the provided OSThread.
  //!
  //! @param[in]	osThread: 	OS thread to wrap.
  //! @param[in] 	msgCount:	The maximum number of messages the
  //! buffer can hold.
  //!
  Thread(OSThread* osThread, int msgCount);

private:
  inline Thread(const Thread&) {}

public:
  //! @brief   	Find the (first) EGG::Thread that matches the provided osThread.
  //!
  //! @details	Iterate through the static thread list (sThreadList) to find the
  //! first EGG thread
  //!				that wraps the specified OS thread.
  //!
  //! @param[in]	osThread: 	The OS thread to search for.
  //!
  //! @return 	The found EGG thread.
  //! @retval		NULL: No matching EGG thread was found.
  //!
  static Thread* findThread(OSThread* osThread);

  //! @brief   	Cancel all but the current thread.
  //!
  //! @details	Iterates through registed threads in sThreadList, checking
  //! against
  //!				OSGetCurrentThread(), then calling
  //! OSCancelThread().
  //!
  static void kandoTestCancelAllThread();

  //! @brief   	Initialize EGG Thread.
  //!
  //! @details	Initializes sThreadList and sets the SwitchThreadCallback to
  //!				Thread::switchThreadCallback.
  //!
  static void initialize();

  //! @brief   	The callback for switching threads.
  //!
  //! @details	Finds the associated EGG threads of the two OSThreads, and calls
  //! onExit()
  //!				on the first thread and onEnter() on the next.
  //!
  //! @param[in]	from: 	The last thread running.
  //! @param[in] 	to:		The next thread to run.
  //!
  //! @note		Either threads may be null if there is no thread to run.
  //!				This function handles this accordingly
  //!
  static void switchThreadCallback(OSThread* from, OSThread* to);

  //! @brief   	Configures the message queue.
  //!
  //! @details	- Allocates mMesgBuffer to msgCount * 4
  //!				- Calls OSInitMessageQueue using mMesgQueue and
  //! mMesgBuffer
  //!				- Appends this Thread to sThreadList
  //!
  //! @param[in]	msgCount: 	The maximum number of messages the
  //! buffer can hold.
  //!							The buffer size in bytes
  //! will be msgCount
  //!* 4.
  //!
  void setCommonMesgQueue(int msgCount, Heap* heap);

  //! @brief   	Starts a thread.
  //!
  //! @details	Casts eggThread to EGG::Thread* and calls the virtual run
  //! method.
  //!
  //! @param[in]	eggThread: 	Pointer to an object that inherits
  //! Thread.
  //!
  static void* start(void* eggThread);

  inline OSMessageQueue* getMesgQueue() { return &mMesgQueue; }

  inline OSThread* getOSThread() { return mOSThread; }

  //! When not NULL will override the heap used for allocations.
  inline Heap* getAllocatableHeap() { return mAlloctableHeap; }

  inline void resume() { OSResumeThread(mOSThread); }

  inline int sendMessage(OSMessage message) {
    return OSSendMessage(&mMesgQueue, message, OS_MESSAGE_NOBLOCK);
  }

  inline OSMessage waitMessage(int* success) {
    OSMessage message;
    *success = OSReceiveMessage(&mMesgQueue, &message, OS_MESSAGE_NOBLOCK);
    return message;
  }

  inline OSMessage waitMessageBlock() {
    OSMessage message;
    OSReceiveMessage(&mMesgQueue, &message, OS_MESSAGE_BLOCK);
    return message;
  }

private:
  // List of all registered threads.
  static nw4r::ut::List sThreadList;

  Heap* mContainingHeap; //!< [+0x04] Heap to use for thread-specific
                         //!< allocations (in ctor: create stack and OSThread)
  OSThread* mOSThread;   //!< [+0x08] The OS thread this object wraps. Name
                         //!< confirmed by WS assert.

  OSMessageQueue mMesgQueue; //!< [+0x0C] sizeof=0x20
  OSMessage* mMesgBuffer;    //!< [+0x2C] name confirmed WS assert
  int mMesgCount;            //!< [+0x30]

  char* mStackMemory; //!< [+0x34] The base (*beginning*) of the stack.
  u32 mStackSize;     //!< [+0x38] The size of the stack.

  Heap* mAlloctableHeap; //!< [0+x3C] When not NULL will override the heap used
                         //!< for allocations. (Note: Does not escape the
                         //!< Heap::sAllocatableHeap restriction.)
  nw4r::ut::Node mLink;
};

} // namespace EGG
/* end "egg/core/eggThread.hpp" */

namespace EGG {

class ExpHeap;
class Allocator;

struct HeapAllocArg {
  int userArg; // 00
  u32 size;    // 04
  int align;   // 08
  Heap* heap;  // 0C heap to allocate in

  inline HeapAllocArg() : userArg(0), size(0), align(0), heap(nullptr) {}
};
typedef void (*HeapAllocCallback)(HeapAllocArg& arg);

struct HeapErrorArg {
  const char* msg;
  void* userdata;

  inline HeapErrorArg() {}
};

typedef void (*ErrorCallback)(void*);

//! @brief   Base Heap class
//!
//! @details EGG::Heap is not concrete and only acts as an interface for actual
//! implementations.
//!
class Heap : public Disposer {
public:
  //! @brief Types of heaps that can be created
  //!
  enum eHeapKind {
    HEAP_KIND_NONE = 0, //!< [0] Unconfirmed!
    HEAP_KIND_EXPANDED, //!< [1] Expanded heap.
    HEAP_KIND_FRAME,    //!< [2] Frame heap. Doesn't exist in MKW's EGG.
    HEAP_KIND_UNIT      //!< [3] Unit heap.
  };

  inline bool isExpHeap() { return getHeapKind() == HEAP_KIND_EXPANDED; }
  inline Heap* getParentHeap() { return mParentHeap; }
  inline void* getStartAddress() { return this; }

  virtual ~Heap();

  //! @brief [vt+0x0C] Get the type of heap the current heap is.
  //!
  //! @returns The eHeapKing of the heap.
  //!
  virtual eHeapKind getHeapKind() const = 0;

  virtual void initAllocator(Allocator* allocator, s32 align) = 0; // [vt+0x10]
  virtual void* alloc(u32 size, s32 align) = 0;                    // [vt+0x14]
  virtual void free(void* block) = 0;                              // [vt+0x18]
  virtual void destroy() = 0;                                      // [vt+0x1C]
  virtual u32 resizeForMBlock(void* block, u32 size) = 0;          // [vt+0x20]
  virtual u32 getAllocatableSize(s32 align) = 0;                   // [vt+0x24]
  virtual u32 adjust() = 0;                                        // [vt+0x28]

  HEAP_PRIVATE :
      //! @brief   	Static linked-list of heaps.
      //!
      //! @details	When a heap is created, it is appended to this list.
      //!				When it is deleted, it is removed.
      //!
      static nw4r::ut::List sHeapList;

  //! @brief   	Root heap mutex.
  //!
  static OSMutex sRootMutex;

  //! @brief When the heap passed to alloc is NULL, use this instead.
  static Heap* sCurrentHeap;

  //! @brief Whether or not the static list of heaps has been initialized.
  //! @see   initialize
  static int sIsHeapListInitialized;

  //! @brief	When non NULL, this heap MUST be used for heap allocations.
  //!			This will restrict rather than redirect allocations.
  static Heap* sAllocatableHeap;
  static ErrorCallback sErrorCallback;     //!< TODO
  static HeapAllocCallback sAllocCallback; //!< TODO
  static void* sErrorCallbackArg;          //!< TODO
  static void* sAllocCallbackArg;          //!< TODO
  static class Thread* sAllocatableThread; //!< TODO
public:
  //! @brief [+0x10] argument of heap constructor. Name confirmed by WS assert.
  MEMHeapHandle mHeapHandle;
  //! @brief [+0x14] set to 0 in heap ctor. treeki -- void* parentHeapMBlock
  void* mParentBlock;
  //! @brief [+0x18] name from findParentHeap()
  Heap* mParentHeap;
  //! @brief [+0x1C] Values of HeapFlag
  enum HeapFlag {
    // tstDisableAllocation, enableAllocation, disableAllocation
    // setBit__Q23EGG12TBitFlag<Us>FUc
    HEAP_FLAG_LOCKED = (1 << 0)
  };
  u16 mFlag;
  // 2b implicit pad?

  //! @details List of child disposers.
  //! When Heap::dispose() is called, ~Disposer() will be called for all
  //! children.
  nw4r::ut::Node mNode;     //!< [+0x20]
  nw4r::ut::List mChildren; //!< [+0x28] sizeof=0xC

  const char* mName; //!< [+0x034] set to "NoName" in ctor

public:
  //! @brief   	Must be called before heaps are created. Prepares static heap
  //! members.
  //!
  //! @details	Initializes the static heap data for heap creation.
  //!
  //! @post
  //!	- sHeapList is initialized.
  //!	- sRootMutex is initialized.
  //!	- sIsHeapListInitialized is true.
  //!
  //!
  static void initialize();

  //! @brief   	Heap constructor.
  //!
  //! @details	Creates a Heap wrapper around the supplied MEM heap.
  //!				- Calls down to the parent Disposer constructor
  //! before setting values.
  //!				- Parent members _14, _18, _1C are zeroed; mName
  //! is set to "NoName".
  //!				- ut::List at _28 initialized.
  //!				- This heap is added to the global heap list
  //!(sHeapList).
  //!
  //! @param[in]	heapHandle: MEM heap handle to create EGG::Heap wrapper
  //! around.
  //!
  //! @pre 		initialize() has been called. (WS asserts
  //! sHeapInitialized)
  //!
  //! @return 	this
  //!
  Heap(MEMiHeapHead* heapHandle);

private:
  inline Heap(const Heap&) {}

public:
  //! @brief   	Allocate a block of memory in a heap.
  //!
  //! @details	TODO
  //!
  //! @param[in]	size: 	Size of the block in bytes.
  //! @param[in]  align:	Alignment of block to create.
  //! @param[in]	heap:	Heap to allocate block in.
  //!
  //! @return 	The address of the allocated block.
  //! @retval		NULL: The allocation failed.
  //!
  static void* alloc(u32 size, int align, Heap* heap);

  template <typename T> static T* alloc(u32 count, Heap* heap, int align = 4) {
    return reinterpret_cast<T*>(alloc(count * sizeof(T), align, heap));
  }
  template <typename T> static T* alloc(Heap* heap, int align = 4) {
    return reinterpret_cast<T*>(alloc(sizeof(T), align, heap));
  }

  //! @brief   	Returns the Disposer's parent heap.
  //!
  //! @details	Initializes the static heap data for heap creation.
  //!
  //! @pre		mHeapHandle != NULL. (WS assert)
  //!
  Heap* findParentHeap();

  //! @brief   	Scan global heap list for heap containing specified memory
  //! block.
  //!
  //! @details	First runs MEMFindContainHeap() to determine if it is in a MEM
  //! heap.
  //!				If this check passes, it will iterate through
  //! sHeapList, checking if 				the heap in each
  //! iteration's _10 matches the MEM heap found before.
  //!
  //! @param[in]	memBlock: Memory block to look scan for container.
  //!
  //! @pre 		sHeapList is intialized. (sIsHeapListInitialized)
  //!
  //! @return 	The Heap that contains the memory block.
  //! @retval		nullptr: The memory block is not contained in any heap
  //!
  static Heap* findContainHeap(const void* memBlock);

  //! @brief   	Free a block of memory from a heap.
  //!
  //! @details	Safely calls heap virtual free function on a memory block.
  //! Memory contained in a non EGG heap cannot be used.
  //!
  //! @param[in]	memBlock Block of memory to free.
  //! @param[in]  heap     Heap of memBlock to use for free. If NULL, it will be
  //! rederived.
  //!
  //! @pre 		If no heap is provided, the global heap list must be
  //! initialized.
  //!
  static void free(void* memBlock, Heap* heap);

  //! @brief   	Destroy all child heaps.
  //!
  //! @details	Calls destructor on first heap in child heap list until there
  //! are no children.
  //!
  void dispose();

  static void dumpAll();

  //! @brief   	Let this heap become the current heap.
  //!
  //! @details	Sets the static Heap sCurrentHeap to this.
  //!
  //! @pre 		sRootMutex is intialized.
  //!
  //! @return 	The previous current heap.
  //!
  Heap* becomeCurrentHeap();

public:
  bool hasFlag(u8 idx) volatile { return mFlag & 1 << idx; }

  void clearFlag(u8 idx) volatile { mFlag &= ~(1 << idx); }

  void setFlag(u8 idx) volatile { mFlag |= (1 << idx); }

  //! @brief Enables the heap's allocation.
  //!
  //! @return Whether or not the heap's allocation was disabled.
  //!
  bool enableAllocation() {
    bool b = hasFlag(0);
    if (b)
      clearFlag(0);
    return b;
  }

  //! @brief Disables the heap's allocation.
  //!
  void disableAllocation() {
    setFlag(0);
  }

  static void* addOffset(void* begin, u32 size) {
    return reinterpret_cast<char*>(begin) + size;
  }

  inline void appendDisposer(Disposer* disposer) {
    nw4r::ut::List_Append(&mChildren, disposer);
  }
  inline void removeDisposer(Disposer* disposer) {
    nw4r::ut::List_Remove(&mChildren, disposer);
  }

  inline MEMiHeapHead* getHeapHandle() { return mHeapHandle; }

  static inline Heap* getCurrentHeap() { return sCurrentHeap; }

  inline int getArenaEnd() {
#ifdef RII_CLIENT
    return 0;
#else
    return (int)mHeapHandle->arena_end;
#endif
  }
};

} // namespace EGG

void* operator new(size_t size);
// __nwa(ulong, ulong)
void* operator new[](size_t size, u32 align);
// __nw(ulong, EGG::Heap *, int)
void* operator new(size_t size, EGG::Heap* heap, int align);
// __nwa(ulong)
void* operator new[](size_t size);
// __nwa(ulong, int)
void* operator new[](size_t size, int align);
// __nwa(ulong, EGG::Heap *, int)
void* operator new[](size_t size, EGG::Heap* heap, int align);
// __dl(void *)
void operator delete(void* p);
// __dla(void *)
void operator delete[](void*);

#undef HEAP_PRIVATE
/* end "egg/core/eggHeap.hpp" */
/* "lib\egg\core\eggExpHeap.hpp" line 8 "rk_types.h" */
/* end "rk_types.h" */

namespace EGG {

class ExpHeap : public Heap {
public:
  struct GroupSizeRecord {
    u32 entries[256];

    GroupSizeRecord();
    void reset();
    void addSize(u16 groupID, u32 size);
  };

  ExpHeap(MEMHeapHandle heapHandle) : Heap(heapHandle) {}

  virtual ~ExpHeap() override;

  //! @brief Create an EGG ExpHeap and wrapped MEM ExpHeap in a certain region.
  //!
  //! @param[in] block Start of memory block to create.
  //! @param[in] size Size of the new heap to create. Must be at least 60 bytes.
  //! @param[in] attr MEM ExpHeap option flags.
  //!
  //! @returns The created ExpHeap
  //!
  static ExpHeap* create(void* block, u32 size, u16 attr) NEVER_INLINE;

  //! @brief Create a new ExpHeap as a child of an existing heap.
  //!
  //! @param[in] size Size of the new heap to create. If -1, the maximum
  //! alloctable size will be used.
  //! @param[in] heap Parent heap to use. If NULL, default heap will be used.
  //! @param[in] attr MEM ExpHeap option flags.
  //
  static ExpHeap* create(u32 size, Heap* heap, u16 attr);

  //! @brief There's no evidence of this macro/inline function existing, but it
  //! makes future work a lot cleaner.
  static inline ExpHeap* Make(void* start, u32 size, char* name) {
    ExpHeap* made = ExpHeap::create(start, size, 0);
    made->mName = name;
    return made;
  }
  //! @brief There's no evidence of this macro/inline function existing, but it
  //! makes future work a lot cleaner.
  static inline ExpHeap* MakeChild(u32 size, Heap* parent, char* name) {
    ExpHeap* made = ExpHeap::create(size, parent, 0);
    made->mName = name;
    return made;
  }

  //! @brief Destroy the current heap and free itself from its parent if it has
  //! one.
  //!
  void destroy() override;

  //! @brief Allocate a block of memory in the heap.
  //!
  //! @param[in] size  Size of the block of memory.
  //! @param[in] align Alignment of memory block.
  //!
  //! @pre _1 must not have the last bit set.
  //!		 If set, `OSPanic("eggExpHeap.cpp", 174, "DAME DAME\n");`
  //!
  void* alloc(u32 size, s32 align) override;

  //! @brief Free a block of memory in the heap.
  //!
  //! @param[in] block Block of memory in the heap.
  //!
  void free(void* block) override;

  //! @brief Resize allocated memory block.
  //!
  //! @param[in] block Allocated memory block to resize.
  //! @param[in] size  New size for memory block.
  //!
  //! @returns New size of memory block.
  //!			 - When expanding, may be greater than the size of the
  //! requested size.
  //!			 - When reducing, may be the original block size.
  //!			 - When unsuccessful, 0.
  //!
  u32 resizeForMBlock(void* block, u32 size) override;

  u32 getTotalFreeSize();

  u32 getAllocatableSize(s32 align) override;

  u16 setGroupID(u16 groupID);

  u32 adjust() override;

  void initAllocator(Allocator* allocator, s32 align) override;

  static void addGroupSize(void* block, MEMHeapHandle heap, u32 userParam);

  void calcGroupSize(GroupSizeRecord* record);

  void freeAll();

  //! @brief Returns the heap kind.
  //!
  //! @returns HEAP_KIND_EXPANDED
  //!
  eHeapKind getHeapKind() const override;
};

} // namespace EGG
/* end "egg/core/eggExpHeap.hpp" */
/* "src\system\ResourceManager.hpp" line 9 "system/DvdArchive.hpp" */
#pragma once

/* "src\system\DvdArchive.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */
/* "src\system\DvdArchive.hpp" line 3 "stdio.h" */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define FILENAME_MAX 256

#ifndef NULL
#define NULL 0
#endif

#ifndef SIZE_T_DEFINE
#define SIZE_T_DEFINE
typedef unsigned long size_t;
#endif

typedef struct _FILE FILE;

typedef unsigned long __file_handle;

typedef unsigned long fpos_t;

typedef void* __ref_con;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode,
                          __ref_con ref_con);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count,
                         __ref_con ref_con);
typedef int (*__close_proc)(__file_handle file);

typedef struct {
  unsigned int open_mode : 2;
  unsigned int io_mode : 3;
  unsigned int buffer_mode : 2;
  unsigned int file_kind : 3;

  unsigned int binary_io : 1;
} __file_modes;

typedef struct {
  unsigned int io_state : 3;
  unsigned int free_buffer : 1;
  unsigned char eof;
  unsigned char error;
} __file_state;

struct _FILE {
  __file_handle handle;
  __file_modes mode;
  __file_state state;

  unsigned char char_buffer;
  unsigned char char_buffer_overflow;
  unsigned char ungetc_buffer[2];

  unsigned long position;
  unsigned char* buffer;
  unsigned long buffer_size;
  unsigned char* buffer_ptr;
  unsigned long buffer_len;
  unsigned long buffer_alignment;
  unsigned long saved_buffer_len;
  unsigned long buffer_pos;
  __pos_proc position_proc;
  __io_proc read_proc;
  __io_proc write_proc;
  __close_proc close_proc;
  __ref_con ref_con;
};

#define EOF (-1)

#define SEEK_CUR 1
#define SEEK_END 2
#define SEEK_SET 0

typedef char* va_list;

int sprintf(char* str, const char* format, ...);
int snprintf(char* s, size_t n, const char* format, ...);
#ifdef __CWCC__
int vsnprintf(char* s, size_t n, const char* format, va_list arg);
int vprintf(const char* format, va_list arg);
int vsprintf(char* s, const char* format, va_list arg);
#endif

int sscanf(const char* str, const char* format, ...);

FILE* fopen(const char* filename, const char* mode);
int fclose(FILE* stream);
int fseek(FILE* stream, long int offset, int origin);
long int ftell(FILE* stream);
size_t fread(void* ptr, size_t size, size_t count, FILE* stream);
void rewind(FILE* stream);

int remove(const char* pathname);

#ifdef __cplusplus
}
#endif
/* end "stdio.h" */
/* "src\system\DvdArchive.hpp" line 4 "egg/core/eggArchive.hpp" */
/*!
 * @file
 * @brief A read-only view of a "dolphin archive" .arc file.
 */

#pragma once

/* "lib\egg\core\eggArchive.hpp" line 7 "rk_types.h" */
/* end "rk_types.h" */
/* "lib\egg\core\eggArchive.hpp" line 8 "stddef.h" */
/* end "stddef.h" */
/* "lib\egg\core\eggArchive.hpp" line 9 "string.h" */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#ifndef SIZE_T_DEFINE
#define SIZE_T_DEFINE
typedef unsigned long size_t;
#endif

// PAL: 0x80005f34
void* memcpy(void*, const void*, size_t);
// PAL: 0x80006038
void* memset(void*, int, size_t);

void* memmove(void*, const void*, size_t);
void* memchr(const void* ptr, int value, size_t num);
void* __memrchr(const void* ptr, int value, size_t num);

int memcmp(const void* s1, const void* s2, size_t n);

size_t strlen(const char*);

char* strcpy(char* dst, const char* src);
char* strncpy(char* dest, const char* src, size_t n);
int strcmp(const char* s1, const char* s2);
int strncmp(const char* s1, const char* s2, size_t n);

char* strchr(const char*, int);
char* strrchr(const char* str, int ch);

char* strstr(const char* haystack, const char* needle);

size_t strspn(const char* s, const char* accept);
size_t strcspn(const char* s, const char* reject);

char* strcat(char* dest, const char* src);
char* strncat(char* dest, const char* src, size_t n);

#ifndef NULL
#define NULL 0
#endif

#ifdef __cplusplus
} // extern "C"
#endif
/* end "string.h" */

/* "lib\egg\core\eggArchive.hpp" line 11 "egg/core/eggDisposer.hpp" */
/* end "egg/core/eggDisposer.hpp" */
/* "lib\egg\core\eggArchive.hpp" line 12 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */
/* "lib\egg\core\eggArchive.hpp" line 13 "egg/eggInternal.hpp" */
#pragma once

#define EGG_ASSERT(...)
/* end "egg/eggInternal.hpp" */
/* "lib\egg\core\eggArchive.hpp" line 14 "nw4r/ut/utList.hpp" */
/* end "nw4r/ut/utList.hpp" */
/* "lib\egg\core\eggArchive.hpp" line 15 "rvl/arc/rvlArchive.h" */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

/* "lib\rvl\arc\rvlArchive.h" line 6 "rk_types.h" */
/* end "rk_types.h" */
/* "lib\rvl\arc\rvlArchive.h" line 7 "stdbool.h" */
#pragma once

#ifndef __cplusplus
typedef _Bool bool;

#define true ((_Bool)1)
#define false ((_Bool)0)
#endif // __cplusplus
/* end "stdbool.h" */

//! Describes the type of an entry in an archive.
//!
typedef enum rvlArchiveType {
  //! The entry is a file.
  //! Accessed via rvlArchiveFile with ARCOpen/ARCFastOpen
  //!
  RVL_ARCHIVE_FILE,

  //! The entry is a folder.
  //!
  RVL_ARCHIVE_FOLDER
} rvlArchiveType;

//! A unique integer handle.
//! Negative if the operation failed.
//! For use with rvlArchiveFileOpenLow.
//!
typedef s32 rvlArchiveEntryHandle;

//! Return if the handle returned by rvlArchiveResolve is valid.
//!
//! @note A handle may be plausibly valid,
//!       although not valid for a specific archive.
//!
#define rvlArchiveEntryHandleIsValid(handle) ((handle) >= 0)

//! Return if the handle is valid for a specific archive.
//!
#define rvlArchiveEntryHandleIsValidForArchive(handle, archive)                \
  ((handle) >= 0 && (handle) < archive->mCount)

//! A read-only view of an archive file.
//!
typedef struct rvlArchive {
  const struct rvlArchiveHeader* mHeader; //!< 00 Pointer to the archive header.
  const struct rvlArchiveNode*
      mNodes;           //!< 04 Array of nodes for each archive entry.
  const u8* mFileData;  //!< 08 File data buffer, accessed by nodes.
  u32 mCount;           //!< 0C Number of nodes in the archive.
  const char* mStrings; //!< 10 String buffer, accessed by nodes.
  u32 mFstSize;         //!< 14 Total bytesize of nodes and strings.
  u32 mCurrentPath;     //!< 18 The current directory of the archive.
} rvlArchive;

//! File info.
//!
typedef struct rvlArchiveFile {
  rvlArchive* parent; //!< 00 The archive the file is a part of.
  u32 offset;         //!< 04 Offset into the archive's file data buffer.
  u32 size;           //!< 08 Size of the file.
} rvlArchiveFile;

//! Info about a generic file or folder.
//! - If node_type is rvl_ARCHIVE_FILE, use rvlArchiveFileOpenLow to fill-in an
//!   rvlArchiveFile.
//! - If node_type is rvl_ARCHIVE_FOLDER, use rvlArchiveFolderOpen to fill-in an
//!   rvlArchiveFolderRange.
//!
typedef struct rvlArchiveEntry {
  rvlArchive* parent;       //!< 00 The archive the file is a part of.
  u32 path;                 //!< 04 Special ID corresponding to a file path.
                            //!< Accepted by rvlArchiveFileOpenLow.
  rvlArchiveType node_type; //!< The entry type.
  const char* name;         //!< 0C Name of this entry in specific.
                            //!< (Not an absolute path)
} rvlArchiveEntry;

//! Contains an iterable range of the recursive contents of a folder.
//!
typedef struct rvlArchiveFolderRange {
  rvlArchive* parent; //!< 00 The archive the file is a part of.
  u32 path_begin;     //!< 04 The lower bound of the iterator range.
  u32 path_it;        //!< 08 The current position of the iterator.
  u32 path_end;       //!< 0C The upper bound of the iterator range.
} rvlArchiveFolderRange;

//! @brief Open an archive from the specified U8 data.
//!
//! @param[in]  pData Pointer to the U8 data.
//! @param[out] pOut  Pointer to the archive to create.
//!
//! @return If the operation succeeded.
//!
bool ARCInitHandle(void* pData, rvlArchive* pOut);

//! @brief Resolve a string path to a unique integer
//!        for use with ARCFastOpen.
//!
//! @param[in] self The archive.
//! @param[in] path Null-terminated string path. Forward slashes must be used.
//!
//! @return A unique integer handle. Negative if the operation failed.
//!
rvlArchiveEntryHandle ARCConvertPathToEntrynum(rvlArchive* self,
                                               const char* path);

//! @brief Set the current path of the archive to a new root for future access.
//!        Similar to the "cd" command.
//!
//! @param[in] self The archive.
//! @param[in] path Null-terminated string path. Forward slashes must be used.
//!
//! @return If the operation succeeded.
//!
bool ARCChangeDir(rvlArchive* self, const char* path);

//! @brief Open a file handle from an archive.
//!
//! @param[in]  self The archive.
//! @param[in]  path Null-terminated string path. Forward slashes must be used.
//! @param[out] pOut Pointer to an rvlArchiveFile to fill in.
//!
//! @return If the operation succeeded.
//!
int ARCOpen(const rvlArchive* self, const char* path, rvlArchiveFile* pOut);

//! @brief Open a file handle from an archive.
//!
//! @param[in]  self The archive.
//! @param[in]  path Direct entry handle, from rvlArchiveResolve.
//! @param[out] pOut Pointer to an rvlArchiveFile to fill in.
//!
//! @return If the operation succeeded.
//!
int ARCFastOpen(const rvlArchive* self, rvlArchiveEntryHandle path,
                rvlArchiveFile* pOut);

//! @brief Get the file data from a file handle.
//!
//! @param[in] self Pointer to a file.
//!
//! @return A pointer to the beginning of the file data buffer.
//!
void* ARCGetStartAddrInMem(rvlArchiveFile* self);

//! @brief Get the address translation of an archive subfile.
//!
//! @param[in] self Pointer to a file.
//!
//! @return The number of bytes in the archive file until the subfile begins.
//!
s32 ARCGetStartOffset(const rvlArchiveFile* self);

//! @brief Get the filesize of a file handle.
//!
//! @param[in] self Pointer to a file.
//!
//! @return The size of the file data buffer, in bytes.
//!
u32 ARCGetLength(const rvlArchiveFile* self);

//! @brief Close a file handle.
//!
//! @param[in] self Pointer to a file.
//!
//! @return If the operation succeeded.
//!
bool ARCClose(rvlArchiveFile* self);

//! @brief Get an iterable range of the recursive contents of a folder.
//!
//! @param[in]  self Pointer to an archive.
//! @param[in]  path Folder path.
//! @param[out] pOut A folder range to fill in.
//!
//! @return If the operation succeeded:
//!         - 1) The path exists and
//!         - 2) is not a file.
//!
bool ARCOpenDir(const rvlArchive* self, const char* path,
                rvlArchiveFolderRange* pOut);

//! @brief Retrieve the next element in the iterator.
//!
//! @param[in]  self The folder range.
//! @param[out] pOut The archive entry to fill in.
//!
//! @return False if the iterator has been exhausted.
//!
bool ARCReadDir(rvlArchiveFolderRange* self, rvlArchiveEntry* pOut);

//! @brief Close the folder range handle.
//!
//! @param[in] self The folder range.
//!
//! @return If the operation succeeded.
//!
bool ARCCloseDir(rvlArchiveFolderRange* self);

#ifdef __cplusplus
}
#endif
/* end "rvl/arc/rvlArchive.h" */

namespace EGG {

struct LowArchive : public rvlArchive {
  inline void reset() { memset(this, 0, sizeof(*this)); }
  inline bool open(rvlArchiveEntryHandle path, rvlArchiveFile& file) {
    return ARCFastOpen(this, path, &file);
  }
  inline bool open(const char* path, rvlArchiveFile& file) {
    return ARCOpen(this, path, &file);
  }
};

class Archive : public Disposer // sizeof=60,0x3C
{
public:
  struct FileInfo {
    u32 startOffset;
    u32 length;
  };

  //! Initialize the wrapped ARC handle from the start address pointer
  //! member.
  u32 initHandle(void* pArcStart) {
    // Here for now (since we don't have deadstripping)
    {
      EGG_ASSERT(pArcStart, "eggArchive.cpp", 61,
                 "arcBinary != NULL"); // from later inline
      return ARCInitHandle(pArcStart, &this->mArcHandle);
    }
  }

  //! @brief Find the EGG Archive wrapping the ARC file starting at pArchive.
  //! @remarks Always inlined.
  //!
  static Archive* findArchive(void* key) {
    // Here for now (since we don't have deadstripping)
    {
      Archive* found = NULL;
      if (isArchiveListInitialized()) {
        Archive* iterArchive = NULL;
        while ((iterArchive = (Archive*)nw4r::ut::List_GetNext(&sArchiveList,
                                                               iterArchive))) {
          if (iterArchive->mArcHandle.mHeader == key) {
            found = iterArchive;
            break;
          }
        }
      }
      return found;
    }
  }

  //! @brief Mount an archive.
  //! @details If the archive is already mounted, it will be used.
  //! @returns A pointed to the mounted EGG Archive if successful. Otherwise,
  //! NULL.
  //!
  static Archive* mount(void* pArcStart, Heap* pHeap, int align);

  //! @brief Exact same as @see mount, except the status will be set such that
  //! fast get attemps fail.
  //!
  static Archive* mountNoFastGet(void* pArcStart, Heap* pHeap, int align);

  //! @brief Unmount an archive. (Set the status as NOT_LOADED and decrease
  //! refcount)
  //!
  void unmount();

  //! @brief Convert the path to an ARC entry ID.
  int convertPathToEntryID(const char* path);
  void* getFileFast(int entryNum, FileInfo* pInfo);
  void getFile(const char* path, FileInfo* pInfo);
  // read arc file from disc
  static void* loadFromDisc(const char* path, Heap* pHeap, int align);

private:
  static bool sIsArchiveListInitialized;
  static nw4r::ut::List sArchiveList;

  static inline bool isArchiveListInitialized() {
    return sIsArchiveListInitialized;
  }

  Archive() {
    mRefCount = 1;
    mStatus = NOT_LOADED;
    mArcHandle.reset();
    if (!sIsArchiveListInitialized) {
      nw4r::ut::List_Init(&sArchiveList, offsetof(Archive, mLink));
      sIsArchiveListInitialized = true;
    }
    appendList(this);
  }
  inline Archive(const Archive&) {}
  virtual ~Archive() override; //!< [vt+0x00]

  //! @brief   Append an archive to the static archive list.
  //! @remarks Always inlined.
  //!
  static void appendList(Archive* pArchive) {
    nw4r::ut::List_Append(&sArchiveList, pArchive);
  }
  //! @brief Remove an archive to the static archive list.
  //!
  static void removeList(Archive* pArchive);

  enum Status {
    NOT_LOADED,               //!< [0]
    LOADED_AND_CAN_FAST_READ, //!< [1]
    LOADED //!< [2] Just going by behavior, fast read can only proceed when set
           //!< to 1.
  };
  Status mStatus;        //!< [+0x10] set to 0 in ct
  int mRefCount;         //!< [+0x14] set to 1 in ct
  LowArchive mArcHandle; // 0x18

  nw4r::ut::Node mLink;
};

} // namespace EGG
/* end "egg/core/eggArchive.hpp" */
/* "src\system\DvdArchive.hpp" line 5 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */

namespace System {
enum ArchiveState {
  DVD_ARCHIVE_STATE_CLEARED = 0,
  DVD_ARCHIVE_STATE_RIPPED = 2,
  DVD_ARCHIVE_STATE_DECOMPRESSED = 3,
  DVD_ARCHIVE_STATE_MOUNTED = 4,
  DVD_ARCHIVE_STATE_UNKN5 = 5
};

class DvdArchive {
  friend class MultiDvdArchive;
  friend class ResourceManager;

public:
  DvdArchive();
  virtual ~DvdArchive();

  void mount(EGG::Heap* archiveHeap);
  void load(const char* path, EGG::Heap* archiveHeap, bool isCompressed,
            s32 align, EGG::Heap* fileHeap, u32 param_6);
  void load(const char* path, u32 _unused, EGG::Heap* archiveHeap);
  void loadBuffer(void* fileStart, u32 fileSize, EGG::Heap* archiveHeap,
                  s32 param_4);
  void* getFileCopy(char* filename, EGG::Heap* heap, size_t* size, s8 param_4);
  void ripFile(const char* path, EGG::Heap* fileHeap, u8 align);
  bool tryRipFile(const char* path, EGG::Heap* fileHeap, s8 align);
  void clear();
  void unmount();
  void clearArchive();
  void clearFile();
  void* getFile(const char* filename, size_t* size);
  void decompress(const char* path, EGG::Heap* archiveHeap, u32 _unused);
  void move();
  void loadOther(const DvdArchive* other, EGG::Heap* heap);

  bool isLoaded() const {
    return mStatus == DVD_ARCHIVE_STATE_MOUNTED ||
           mStatus == DVD_ARCHIVE_STATE_UNKN5;
  }
  bool isRipped() const { return mStatus == DVD_ARCHIVE_STATE_RIPPED; }

private:
  void _UNKNOWN();
  void _UNKNOWN2(int, u8* p);
  void _UNKNOWN3();

  void* getArchiveEnd() const {
    return (void*)(mArchiveSize + (u32)mArchiveStart);
  }

  EGG::Archive* mArchive;
  void* mArchiveStart;
  u32 mArchiveSize;
  EGG::Heap* mArchiveHeap;
  void* mFileStart;
  u32 mFileSize;
  EGG::Heap* mFileHeap;
  volatile ArchiveState mStatus;
};

} // namespace System
/* end "system/DvdArchive.hpp" */
/* "src\system\ResourceManager.hpp" line 10 "system/LocalizedArchive.hpp" */
#pragma once

/* "src\system\LocalizedArchive.hpp" line 2 "MultiDvdArchive.hpp" */
#pragma once

/* "src\system\MultiDvdArchive.hpp" line 2 "DvdArchive.hpp" */
/* end "DvdArchive.hpp" */
/* "src\system\MultiDvdArchive.hpp" line 3 "host_system/SystemManager.hpp" */
/*!
 * @file
 * @brief System Manager
 */
#pragma once

/* "src\host_system\SystemManager.hpp" line 6 "rk_types.h" */
/* end "rk_types.h" */
/* "src\host_system\SystemManager.hpp" line 7 "rvl/os/os.h" */
/* end "rvl/os/os.h" */
/* "src\host_system\SystemManager.hpp" line 8 "rvl/os/osLink.h" */
#pragma once

/* "lib\rvl\os\osLink.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\os\osLink.h" line 4 "decomp.h" */
/* end "decomp.h" */

#ifdef __cplusplus
extern "C" {
#endif

typedef struct OSModuleInfo OSModuleInfo;

typedef struct OSModuleLink {
  OSModuleInfo* succ;
  OSModuleInfo* pred;
} OSModuleLink;

typedef struct OSModuleQueue {
  OSModuleInfo* head;
  OSModuleInfo* tail;
} OSModuleQueue;

struct OSModuleInfo {
  u32 id;
  OSModuleLink head;
  u32 sections;
  u32 sectionInfoOffset;
  u32 nameOffset;
  u32 nameLen;
  u32 version;
};

typedef struct OSModuleHeader {
  OSModuleInfo info;
  u32 bssSize;
  u32 relOffset;
  u32 impOffset;
  u32 impSize;
  u8 prologSection;
  u8 epilogSection;
  u8 unresolvedSection;
  u8 bssSection;
  u32 prolog;
  u32 epilog;
  u32 unresolved;
  u32 align;
  u32 bssAlign;
  u32 fixSize;
} OSModuleHeader;

void OSNotifyLink(OSModuleInfo*);
void OSNotifyPreLink(OSModuleInfo*);
void OSNotifyPostLink(OSModuleHeader*, OSModuleHeader*);
int Relocate(OSModuleHeader*, OSModuleHeader*);
int Link(OSModuleInfo* info, void* bss, int fixed);
int OSLink(OSModuleInfo* info, void* bss);
void __OSModuleInit(void);

#ifdef __cplusplus
}
#endif
/* end "rvl/os/osLink.h" */

/* "src\host_system\SystemManager.hpp" line 10 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */
/* "src\host_system\SystemManager.hpp" line 11 "egg/core/eggTaskThread.hpp" */
/*!
 * @file
 * @brief TODO.
 */

#pragma once

/* "lib\egg\core\eggTaskThread.hpp" line 7 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */
/* "lib\egg\core\eggTaskThread.hpp" line 8 "egg/core/eggThread.hpp" */
/* end "egg/core/eggThread.hpp" */

/* "lib\egg\core\eggTaskThread.hpp" line 10 "rk_types.h" */
/* end "rk_types.h" */

namespace EGG {

class TaskThread : public Thread {
public:
  typedef void (*TFunction)(void*);

  static TaskThread* create(int msgCount, int prio, u32 stackSize, Heap* heap);

  struct TJob {
    TFunction mMainFunction;
    void* mArg;
    void* mTaskEndMessage;
    TFunction mEnterFunction;
    TFunction mExitFunction;
    TFunction mCallbackFunction;

    TJob();

    inline void clearFunctions() {
      mMainFunction = nullptr;
      mEnterFunction = nullptr;
      mExitFunction = nullptr;
      mCallbackFunction = nullptr;
    }
  };

  void destroy();
  bool request(TFunction mainFunction, void* arg, void* _08);
  bool isTaskExist() const;

  // Thread overrides
  ~TaskThread() override;
  void onEnter() override;
  void onExit() override;
  void* run() override;

  //! @brief Create a task thread and resume current thread
  //!
  TaskThread(int msgCount, int prio, u32 stackSize);
  TJob* findBlank();

  TJob* mCurrentJob;
  TJob* mJobs;
  s32 mJobCount;
  OSMessageQueue* mTaskEndMessageQueue;
};

} // namespace EGG
/* end "egg/core/eggTaskThread.hpp" */

namespace System {

class SystemManager // sizeof=4352, vt at 0x54
{
public:
  static SystemManager* sInstance;

  struct SystemRipper {
    u8 mPathBuf[64]; //!< [+0x00] Buffer for the ripped path to placed in.
    EGG::Heap* pDvdRipperHeap; //!< [+0x40] Heap to use for DVD ripper methods.
    bool bTopAllocDir; //!< [+0x44] if true? allocDir=1(ALLOC_DIR_TOP)negative :
                       //!< allocDir=2(ALLOC_DIR_BOTTOM)positive
    u32* mRippedFileSizeOutput;  //!< [+0x48] Output filesize pointer for ripped
                                 //!< file.
    u8* pManualRipperDestBuffer; //!< [+0x4C] Used if pDvdRipperHeap is NULL as
                                 //!< the destination buffer.
    u8* mRippedDestBuf; //!< [+0x50] Used as dest buffer in read function.
  } mSystemRipper;

  //! @brief		Initialize the static instance for the system manager.
  //!
  //! @param[in]	pHeap Heap for the new instance to use.
  //!
  //! @return		Pointer to the new system manager.
  //!
  static SystemManager* initStaticInstance(EGG::Heap* PHeap);

  //! @brief [vt(+0x54)+0x08] Destroy the system manager.
  //!
  virtual ~SystemManager();

  SystemManager(EGG::Heap* heap);
  void NDEVArgParse();
  void LoadSymbols(OSModuleInfo* osmoduleinfo);
  void setupSystem(EGG::Heap* heap);

  //! @brief Properly shutdown the Wii.
  void shutdownSystem();

  //! @brief Properly return to the Wii main menu.
  //!
  void returnToMenu();

  //! @brief Properly restart the Wii.
  //!
  void restart();

  void setSystemPowerCallbacks(); // disable doRestart and doShutdown and set
                                  // Power / Reset callbacks

  void handlePowerState();           // handle doShutdown and doRestart
  const char* getRegionCode() const; // For this build, return 'RMCP'
  u32 sanitizeGameIDRegion(u32 gameName) const;

  // TODO
  u8* ripFromDiscAsync(const char path[64], EGG::Heap* heap, bool allocTop,
                       u32* fsizeOutput, u8* dst);
  u8* ripFromDisc(const char path[64], EGG::Heap* heap, bool allocTop,
                  u32* fsizeOutput, u8* dst);

  //! @brief Processes a rip request (used as function for ripping task thread)
  //!
  //! @details
  //!		If pDvdRipperHeap is set, the EGG::DvdRipper will create a
  //! buffer form the heap. The allocation direction is contrlled by
  //! bTopAllocDir. 		Otherwise, pManualRipperDestBuffer will be used.
  //!
  //! @post If set, the value pointed to by mRippedFileSizeOutput will be set.
  //!
  //! @return A pointer to the ripped file in memory.
  //!
  // Internal
  // static void* processRipRequest();

  //! @brief
  static u8* ripFromDisc(const char path[64], EGG::Heap* heap, bool allocTop,
                         u32* fsizeOutput);
  static u8* ripFromDisc(const char path[64], u8* dst, u32* fsizeOutput);
  static bool isPal50();

  //! @brief Stop the motors of all controllers on all channels.
  //!
  static void stopAllControllerMotors();

  u32 mAspectRatio;      //!< [+0x58] 1 - 16x9
  u32 mLanguage;         //!< [+0x5C] True language?
  u32 mResourceLanguage; //!< [+0x60] Same as above, but Dutch -> English
  u32 mProgressiveMode;  //!< [+0x64] 1 - on
  u32 mEuRgb60Mode;      //!< [+0x68] 1 - EURGB60
  int mb50Fps; //!< [+0x6C] Name is really a GUESS. An int. Possible some vi
               //!< type? PAL and EURGB set it to true but it's already true. So
               //!< possibly isEuro too?
  u32 mLaunchType; //!< [+0x70] Determiined by launch/return code

  f32 mFps60;       // 74 set 59.94f in CT
  f32 mFpsCurrent;  // 78 set 59.94f in CT, though always to 50 here?
  f32 mFrameSize60; // 0x7C for 60fps: 16.68335f (1000/59.94)

  bool bIsNdev; //!< [+0x80]
  // 81 unseen. pad?
  u16 _82;           // determined by return/launchcode
  u32 mMatchingArea; //!< [+0x84] set 15 in ct. everywhere: 2; australia/new
                     //!< zealand: 3
  u8* buf_88;        //!< [+0x88] 32 bytes
  u8* buf_8C;        //!< [+0x8C] 32 bytes
  u8* buf_90;        //!< [+0x90] 32 bytes

  u32 _94;
  char* pNdevArgument;  //!< [+0x98] first argument when loaded from ndev @see
                        //!< NDEVArgParse max size 48
  u32 mStaticTextStart; // 9C
  u32 mStaticTextEnd;   // A0 8038917C
  u32 mStaticTextSize;  // A4 8038917C - 0x80004000
  u32 _A8;
  EGG::Heap* mHeap; //!< [+0xAC] arg of ct. maybe another so name for now
  OSModuleInfo* _B0;
  bool doShutDown; //!< [+0xB4] If true, system will shut down in next
                   //!< handlePowerState()
  bool doRestart;  //!< [+0xB5] If true, system will restart in next
                   //!< handlePowerState()
  bool _B6;        // 0 in ct
  bool _B7; // if it's not enabled, power/reset callbacks won't shut down system

  OSMessageQueue _B8;           //!< [+0xB8] sizeof=0x20
  OSMessage _D8[4];             //!< [+0xD8]
  EGG::TaskThread* mTaskThread; //!< [+0xE8]
  OSThread* pCreatedInThread;   //!< [+0xEC] zeroed then OSGetThread() in ct

  u8 mYear;       //!< [+0xF0] clamped to 99 in ct
  u8 mMonth;      //!< [+0xF1] clamped to 12 in ct
  u8 mDayOfMonth; //!< [+0xF2] clamped to 31 in ct
  u8 _F3;         // 0 in ct
  u8 _F4;         // 0 in ct
  struct {
    s32 ID; // F8
    u8 unk[0x10fc - 4];
    u16 mLatitude;  // 10FC
    u16 mLongitude; // 10FE

    //! @brief	The check for region has to be in this function, as codwarrior
    //! doesn't optimize this as much as it would had
    //!			the comparison been outside.
    inline bool isRegion(s32 region) const {
#ifdef NTSCJ
      if (ID != -1)
        return ID >> 24 == region;
      return -1;
#else
      return ID == -1 ? 0 : ID >> 24 == region;
#endif
    }
  } mSimpleAddressData; // F8 -> 1100
};

} // namespace System
/* end "host_system/SystemManager.hpp" */

/* "src\system\MultiDvdArchive.hpp" line 5 "rk_types.h" */
/* end "rk_types.h" */
/* "src\system\MultiDvdArchive.hpp" line 6 "rvl/dvd/dvd.h" */
#pragma once

/* "lib\rvl\dvd\dvd.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\dvd\dvd.h" line 4 "decomp.h" */
/* end "decomp.h" */

#ifdef __cplusplus
extern "C" {
#endif

typedef struct DVDCommandBlock DVDCommandBlock;
typedef struct DVDFileInfo DVDFileInfo;

typedef void (*DVDAsyncCallback)(s32, DVDFileInfo*);
typedef void (*DVDCBAsyncCallback)(s32, DVDCommandBlock*);

typedef struct DVDDiskID {
  char gameName[4];
  char company[2];
  u8 diskNumber;
  u8 gameVersion;
  u8 streaming;
  u8 streamingBufSize;
  u8 padding[14];
  u32 rvlMagic;
  u32 gcMagic;
} DVDDiskID;

typedef struct DVDCommandBlock {
  DVDCommandBlock* next;
  DVDCommandBlock* prev;
  u32 command;
  s32 state;
  u32 offset;
  u32 length;
  void* addr;
  u32 currTransferSize;
  u32 transferredSize;
  DVDDiskID* id;
  DVDCBAsyncCallback callback;
  void* userData;
} DVDCommandBlock;

typedef struct DVDFileInfo {
  DVDCommandBlock cb;
  u32 startAddr;
  u32 length;
  DVDAsyncCallback callback;
} DVDFileInfo;


s32 DVDConvertPathToEntrynum(const char*);

#define DVD_RESULT_CANCELED -3

void dvd_StampCommand();
void dvd_defaultOptionalCommandChecker();
void DVDInit();
void dvd_stateReadingFST();
void cbForStateReadingFST();
void dvd_cbForStateError();
void dvd_cbForStoreErrorCode2();
void unk_8015efd0();
void dvd_cbForStoreErrorCode3();
void dvd_cbForStateGettingError();
void dvd_cbForUnrecoveredError();
void dvd_cbForUnrecoveredErrorRetry();
void dvd_cbForStateGoToRetry();
void dvd_stateCheckID();
void dvd_cbForStateReadingTOC();
void dvd_cbForStateReadingPartitionInfo();
void dvd_cbForStateOpenPartition();
void dvd_cbForStateOpenPartition2();
void dvd_cbForStateCheckID1();
void dvd_cbForStateCheckID2();
void dvd_stateCoverClosed();
void dvd_ResetAlarmHandler();
void dvd_cbForStateReset();
void dvd_stateDownRotation();
void dvd_cbForStateDownRotation();
void dvd_stateCoverClosed_CMD();
void dvd_cbForStateCoverClosed();
void dvd_cbForPrepareCoverRegister();
void stateReady();
void stateBusy();
void dvd_cbForStateBusy();
void DVDReadAbsAsyncPrio();
void DVDInquiryAsync();
s32 DVDGetCommandBlockStatus(DVDCommandBlock*);
void DVDGetDriveStatus();
void DVDSetAutoInvalidation();
void DVDPause();
void DVDResume();
u32 DVDCancelAsync(DVDFileInfo*, DVDCBAsyncCallback);
u32 DVDCancel(DVDFileInfo*);
s32 DVDCancelAll(void);
void DVDGetCurrentDiskID();
void __BS2DVDLowCallback();
void __DVDGetCoverStatus();
void __DVDResetWithNoSpinup();
void __DVDPrepareResetAsync();
void __DVDPrepareReset();
void __DVDTestAlarm();
void __DVDStopMotorAsync();

#define DVDRead(fileInfo, addr, length, offset)                                \
  DVDReadPrio((fileInfo), (addr), (length), (offset), 2)
#define DVDGetFileInfoStatus(fileinfo) DVDGetCommandBlockStatus(&(fileinfo)->cb)
#define DVD_RESULT_CANCELED -3


#ifdef __cplusplus
}
#endif
/* end "rvl/dvd/dvd.h" */

namespace System {

enum ResourceChannelID {
  RES_CHAN_RACE_SYS, //!< [0] Localized: /Race/Common.szs and such
  RES_CHAN_COURSE,   //!< [1] Diff'd: Track file
  RES_CHAN_UI,       //!< [2] Localized: 2D UI
  RES_CHAN_FONT,     //!< [3] Fonts
  RES_CHAN_EARTH,    //!< [4] Globe (Async LZ)
  RES_CHAN_MII,      //!< [5] Mii Parts
  RES_CHAN_DRIVER,   //!< [6] Driver
  RES_CHAN_DEMO,     //!< [7] Cutscenes
  RES_CHAN_UI_MODEL, //!< [8] BackModel et al

  RES_CHAN_NUM
};

enum EResourceKind {
  RES_KIND_FILE_DOUBLE_FORMAT, // 0 %s%s Supports prefix
  RES_KIND_FILE_SINGLE_FORMAT, // 1 %s
  RES_KIND_BUFFER,             // 2
  RES_KIND_3,                  // unseen
  RES_KIND_4,                  // _Dif loader

  RES_KIND_DEFAULT = RES_KIND_FILE_DOUBLE_FORMAT
};

class MultiDvdArchive {
  friend class ResourceManager;

public:
  MultiDvdArchive(u16 archiveCount = 1);
  virtual ~MultiDvdArchive();

  virtual void init();
  void clear();

  bool exists(const char* name);
  void* getFile(const char* filename, size_t* size);
  void unmount();
  void rip(const char* name, EGG::Heap* heap);
  void load(const char* filename, EGG::Heap* archiveHeap, EGG::Heap* fileHeap,
            unk32 param_5);
  void loadOther(MultiDvdArchive* other, EGG::Heap* heap);
  bool isLoaded();

  int totalArchiveSize();
  u16 rippedArchiveCount();

protected:
  void* getEarliestResBufInMem();
  void* getFarthestResBufInMem();

  enum { SUFFIX_SIZE = 128 };
  DvdArchive* archives;
  u16 archiveCount;
  u32* fileSizes;
  char** suffixes;
  void** fileStarts;
  EResourceKind* kinds;
};

} // namespace System
/* end "MultiDvdArchive.hpp" */

namespace System {

MultiDvdArchive* createMultiDvdArchive(ResourceChannelID kind);

class CourseDvdArchive : public MultiDvdArchive {
public:
  CourseDvdArchive();
  void init() override;
};

class UIDvdArchive : public MultiDvdArchive {
public:
  UIDvdArchive();
  void init() override;
};

class RaceSysDvdArchive : public MultiDvdArchive {
public:
  RaceSysDvdArchive();
  void init() override;
};

} // namespace System
/* end "system/LocalizedArchive.hpp" */
/* "src\system\ResourceManager.hpp" line 11 "system/MultiDvdArchive.hpp" */
/* end "system/MultiDvdArchive.hpp" */
/* "src\system\ResourceManager.hpp" line 12 "system/GhostFile.hpp" */
#pragma once

/* "src\system\GhostFile.hpp" line 2 "system/Mii.hpp" */
#pragma once

/* "src\system\Mii.hpp" line 2 "string.h" */
/* end "string.h" */

/* "src\system\Mii.hpp" line 4 "rk_types.h" */
/* end "rk_types.h" */

namespace System {

class RawMii {
public:
  void reset() { memset(mBuffer, 0, sizeof(mBuffer)); }

private:
  u8 mBuffer[0x4c];
};

struct unkStruct {
  u8 x0;
  u8 x1;
  u8 x2;
  u8 x3;
};

struct MiiId {
  u8 _00[0x8 - 0x0];
};

class Mii {
public:
  Mii(s32 num) { init(num); }
  virtual ~Mii();
  void init(s32);
  s32 _4;
  u8 _8;
  s8 _9;
  s32 _C;
  RawMii mRaw;
  s32 _5C;
  unkStruct _60;
  u32 _64;
  u32 _68[15];
  u8 _A4;
  u8 _A5;
  u8 _A6;
  u32 _A8;
  u8 _AC;
  u8 _AD;
  u8 _AE;
  u32 _B0;
  u32 _B4;
};

inline Mii::~Mii() {}

} // namespace System
/* end "system/Mii.hpp" */

/* "src\system\GhostFile.hpp" line 4 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */

/* "src\system\GhostFile.hpp" line 6 "rk_types.h" */
/* end "rk_types.h" */

namespace System {

class Time {
public:
  Time();

#pragma warn_unusedvar on
  virtual ~Time() { u8 i; } // Trust me bro
#pragma warn_unusedvar off

  u16 getClampedMinutes() const {
    if (mMinutes > 99) {
      return 99;
    }

    return mMinutes;
  }

  u16 getClampedSeconds() const {
    if (mMinutes > 99) {
      return 59;
    }

    return mSeconds;
  }

  u16 getClampedMilliseconds() const {
    if (mMinutes > 99) {
      return 999;
    }

    return mMilliseconds;
  }

  void setIsValid(bool isValid) { mIsValid = isValid; }

  void set(u16 minutes, u8 seconds, u16 milliseconds, bool isValid = true) {
    mIsValid = isValid;
    mMinutes = minutes;
    mSeconds = seconds;
    mMilliseconds = milliseconds;
  }
  void set2(u16 minutes, u8 seconds, u16 milliseconds, bool isValid) {
    mMinutes = minutes;
    mSeconds = seconds;
    mMilliseconds = milliseconds;
    mIsValid = isValid;
  }

private:
  u16 mMinutes;
  u8 mSeconds;
  u16 mMilliseconds;
  bool mIsValid;
};

class Date {
public:
  Date() {
    mIsValid = false;

    clamp();

    mYear = 0;
    mMonth = 0;
    mDay = 0;
  }

  void set(u8 year, u8 month, u8 day) {
    mIsValid = true;

    clamp();

    mYear = year;
    mMonth = month;
    mDay = day;
  }

  u8 getYear() const { return mYear; }

  u8 getMonth() const { return mMonth; }

  u8 getDay() const { return mDay; }

private:
  void clamp() {
    if (mYear > 99) {
      mYear = 99;
    }

    if (mMonth > 12) {
      mMonth = 12;
    }

    if (mDay > 31) {
      mDay = 31;
    }
  }

  u8 mYear;
  u8 mMonth;
  u8 mDay;
  bool mIsValid;
};

MW_PRAG_PACKED
struct RawGhostFile {
  friend class GhostFile;

public:
  // RawGhostFile() { reset(); }

  //~RawGhostFile() {}

  void reset();

  bool isHeaderValid() const;

  bool isValid() const;

  static bool compress(const RawGhostFile& src, RawGhostFile& dst);

  static bool decompress(const RawGhostFile& src, RawGhostFile& dst);

  u32 getSize() const;

private:
  void updateCrc32Uncompressed();

  union {
    u8 buffer[0x2800];
    struct {
      u32 fourcc;

      u32 raceMinutes : 7;
      u32 raceSeconds : 7;
      u32 raceMilliseconds : 10;
      u32 courseId : 6;
      u32 _pad0 : 2;

      u32 vehicleId : 6;
      u32 characterId : 6;
      u32 year : 7;
      u32 month : 4;
      u32 day : 5;
      u32 controllerId : 4;

      u16 _pad1 : 4;
      u16 isCompressed : 1;
      u16 _pad2 : 2;
      u16 type : 7;
      u16 driftIsAuto : 1;
      u16 _pad3 : 1;

      u16 inputsSize;
      u8 lapCount;
      struct {
        u32 minutes : 7;
        u32 seconds : 7;
        u32 milliseconds : 10;
      } lapTimes[5];
      wchar_t userData[10];
      u32 location;
      u32 _38;
      RawMii mii;

      u32 compressedInputsSize;
    };
  };
};
MW_PRAG_END

class GhostFile {
  friend class GhostFileGroup;

public:
  GhostFile();

  GhostFile(const RawGhostFile& raw);

  bool read(const RawGhostFile& raw);

  bool writeHeaderUncompressed(RawGhostFile& raw) const;

  bool writeUncompressed(RawGhostFile& raw) const;

  void init(u8 playerId);

  bool isValid() const { return mHeaderIsValid; }

  void invalidate() { mHeaderIsValid = false; }

  u8 getLapCount() const { return mLapCount; }

private:
  void reset();

  bool readHeader_thunk(const RawGhostFile& raw); // Unused

  bool readHeader(const RawGhostFile& raw);

  void writeHeader(RawGhostFile& raw) const;

public:
  bool mHeaderIsValid;
  wchar_t mUserData[11];
  RawMii mMii;
  u8 mLapCount;
  Time mLapTimes[5];
  Time mRaceTime;
  u32 mCharacterId;
  u32 mVehicleId;
  s32 mCourseId;
  u32 mControllerId;
  Date mDate;
  u32 mType;
  bool mDriftIsAuto;
  u32 mLocation;
  u32 mInputsSize;
  const u8* mInputs;
};

class GhostFileGroup {
public:
  enum GhostGroupType {
    GHOST_GROUP_TYPE_SAVED = 0x0,
    GHOST_GROUP_TYPE_DOWNLOADED = 0x1,
    GHOST_GROUP_TYPE_SLOW_STAFF = 0x2,
    GHOST_GROUP_TYPE_FAST_STAFF = 0x3,
    GHOST_GROUP_TYPE_GHOST_RACE = 0x4,
    GHOST_GROUP_TYPE_COMPETITION = 0x5
  };

  GhostFileGroup(EGG::Heap* heap, s32 type);

  virtual ~GhostFileGroup();

  void invalidate(u16 idx);

  GhostFile* get(u16 idx);

  void readHeader(u16 idx, const RawGhostFile& raw);

private:
  u16 mCount;
  s32 mType;
  GhostFile* mFiles;
  bool* _10;
};

} // namespace System
/* end "system/GhostFile.hpp" */

namespace System {

struct JobContext {
  MultiDvdArchive* mpMultiArchive;
  DvdArchive* mpArchive;
  unk _08;
  char mFilename[64];
  EGG::Heap* mpArchiveHeap;
  EGG::Heap* mpFileHeap;
};

// Enums that represent indices in vehicle name specifiers arrays.
typedef enum {
  MARIO = 0x0,
  BABY_PEACH = 0x1,
  WALUIGI = 0x2,
  BOWSER = 0x3,
  BABY_DAISY = 0x4,
  DRY_BONES = 0x5,
  BABY_MARIO = 0x6,
  LUIGI = 0x7,
  TOAD = 0x8,
  DONKEY_KONG = 0x9,
  YOSHI = 0xA,
  WARIO = 0xB,
  BABY_LUIGI = 0xC,
  TOADETTE = 0xD,
  KOOPA_TROOPA = 0xE,
  DAISY = 0xF,
  PEACH = 0x10,
  BIRDO = 0x11,
  DIDDY_KONG = 0x12,
  KING_BOO = 0x13,
  BOWSER_JR = 0x14,
  DRY_BOWSER = 0x15,
  FUNKY_KONG = 0x16,
  ROSALINA = 0x17,
  MII_S_A_MALE = 0x18,
  MII_S_A_FEMALE = 0x19,
  MII_S_B_MALE = 0x1A,
  MII_S_B_FEMALE = 0x1B,
  MII_S_C_MALE = 0x1C,
  MII_S_C_FEMALE = 0x1D,
  MII_M_A_MALE = 0x1E,
  MII_M_A_FEMALE = 0x1F,
  MII_M_B_MALE = 0x20,
  MII_M_B_FEMALE = 0x21,
  MII_M_C_MALE = 0x22,
  MII_M_C_FEMALE = 0x23,
  MII_L_A_MALE = 0x24,
  MII_L_A_FEMALE = 0x25,
  MII_L_B_MALE = 0x26,
  MII_L_B_FEMALE = 0x27,
  MII_L_C_MALE = 0x28,
  MII_L_C_FEMALE = 0x29,
  MII_M = 0x2A,
  MII_S = 0x2B,
  MII_L = 0x2C,
  PEACH_BIKER = 0x2D,
  DAISY_BIKER = 0x2E,
  ROSALINA_BIKER = 0x2F
} CharacterId;

typedef enum {
  STANDARD_KART_S = 0x0,
  STANDARD_KART_M = 0x1,
  STANDARD_KART_L = 0x2,
  BABY_BOOSTER = 0x3,
  CLASSIC_DRAGSTER = 0x4,
  OFFROADER = 0x5,
  MINI_BEAST = 0x6,
  WILD_WING = 0x7,
  FLAME_FLYER = 0x8,
  CHEEP_CHARGER = 0x9,
  SUPER_BLOOPER = 0xA,
  PIRANHA_PROWLER = 0xB,
  RALLY_ROMPER = 0xC,
  ROYAL_RACER = 0xD,
  JETSETTER = 0xE,
  BLUE_FALCON = 0xF,
  SPRINTER = 0x10,
  HONEYCOUPE = 0x11,
  STANDARD_BIKE_S = 0x12,
  STANDARD_BIKE_M = 0x13,
  STANDARD_BIKE_L = 0x14,
  BULLET_BIKE = 0x15,
  MACH_BIKE = 0x16,
  BOWSER_BIKE = 0x17,
  BIT_BIKE = 0x18,
  BON_BON = 0x19,
  WARIO_BIKE = 0x1A,
  QUACKER = 0x1B,
  RAPIDE = 0x1C,
  SHOOTING_STAR = 0x1D,
  MAGIKRUISER = 0x1E,
  NITROCYCLE = 0x1F,
  SPEAR = 0x20,
  JET_BUBBLE = 0x21,
  DOLPHIN_DASHER = 0x22,
  PHANTOM = 0x23
} VehicleId;

// name of battle mode team
typedef enum {
  BATTLE_TEAM_RED = 0,
  BATTLE_TEAM_BLUE = 1,
  BATTLE_TEAM_NONE = 2 // not in battle mode
} BattleTeam;

// single player/number of multiplayer
typedef enum {
  PLAYER_MODE_FOUR = 0,
  PLAYER_MODE_TWO = 1,
  PLAYER_MODE_SINGLE = 2
} PlayMode;

typedef enum {
  // Race courses

  // Nitro tracks
  MARIO_CIRCUIT = 0x0,
  MOO_MOO_MEADOWS = 0x1,
  MUSHROOM_GORGE = 0x2,
  GRUMBLE_VOLCANO = 0x3,
  TOADS_FACTORY = 0x4,
  COCONUT_MALL = 0x5,
  DK_SUMMIT = 0x6, // "snowboard cross" enjoyers punching air
  WARIOS_GOLD_MINE = 0x7,
  LUIGI_CIRCUIT = 0x8,
  DAISY_CIRCUIT = 0x9,
  MOONVIEW_HIGHWAY = 0xA,
  MAPLE_TREEWAY = 0xB,
  BOWSERS_CASTLE = 0xC,
  RAINBOW_ROAD = 0xD,
  DRY_DRY_RUINS = 0xE,
  KOOPA_CAPE = 0xF,

  // Retro tracks
  GCN_PEACH_BEACH = 0x10,
  GCN_MARIO_CIRCUIT = 0x11,
  GCN_WALUIGI_STADIUM = 0x12,
  GCN_DK_MOUNTAIN = 0x13,
  DS_YOSHI_FALLS = 0x14,
  DS_DESERT_HILLS = 0x15,
  DS_PEACH_GARDENS = 0x16,
  DS_DELFINO_SQUARE = 0x17,
  SNES_MARIO_CIRCUIT_3 = 0x18,
  SNES_GHOST_VALLEY_2 = 0x19,
  N64_MARIO_RACEWAY = 0x1A,
  N64_SHERBET_LAND = 0x1B,
  N64_BOWSERS_CASTLE = 0x1C,
  N64_DKS_JUNGLE_PARKWAY = 0x1D,
  GBA_BOWSER_CASTLE_3 = 0x1E,
  GBA_SHY_GUY_BEACH = 0x1F,

  // Battle courses
  DELFINO_PIER = 0x20,
  BLOCK_PLAZA = 0x21,
  CHAIN_CHOMP_ROULETTE = 0x22,
  FUNKY_STADIUM = 0x23,
  THWOMP_DESERT = 0x24,
  GCN_COOKIE_LAND = 0x25,
  DS_TWILIGHT_HOUSE = 0x26,
  SNES_BATTLE_COURSE_4 = 0x27,
  GBA_BATTLE_COURSE_3 = 0x28,
  N64_SKYSCRAPER = 0x29,

  // Other courses
  GALAXY_COLOSSEUM = 0x36,
  WINNING_DEMO = 0x37,
  LOSING_DEMO = 0x38,
  DRAW_DEMO = 0x39,
  SUNSET_LUIGI_CIRCUIT = 0x3A
} CourseId;

typedef enum {
  MENU_CHARACTER_MANAGER_STATE_CLEARED = 0,
  MENU_CHARACTER_MANAGER_STATE_UNK1 = 1,
  MENU_CHARACTER_MANAGER_STATE_UNK2 = 2,
  MENU_CHARACTER_MANAGER_STATE_UNK3 = 3,
  MENU_CHARACTER_MANAGER_STATE_UNK4 = 4
} MenuCharacterManagerState;

typedef enum {
  COURSE_CACHE_STATE_UNK0 = 0,
  COURSE_CACHE_STATE_UNK1 = 1,
  COURSE_CACHE_STATE_UNK2 = 2,
  COURSE_CACHE_STATE_UNK3 = 3
} CourseCacheState;

class CourseCache : EGG::Disposer {
public:
  CourseCache();
  void init();
  virtual ~CourseCache();
  void load(CourseId courseId);
  void loadOther(MultiDvdArchive* other, EGG::Heap* heap);

  // private: // idk if rii prefers to befriend every class over public-ing
  // everything
  void* mpBuffer;
  EGG::ExpHeap* mpHeap;
  CourseId mCourseId;
  CourseCacheState mState;
  MultiDvdArchive* mpArchive;
};

// begrudging riidefi magic
struct S {
  virtual ~S();
};
inline S::~S() {}
struct T {
public:
  T() {
    mpArchiveHeap = nullptr;
    mpFileHeap = nullptr;
    mState = MENU_CHARACTER_MANAGER_STATE_CLEARED;
  }
  EGG::ExpHeap* mpArchiveHeap;
  EGG::ExpHeap* mpFileHeap;
  MenuCharacterManagerState mState;

  // what am I looking at
  inline bool SOME_CHECK() const {
    return mpArchiveHeap && ((mState <= 4u && (((1 << mState) & 0x15U) != 0)));
  }
  inline void destroy() {
    if (SOME_CHECK()) {
      mpArchiveHeap->freeAll();
      mpFileHeap->freeAll();
    }
    mState = MENU_CHARACTER_MANAGER_STATE_UNK3;
  }
  inline void setArchiveHeap(EGG::ExpHeap* heapSrc) {
    if (!mpArchiveHeap) {
      mpArchiveHeap = heapSrc;
    }
  }
  inline void setFileHeap(EGG::ExpHeap* heapSrc) {
    if (!mpFileHeap) {
      mpFileHeap = heapSrc;
    }
  }
};

class MenuCharacterManager : S, public T {
  friend class ResourceManager;

public:
  MenuCharacterManager() {
    mCharacter = MARIO;
    mTeam = BATTLE_TEAM_NONE;
  }
  virtual ~MenuCharacterManager() {}
  CharacterId mCharacter;
  BattleTeam mTeam;
};

void preloadCourseTask(void* courseId);
const char* getCharacterName(CharacterId charId);
const char* getVehicleName(VehicleId vehicleId);

// unknown structs
struct Whatever {
  u32 _00;
  u8 _04[0xa4 - 0x4];
};
struct Whatever2 {
  u8 _00[0x4 - 0x0];
  Whatever* _04;
  u16 _08; // ...
};

class ResourceManager {
  virtual ~ResourceManager();

public:
  static volatile ResourceManager* createInstance();
  static void destroyInstance();

  // Pretty sure this is actual source code
  union ResMgrInstance {
    volatile ResourceManager* vol;
    ResourceManager* nonvol;
  };
  static ResMgrInstance spInstance;
  static inline ResourceManager* getInstance() { return spInstance.nonvol; }
  // static volatile ResourceManager* spInstance;
  // static ResourceManager* spInstance_REAL;

  ResourceManager();

  MultiDvdArchive** mppSceneArchives;
  MultiDvdArchive mKartArchives[MAX_PLAYER_COUNT];
  MultiDvdArchive mBackupKartArchives[MAX_PLAYER_COUNT]; // TODO: better name
  DvdArchive mSystemArchives[4];
  JobContext mJobContexts[7];
  EGG::TaskThread* mpTaskThread;
  CourseCache mCourseCache;
  MenuCharacterManager mMenuManagers[4];
  bool mIsGlobeLoadingBusy;
  bool _60d; // this variable is only used in GameScene
  EGG::ExpHeap* mpMenuHeap;
  EGG::Heap* mpGlobeHeap;
  bool mRequestPending;
  bool mRequestsEnabled;

  void foo() volatile {
    mRequestPending = false;
    mRequestsEnabled = true;
  }
  void bar() volatile {
    mpGlobeHeap = nullptr;
    mIsGlobeLoadingBusy = false;
  }

  MultiDvdArchive* load(ResourceChannelID channelId, EGG::Heap* archiveHeap,
                        const char* filename);
  DvdArchive* loadSystemResource(s32 idx, EGG::Heap* archiveHeap);
  MultiDvdArchive* loadUI(const char* filename, EGG::Heap* archiveHeap);
  MultiDvdArchive* loadCourse(CourseId courseId, EGG::Heap* param_3,
                              bool splitScreen);
  MultiDvdArchive* loadMission(CourseId courseId, s32 missionNum,
                               EGG::Heap* param_3, bool splitScreen);
  MultiDvdArchive* loadCompetition(CourseId courseId, void* fileStart,
                                   u32 fileSize, EGG::Heap* heap, u8 unk6);
  MultiDvdArchive* loadKartFromArchive(MultiDvdArchive* archive, u32 unu,
                                       VehicleId vehicleId,
                                       CharacterId characterId,
                                       BattleTeam battleTeam, PlayMode playMode,
                                       EGG::Heap* archiveHeap,
                                       EGG::Heap* fileHeap);
  MultiDvdArchive* loadKartFromArchive2(s32 archiveIdx, VehicleId vehicleId,
                                        CharacterId characterId,
                                        BattleTeam battleTeamId,
                                        PlayMode playMode,
                                        EGG::Heap* archiveHeap,
                                        EGG::Heap* fileHeap);
  MultiDvdArchive* loadKartFromArchive3(s32 archiveIdx, VehicleId vehicleId,
                                        CharacterId characterId,
                                        BattleTeam battleTeamId,
                                        PlayMode playMode,
                                        EGG::Heap* archiveHeap,
                                        EGG::Heap* fileHeap);
  MultiDvdArchive* loadMenuKartModel(s32 archiveIdx, CharacterId characterId,
                                     BattleTeam battleTeam,
                                     EGG::Heap* archiveHeap,
                                     EGG::Heap* fileHeap);
  void unmountMulti(s32 archiveIdx);
  void unmountMulti(MultiDvdArchive* other);
  void unmountArchive(s32 archiveIdx);
  void* getFile(s32 archiveIdx, const char* filename, size_t* size);
  void* getCharacterFile(CharacterId characterId, size_t* size);
  void* getVehicleFile(s32 archiveIdx, VehicleId vehicleId, size_t* size);
  void* getKartArchiveFile(s32 idx, const char* filename, size_t* size);
  void* getBackupKartArchiveFile(s32 idx, const char* filename, size_t* size);
  void* getBspFile(s32 playerIdx, size_t* size);
  void* getFileCopy(s32 archiveIdx, char* filename, EGG::Heap* heap,
                    size_t* size, s8 param_5);
  bool isSceneArchiveLoaded(s32 idx) volatile;
  bool isKartArchiveLoaded(s32 idx);
  bool isBackupKartArchiveLoaded(s32 idx);
  bool isSystemArchiveLoaded(s32 idx);
  bool setArcResourceLink(s32 multiIdx, u16 archiveIdx, void* arcResource,
                          const char* dirname);
  u16 getLoadedArchiveCount(s32 idx);
  // I need this terribleness to match attachArcResourceAccessor
  inline u16 getLoadedArchiveCountInverse(u32 idx) volatile {
    return !isSceneArchiveLoaded(idx) ? 0 : mppSceneArchives[idx]->archiveCount;
  }
  u16 getMenuArchiveCount();
  bool tryRequestTask(EGG::TaskThread::TFunction mainFunction, void* arg);
  bool requestTask(EGG::TaskThread::TFunction mainFunction, void* arg,
                   void* _8);

  void attatchLayoutDir(void* accessor, const char* dirname, Whatever2* param_3,
                        bool param_4);
  void attachArcResourceAccessor(void* arcResourceAccessor,
                                 const char* dirname);
  void preloadCourseAsync(CourseId courseId);
  void initGlobeHeap(size_t size, EGG::Heap* heap);
  // to match flush
  inline void enableRequests() volatile {
    mRequestsEnabled = true;
    mRequestPending = false;
  }
  void flush() NEVER_INLINE;
  void deinitGlobeHeap();
  static void doLoadCharacterKartModel(void* idxs);
  void doLoadCharacterKartModelPriv(s32 idxs);
  bool loadKartMenuModelAsync(s32 idx, CharacterId characterId,
                              BattleTeam battleTeam);
  void createMenuHeaps(u32 count, s32 heapIdx);
  EGG::ExpHeap* getMenuManagerHeap(int managerIdx);
  static u8* loadGlobe(EGG::Heap* globeHeap);
  static void doLoadGlobe(void* globeBlob);
  void doLoadGlobeImpl(u8** glodeBlob) volatile;
  // for matching purposes
  inline bool requestGlobeTaskHelper(void* arg, void* arg2) volatile {
    mIsGlobeLoadingBusy = true;
    if (mRequestsEnabled) {
      mRequestPending = true;
      mpTaskThread->request(ResourceManager::doLoadGlobe, arg, arg2);
    }
    return true;
  }
  bool loadGlobeAsync(void* arg);
  void clear();
  void process() NEVER_INLINE;
  static void doLoadTask(void* jobContext);
  void requestLoad(s32 idx, MultiDvdArchive* m, const char* p,
                   EGG::Heap* archiveHeap);
  void requestLoad(s32 idx, DvdArchive* archive, const char* filename, u32 unk,
                   EGG::Heap* archiveHeap);
  void requestLoad(s32 idx, MultiDvdArchive* archive, const char* filename,
                   EGG::Heap* archiveHeap, EGG::Heap* fileHeap);
  void* getArchiveStart(ResourceChannelID resId, u32 archiveIdx);
  static void loadStaffGhostAsync(GhostFileGroup::GhostGroupType ghostType,
                                  CourseId courseId, u8* destBuffer);

  // TODO: check if actually inline
  inline void requestLoadFile(s32 idx, MultiDvdArchive* m, const char* p,
                              EGG::Heap* archiveHeap, EGG::Heap* fileHeap) {
    mJobContexts[idx].mpMultiArchive = m;
    strncpy(mJobContexts[idx].mFilename, p,
            sizeof(mJobContexts[idx].mFilename));
    mJobContexts[idx].mpArchiveHeap = archiveHeap;
    mJobContexts[idx].mpFileHeap = fileHeap;

    mpTaskThread->request(ResourceManager::doLoadTask, (void*)idx, 0);
    process();

    if (!m->isLoaded()) {
      OSSleepMilliseconds(16);
    }
  }
  inline void requestLoadFile(s32 idx, DvdArchive* archive,
                              const char* filename, u32 unk,
                              EGG::Heap* archiveHeap) {
    mJobContexts[idx].mpArchive = archive;
    strncpy(mJobContexts[idx].mFilename, filename, 0x40);
    mJobContexts[idx].mpArchiveHeap = archiveHeap;
    mJobContexts[idx]._08 = unk;

    mpTaskThread->request(ResourceManager::doLoadTask, (void*)idx, 0);
    process();

    if (!archive->isLoaded()) {
      OSSleepMilliseconds(16);
    }
  }
  inline void clear(s32 i) {
    MultiDvdArchive* archive;
    EGG::ExpHeap* heap;

    heap = mMenuManagers[i].mpArchiveHeap;
    archive = &mKartArchives[i];

    if (archive->isLoaded()) {
      archive->unmount();
    }
    if (heap) {
      heap->destroy();
    }

    if (mMenuManagers[i].mState != MENU_CHARACTER_MANAGER_STATE_UNK3) {
      mMenuManagers[i].mpArchiveHeap = nullptr;
      mMenuManagers[i].mpFileHeap = nullptr;
      mMenuManagers[i].mState = MENU_CHARACTER_MANAGER_STATE_CLEARED;
    }
  }
  // needed to prevent duplicate code in flush and process
  inline void _process();
};

} // namespace System
/* end "system/ResourceManager.hpp" */

/* "src\kart\KartSettings.hpp" line 6 "KartParam.hpp" */

#pragma once

/* "src\kart\KartParam.hpp" line 3 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

/* "src\kart\KartParam.hpp" line 5 "BSP.hpp" */

#pragma once

#define BSP_HITBOX_COUNT 0x10

namespace Kart {
struct BspHitbox {
  u16 enabled;
  EGG::Vector3f pos;
  f32 radius;
  u16 wallOnly; // only collide with walls
  u16 tireCollisionIndex;
};
static_assert(sizeof(BspHitbox) == 0x18);

struct BspWheel {
  u16 enabled;
  // simple spring-mass-damper suspension
  f32 springStiffness;
  f32 dampingFactor;
  f32 maxTravel;
  EGG::Vector3f centerPos;
  // Wheel X axis rotation (0 in vanilla)
  f32 xRot;
  f32 wheelRadius;
  // bounding sphere used for collision
  f32 colSphereRadius;
  u32 _28;
};
static_assert(sizeof(BspWheel) == 0x2c);

class BSP {
public:
  f32 initialYpos;
  BspHitbox hitboxes[BSP_HITBOX_COUNT];
  EGG::Vector3f cuboids[2];
  f32 angVel0Factor;
  f32 _1a0;
  BspWheel wheels[4];
  u32 _254;
  u32 _258;
};
static_assert(sizeof(BSP) == 0x25c);
}
/* end "BSP.hpp" */

namespace Kart {
// Vechicle categories based on the type of axles they use
enum AxleType {
  AXLE_TYPE_KART     = 0x0,
  AXLE_TYPE_BIKE     = 0x1,
  AXLE_TYPE_QUACKER  = 0x2,
  /// Used for blue falcon
  AXLE_TYPE_TRICYCLE = 0x3,
};

enum DriftType {
  DRIFT_TYPE_OUTSIDE_KART = 0x0,
  DRIFT_TYPE_OUTSIDE_BIKE = 0x1,
  DRIFT_TYPE_INSIDE_BIKE  = 0x2,
};

enum WeightClass {
  WEIGHT_CLASS_LIGHT  = 0x0,
  WEIGHT_CLASS_MEDIUM = 0x1,
  WEIGHT_CLASS_HEAVY  = 0x2,
};

struct RotatingItemParams {
  u8 _0[0x10 - 0x0];
};

struct KartStats {
  AxleType axleType;
  DriftType driftType;
  WeightClass weightClass;
  f32 _c;
  f32 weight;
  /// moment of inertia around Y axis
  f32 yawInertia;
  /// base speed
  f32 baseSpeed;
  /// base handling
  f32 baseHandling;
  /// Taken from the wiki. idk what that does, doesn't seem like much of a tilt
  f32 tilt;
  f32 accAs[4];
  f32 accTs[4 - 1];
  f32 driftAccAs[2];
  f32 driftAccTs[2 - 1];
  /// handling in manual mode
  f32 manualHandling;
  /// handling in auto mode
  f32 autoHandling;
  /// Responsiveness to change in direction
  f32 handlingResponsiveness;
  /// drifting in manual mode
  f32 manualDrifting;
  /// drifting in auto mode
  f32 autoDrifting;
  /// Responsiveness to drift change in direction
  f32 driftingResponsiveness;
  /// Angle of outside drifting cars w.r.t. direction of movement
  f32 driftAngle;
  f32 driftAngleDecr;
  /// Mini-turbo duration
  f32 mtDuration;
  /// Base speed multiplier depending on the KCL flag
  f32 speedFactors[32];
  /// Additional handling depending on the KCL flag
  f32 handlingFactors[32];
  RotatingItemParams rotatingItemParams;
  f32 maxVerticalAcc;
  f32 megaScale;
  f32 wheelbase;

  inline f32 getSpeedFactor(s32 type) const { return speedFactors[type]; }
  inline f32 getHandlingFactor(s32 type) const { return handlingFactors[type]; }
};
static_assert(sizeof(KartStats) == 0x18c);

class KartParam {
public:
  KartStats* stats;
  BSP* bsp; 
};
}
/* end "KartParam.hpp" */
/* "src\kart\KartSettings.hpp" line 7 "KartDispParams.hpp" */

#pragma once

// TODO
class KartDriverDispParams;
class KartPartsDispParams;
class BikePartsDispParams;
class DriverDispParams;
/* end "KartDispParams.hpp" */

namespace Kart {
class GpStats;
class RaceStats;
class KartSettings {
public:
  KartSettings();

  u32 isBike;
  System::VehicleId vehicle;
  System::CharacterId character;
  u16 susCount;
  u16 wheelCount;
  u8 playerIdx;
  KartParam* kartParam;
  void* _18;
  KartDriverDispParams* kartDriverDispParams;
  KartPartsDispParams* kartPartsDispParams;
  BikePartsDispParams* bikePartsDispParams;
  DriverDispParams* driverDispParams;
  f32 wheelCountRecip;
  f32 wheelCountPlusOneRecip;
  GpStats* gpStats;
  RaceStats* raceStats;
};
static_assert(sizeof(KartSettings) == 0x3c);
}
/* end "KartSettings.hpp" */
/* "src\kart\KartObjectProxy.hpp" line 11 "KartHitbox.hpp" */
#pragma once

/* "src\kart\KartHitbox.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartHitbox.hpp" line 4 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "src\kart\KartHitbox.hpp" line 5 "egg/math/eggQuat.hpp" */
/*!
 * @file
 * @brief TODO
 */

#pragma once

/* "lib\egg\math\eggQuat.hpp" line 7 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\egg\math\eggQuat.hpp" line 9 "eggVector.hpp" */
/* end "eggVector.hpp" */

namespace EGG {

class Quatf {
public:
  void set(float w, float x, float y, float z);
  void setRPY(const Vector3f& euler);
  void setRPY(float r, float p, float y);
  void setAxisRotation(const Vector3f& axis, float angle);
  float axisSquareNorm() const { return x*x + y*y + z*z; }; // maybe Vector3f subobj
  float squareNorm();
  void normalise();
  Quatf inverse();
  void rotateVector(const Vector3f& v, Vector3f& out);
  void rotateVectorInv(const Vector3f& v, Vector3f& out);
  void slerpTo(const Quatf& r4, float, Quatf& r5) const;
  void makeVectorRotation(Vector3f& v0, Vector3f& v1);

  inline void setIdentity() {
    set(1.0f, 0.0f, 0.0f, 0.0f);
  }

  inline Quatf& operator=(const Quatf& rhs) {
    x = rhs.x;
    y = rhs.y;
    z = rhs.z;
    w = rhs.w;
    return *this;
  }

  inline Quatf& operator*(float f) {
    x *= f;
    y *= f;
    z *= f;
    w *= f;
    return *this;
  }

  inline Quatf& operator+=(const Quatf& rhs) {
    x += rhs.x;
    y += rhs.y;
    z += rhs.z;
    w += rhs.w;
    return *this;
  }

  inline static void quatMul(Quatf& dst, const Quatf& q1, const Quatf& q2) {
    dst.set(
      q1.w*q2.w - q1.x*q2.x - q1.y*q2.y - q1.z*q2.z,
      q1.x*q2.w + q1.w*q2.x + q1.y*q2.z - q1.z*q2.y,
      q1.y*q2.w + q1.w*q2.y + q1.z*q2.x - q1.x*q2.z,
      q1.z*q2.w + q1.w*q2.z + q1.x*q2.y - q1.y*q2.x
    );
  }
  inline static void quatMul(Quatf& dst, const Quatf& q1, const Vector3f& v) {
    float x1 = q1.x;
    float x2 = v.x;
    float y1 = q1.y;
    float y2 = v.y;
    float z1 = q1.z;
    float z2 = v.z;
    float w1 = q1.w;
    dst.set(
      -(x1*x2 + y1*y2 + z1*z2),
      y1*z2 + w1*x2 - z1*y2,
      z1*x2 + w1*y2 - x1*z2,
      w1*z2 + x1*y2 - y1*x2
    );
  }

  f32 x;
  f32 y;
  f32 z;
  f32 w;
};

} // namespace EGG
/* end "egg/math/eggQuat.hpp" */
/* "src\kart\KartHitbox.hpp" line 6 "egg/math/eggMatrix.hpp" */
// credits: kiwi
// https://github.com/kiwi515/ogws/blob/master/include/egg/math/eggMatrix.h

#ifndef EGG_MATH_MATRIX_H
#define EGG_MATH_MATRIX_H

/* "lib\egg\math\eggMatrix.hpp" line 6 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "lib\egg\math\eggMatrix.hpp" line 7 "egg/math/eggQuat.hpp" */
/* end "egg/math/eggQuat.hpp" */

namespace EGG
{
    struct Matrix33f : public nw4r::math::MTX33
    {
        f32& operator()(int i, int j) { return mtx[i][j]; }
    };

    struct Matrix34f : public nw4r::math::MTX34
    {
        Matrix34f() {}
        Matrix34f(f32, f32, f32, f32,
            f32, f32, f32, f32,
            f32, f32, f32, f32);

        void makeZero()
        {
	    for(int i = 0; i < 3; i++) {
                for(int j = 0; j < 4; j++) {
                    mtx[i][j] = 0.0f;
                }
            }
        }

        void inverseToC(Matrix34f& inv) const;
        void makeIdentity();
        void makeQ(const Quatf&);
        void makeQT(const Quatf&, const Vector3f&);
        void makeS(const Vector3f&);
        void makeR(const Vector3f&);
        void setAxisRotation(const Vector3f &, f32);
	EGG::Vector3f multVector(const EGG::Vector3f&) const;
	// Defined inline and emitted in KartWheelPhysics
	EGG::Vector3f multVector33(const EGG::Vector3f&) const NEVER_INLINE;
        void loadPosMtx(u32);

        f32& operator()(int i, int j) { return mtx[i][j]; }

	friend Vector3f operator*(const Matrix34f& M, const Vector3f& v) {
	    Vector3f out;
	    const float vecX = v.x;
	    const float vecY = v.y;
	    const float vecZ = v.z;
	    out.x = (vecX * M.mtx[0][0]) + (vecY * M.mtx[0][1]) + (vecZ * M.mtx[0][2]);
	    out.y = (vecX * M.mtx[1][0]) + (vecY * M.mtx[1][1]) + (vecZ * M.mtx[1][2]);
	    out.z = (vecX * M.mtx[2][0]) + (vecY * M.mtx[2][1]) + (vecZ * M.mtx[2][2]);
	    return out;
	}

        //f32 tbl[3][4];

        static Matrix34f ident;
    };
inline Vector3f operator*(f32 lhs, const Vector3f& rhs) {return Vector3f(lhs*rhs.x, lhs*rhs.y, lhs*rhs.z);}

class Matrix34f_aligned8 : public Matrix34f {} __attribute__ ((aligned (8)));;
}

#endif
/* end "egg/math/eggMatrix.hpp" */

/* "src\kart\KartHitbox.hpp" line 8 "BSP.hpp" */
/* end "BSP.hpp" */

namespace Kart {
// Represents a sphere hitbox
class Hitbox {
public:
  BspHitbox* bsp;
  f32 radius;
  u32 _8;
  // position in world coordinates
  EGG::Vector3f pos;
  /// 99% not actually last pos
  EGG::Vector3f lastPos;
  // position in kart coordinates
  EGG::Vector3f relPos;

public:
  Hitbox();
  ~Hitbox() {}
  void reset();
  void update(const EGG::Vector3f& scale, const EGG::Quatf& rot, const EGG::Vector3f& pos, f32 totalScale, f32 hitboxElevation);
  void setLastPos(const EGG::Vector3f& scale, const EGG::Matrix34f& pose);
  BspHitbox* create(const EGG::Vector3f& pos, f32 radius);
  void setScale(float);
};
static_assert(sizeof(Hitbox) == 0x30);

#define COL_FLAG_FLOOR 			     0x1
#define COL_FLAG_WALL 			     0x2
#define COL_FLAG_INVISIBLE_WALL 	     0x4
#define COL_FLAG_TRICKABLE 		     0x8
#define COL_FLAG_UNK10 			     0x10
#define COL_FLAG_MOVING_WATER_V0 	     0x20
#define COL_FLAG_WALL_3 		     0x40
#define COL_FLAG_INVISIBLE_WALL_ONLY 	     0x80
#define COL_FLAG_MOVING_WATER_V2 	     0x100
#define COL_FLAG_SOFT_WALL 		     0x200
#define COL_FLAG_MOVING_WATER_STRONG_CURRENT 0x400
#define COL_FLAG_MOVING_WATER_DISABLE_ACC    0x800
#define COL_FLAG_WALL_AT_RIGHT_CLOSER 	     0x2000
#define COL_FLAG_WALL_AT_LEFT_CLOSER         0x4000
#define COL_FLAG_MOVING_WATER_V3             0x8000

struct KartCollisionInfo {
  u32 flags;
  EGG::Vector3f tangentOff;
  EGG::Vector3f floorNrm;
  EGG::Vector3f wallNrm;
  EGG::Vector3f softWallNrm;
  EGG::Vector3f vel;
  EGG::Vector3f relPos;
  EGG::Vector3f movement;
  EGG::Vector3f _58;
  f32 speedFactor;
  f32 handlingFactor;
  // floor KCL attribute stuff
  u32 floorKclTypeMask;
  s32 floorKclVariant;
  // wall KCL attribute stuff
  u32 wallKclType;
  s32 wallKclVariant;
  /// Causes the object to sink into the colliding surface by this amount (used for e.g. snow)
  u32 sinkDepth;
  /// Amount of angle between face normals of colliding wall from 0.0-1.0. Greater than 0.0 only when there is wall collision
  f32 colPerpendicularity;

  KartCollisionInfo* initStatus();
  void reset();
};
static_assert(sizeof(KartCollisionInfo) == 0x84);

class HitboxGroup {

  s16 hitboxCount;
  f32 boundingRadius;
  KartCollisionInfo colInfo;
  Hitbox* hitboxes;
  u32 _90;
  f32 hitboxScale;
  f32 _98;

public:
  HitboxGroup();
  ~HitboxGroup() {}
  void reset();
  void setHitboxScale(f32 scale);
  void createHitboxes(s32 n);
  f32 initHitboxes(BspHitbox* hitboxData, void* unused, s32 wheelCount);
  f32 setHitboxes(BspHitbox* hitboxData);
  void createSingleHitbox(const EGG::Vector3f& pos, f32 radius);
  f32 computeCollisionLimits();

  inline const Hitbox& getHitbox(u16 i) const { return hitboxes[i]; }
  inline Hitbox& getHitbox(u16 i) { return hitboxes[i]; }
  inline s32 getHitboxCount() const { return hitboxCount; }
  inline f32 getBoundingRadius() const { return boundingRadius; }
  inline const KartCollisionInfo& getKartCollisionInfo() const { return colInfo; }
  inline KartCollisionInfo& getKartCollisionInfo() { return colInfo; }
};
static_assert(sizeof(HitboxGroup) == 0x9c);
}
/* end "KartHitbox.hpp" */
/* "src\kart\KartObjectProxy.hpp" line 12 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */
/* "src\kart\KartObjectProxy.hpp" line 13 "egg/math/eggQuat.hpp" */
/* end "egg/math/eggQuat.hpp" */
/* "src\kart\KartObjectProxy.hpp" line 14 "kart/KartWheel.hpp" */

#pragma once

/* "src\kart\KartWheel.hpp" line 3 "KartPart.hpp" */

#pragma once

/* "src\kart\KartPart.hpp" line 3 "KartSettings.hpp" */
/* end "KartSettings.hpp" */
/* "src\kart\KartPart.hpp" line 4 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */
/* "src\kart\KartPart.hpp" line 5 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

namespace Kart {
class KartPart {
  

public:
  KartPart(const KartSettings& kartSettings, u32 thing);
  const EGG::Matrix34f getPose() const { return pose; };

  // TODO : structure is still very wrong
  EGG::Vector3f pos;
  EGG::Matrix34f pose;
  u8 todo[0x90-0x3c];
};
}
/* end "KartPart.hpp" */

namespace Kart {
class KartWheelPhysics;
class KartWheel : public KartPart {
public:
  inline const KartWheelPhysics* getPhysics() const { return wheelPhysics; }
  inline KartWheelPhysics* getPhysics() { return wheelPhysics; }
private:
  // for kart the x coordinate is mirrored for the left wheels
  u32 xMirrored;
  u32 bspWheelIdx;
  KartWheelPhysics* wheelPhysics;
  // TODO more
};
}
/* end "kart/KartWheel.hpp" */
/* "src\kart\KartObjectProxy.hpp" line 15 "kart/KartSus.hpp" */
#pragma once

/* "src\kart\KartSus.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartSus.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartSus.hpp" line 6 "KartPart.hpp" */
/* end "KartPart.hpp" */
/* "src\kart\KartSus.hpp" line 7 "kart/KartObjectProxy.hpp" */
/* end "kart/KartObjectProxy.hpp" */

namespace Kart {
class KartSusPhysics;

class KartSus: KartPart {
public:
  inline const KartSusPhysics* getPhysics() const { return susPhysics; }
  inline KartSusPhysics* getPhysics() { return susPhysics; }

private:
  KartSusPhysics* susPhysics;
};
}
/* end "kart/KartSus.hpp" */
/* "src\kart\KartObjectProxy.hpp" line 16 "system/KPadController.hpp" */
#pragma once

/* "src\system\KPadController.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\system\KPadController.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\system\KPadController.hpp" line 6 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

/* "src\system\KPadController.hpp" line 8 "rvl/kpad/kpad.h" */
#pragma once

/* "lib\rvl\kpad\kpad.h" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "lib\rvl\kpad\kpad.h" line 4 "decomp.h" */
/* end "decomp.h" */

/* "lib\rvl\kpad\kpad.h" line 6 "rvl/wpad/wpad.h" */
#pragma once

/* "lib\rvl\wpad\wpad.h" line 2 "rk_types.h" */
/* end "rk_types.h" */
/* "lib\rvl\wpad\wpad.h" line 3 "decomp.h" */
/* end "decomp.h" */

#ifdef __cplusplus
extern "C" {
#endif

// Size: 0x7 (padded to 0x8)
typedef struct DPDObject {
  s16 x;
  s16 y;
  u16 size;
  u8 traceId;
} DPDObject;

// Size: 0x2a (padded to 0x2c)
typedef struct WPADStatus {
  u16 button;
  s16 accX;
  s16 accY;
  s16 accZ;
  DPDObject obj[4];
  u8 dev; // controller type
  s8 err; // error status
} WPADStatus;

// Size: 0x32
typedef struct WPADFSStatus {
  u16 button;
  s16 accX;
  s16 accY;
  s16 accZ;
  DPDObject obj[4];
  u8 dev; // controller type
  s8 err; // error status
  s16 fsAccX;
  s16 fsAccY;
  s16 fsAccZ;
  s8 fsStickX;
  s8 fsStickY;
} WPADFSStatus;

// Size: 0x36 (padded to 0x38)
typedef struct WPADCLStatus {
  u16 button;
  s16 accX;
  s16 accY;
  s16 accZ;
  DPDObject obj[4];
  u8 dev; // controller type
  s8 err; // error status
  u16 clButton;
  s16 clLStickX;
  s16 clLStickY;
  s16 clRStickX;
  s16 clRStickY;
  u8 clTriggerL;
  u8 clTriggerR;
} WPADCLStatus;

// Size: 0x18
typedef struct WPADInfo {
  s32 dpd;
  s32 speaker;
  s32 attach;
  s32 lowBat;
  s32 nearempty;
  u8 battery;
  u8 led;
  u8 protocol;
  u8 firmware;
} WPADInfo;

#ifdef __cplusplus
}
#endif
/* end "rvl/wpad/wpad.h" */
/* "lib\rvl\kpad\kpad.h" line 7 "rvl/mtx/mtx.h" */
/* end "rvl/mtx/mtx.h" */

#ifdef __cplusplus
extern "C" {
#endif

// Size: 0x24
typedef union KPADEXStatus {
  struct {
    Vec2 stick;
    Vec acc;
    f32 acc_value;
    f32 acc_speed;
  } fs;
  struct {
    u32 hold;
    u32 trig;
    u32 release;
    Vec2 lstick;
    Vec2 rstick;
    f32 ltrigger;
    f32 rtrigger;
  } cl;
} KPADEXStatus;

// Size: 0x84
typedef struct KPADStatus {
  u32 hold;
  u32 trig;
  u32 release;
  Vec acc;
  f32 acc_value;
  f32 acc_speed;
  Vec2 pos;
  Vec2 vec;
  f32 speed;
  Vec2 horizon;
  Vec2 hori_vec;
  f32 hori_speed;
  f32 dist;
  f32 dist_vec;
  f32 dist_speed;
  Vec2 acc_vertical;
  u8 dev_type;
  s8 wpad_err;
  s8 dpd_valid_fg;
  u8 data_format;
  KPADEXStatus ex_status;
} KPADStatus;

// Size: 0x38
typedef struct KPADUnifiedWpadStatus {
  union {
    WPADStatus core;
    WPADFSStatus fs;
    WPADCLStatus cl;
  } u;
  u8 fmt;
  u8 padding;
} KPADUnifiedWpadStatus;

void KPADInit();

void KPADSetBtnRepeat(s32, f32, f32);
void KPADSetSensorHeight(s32, f32);
void KPADSetPosParam(s32, f64, f64);
void KPADSetHoriParam(s32, f64, f64);
void KPADSetDistParam(s32, f64, f64);

void KPADReset(void);
s32 KPADRead(s32, KPADStatus [], u32);

#ifdef __cplusplus
}
#endif
/* end "rvl/kpad/kpad.h" */
/* "src\system\KPadController.hpp" line 9 "rvl/pad/pad.h" */
#pragma once

/* "lib\rvl\pad\pad.h" line 2 "rk_types.h" */
/* end "rk_types.h" */
/* "lib\rvl\pad\pad.h" line 3 "stdbool.h" */
/* end "stdbool.h" */

/* "lib\rvl\pad\pad.h" line 5 "rvl/os/osContext.h" */
/* end "rvl/os/osContext.h" */

#ifdef __cplusplus
extern "C" {
#endif

// https://github.com/devkitPro/libogc/blob/bc4b778d558915aa40676e33514c4c9ba2af66b8/gc/ogc/pad.h#L46
// Size: 0x0B (arrays padded to 0x0C)
typedef struct PADStatus {
  // 0x00
  u16 button;
  // 0x02
  s8 stickX;
  // 0x03
  s8 stickY;
  // 0x04
  s8 substickX;
  // 0x05
  s8 substickY;
  // 0x06
  u8 triggerL;
  // 0x07
  u8 triggerR;
  // 0x08
  u8 analogA;
  // 0x09
  u8 analogB;
  // 0x0A
  s8 err;
} PADStatus;

// Size: 0x0A
typedef struct PADClampRegion {
  u8 unk_00;
  u8 unk_01;
  s8 stickMin; // 0x02
  s8 unk_03;
  s8 unk_04;
  s8 substickMin; // 0x05
  s8 unk_06;
  s8 unk_07;
  s8 stickRad;    // 0x08
  s8 substickRad; // 0x09
} PADClampRegion;

void PAD_ClampCircle(s8*, s8*, s8, s8);
void PADClampCircle(PADStatus*);
void PADClampCircle2(PADStatus*, u32);
void PAD_UpdateOrigin(s32);
void PADOriginCallback(s32, u32, void*);
void PADOriginUpdateCallback(s32, u32, void*);
void PADProbeCallback(s32, u32, void*);
void PADTypeAndStatusCallback(s32, u32);
int PADReset(u32);
int PADRecalibrate(u32);
int PADInit(void);
u32 PADRead(PADStatus*);
void PADControlMotor(s32, u32);
int PAD_OnReset(int);
void PAD_SamplingHandler(s32, OSContext*);
int __PADDisableRecalibration(int);
// PADSetSamplingCallback

void PADSetSpec(u32 model);
u32 PADGetSpec(void);

typedef void (*PADSamplingCallback)(void);

#ifdef __cplusplus
} // extern "C"
#endif
/* end "rvl/pad/pad.h" */
/* "src\system\KPadController.hpp" line 10 "rvl/wpad/wpad.h" */
/* end "rvl/wpad/wpad.h" */
namespace System {

class KPadGhostButtonsStream;
class KPadRecorder;
class KPadWiiControllerData;
class RumbleManager;

////////// INPUT STATE /////////////////

struct KPadRaceInputState {
  enum eTrick {
    UP_TRICK    = 1,
    DOWN_TRICK  = 2,
    LEFT_TRICK  = 3,
    RIGHT_TRICK = 4,
  };

  inline KPadRaceInputState() { reset(); }
  virtual ~KPadRaceInputState() {}                // [vt+0x08]

  void reset();

  bool operator==(const KPadRaceInputState& rhs) const;

  void setStickXMirrored(u8 x);
  void setStickXUnmirrored(u8 x);
  void setStickY(u8 y);
  void setTrick(eTrick trick);

  u16 mButtons;                                   // [this+0x04]
  u16 mButtonsRaw;                                // [this+0x06]
  EGG::Vector2f mStick;                           // [this+0x08]
  u8 mStickXRaw;                                  // [this+0x10]
  u8 mStickYRaw;                                  // [this+0x11]
  u8 mTrick;                                      // [this+0x12]
  u8 mTrickRaw;                                   // [this+0x13]
  struct {                                        // [this+0x14]
    bool mIsValid: 1;
    bool mFlags_1: 1;
    bool mFlags_2: 1;
    bool mFlags_3: 1;
    bool mFlags_4: 1;
    bool mFlags_5: 1;
    bool mFlags_6: 1;
    bool mFlags_7: 1;
  };
  u8 _15;
  u8 _16;
  u8 _17;
};

static_assert(sizeof(KPadRaceInputState) == 0x18);

struct KPadUIInputState {
  inline KPadUIInputState() { reset(); }
  virtual ~KPadUIInputState() {}                  // [vt+0x08]

  void reset();

  void setStickXMirrored(u8 x);
  void setStickY(u8 y);

  u16 mButtons;                                   // [this+0x04]
  u16 mButtonsRaw;                                // [this+0x06]
  EGG::Vector2f mStick;                           // [this+0x08]
  u8 _10[0x08];
  u8 mStickXRaw;                                  // [this+0x18]
  u8 mStickYRaw;                                  // [this+0x19]
  u8 _1a;
  u8 _1b;
  EGG::Vector2f mPointerPos;                      // [this+0x1c]
  EGG::Vector2f mPointerHorizontal;               // [this+0x24]
  float mPointerDist;                             // [this+0x2c]
  struct {                                        // [this+0x30]
    volatile u8 mFlags_0: 1; // volatile feels like a hack...
    u8 mFlags_1: 1;
    u8 mFlags_2: 1;
    u8 mFlags_3: 1;
    u8 mFlags_4: 1;
    u8 mFlags_5: 1;
    u8 mFlags_6: 1;
    u8 mFlags_7: 1;
  };
  u8 _31;
  u8 _32;
  u8 _33;
};

static_assert(sizeof(KPadUIInputState) == 0x34);

////////// CONTROLLER //////////////////

enum eControlSource {
  CONTROL_SOURCE_UNKNOWN    = -1,

  //! @brief Wiimote
  //!
  CONTROL_SOURCE_CORE       = 0,

  //! @brief Wiimote+Nunchuck
  //!
  CONTROL_SOURCE_FREESTYLE  = 2,

  //! @brief Classic controller
  //!
  CONTROL_SOURCE_CLASSIC    = 3,

  //! @brief Gamecube controller
  //!
  CONTROL_SOURCE_GAMECUBE   = 4,

  CONTROL_SOURCE_GHOST      = 5,

  CONTROL_SOURCE_AI         = 6,
};

class KPadController {
public:
  KPadController();
  virtual ~KPadController() {}                    // [vt+0x08]

  void calc();

  //! @brief [vt+0x0c] Called by `calc`.
  //!
  virtual void calcInner(KPadRaceInputState* raceInputState,
                         KPadUIInputState* uiInputState) = 0;

  virtual eControlSource getControlSource();      // [vt+0x10]
  virtual bool isRumbleEnabled();                 // [vt+0x14]
  virtual void startMotor();                      // [vt+0x18]
  virtual void stopMotor();                       // [vt+0x1c]
  virtual void stopMotorHard() {}                 // [vt+0x20]
  virtual double getStreamSize();                 // [vt+0x24]
  virtual void setDpdEnabled(bool enabled);       // [vt+0x28]
  virtual bool isDpdEnabled();                    // [vt+0x2c]
  virtual void updateBatteryStatus();             // [vt+0x30]
  virtual int getChan();                          // [vt+0x34]
  virtual void setDriftIsAuto(bool isAuto);       // [vt+0x38]
  virtual void* vf_3c();                          // [vt+0x3c]
  virtual u32 getBatteryLevelAsync();             // [vt+0x40]
  virtual void reset(bool driftIsAuto);           // [vt+0x44]

public:
  KPadRaceInputState mRaceInputState;             // [this+0x04]
  KPadUIInputState mUIInputState;                 // [this+0x1c]
  bool mIsConnected;                              // [this+0x50]
  bool mDriftIsAuto;                              // [this+0x51]
  u8 _52;
  u8 _53;
  u32 mBattery;                                   // [this+0x54]
  bool mOutOfBattery;                             // [this+0x58]
  u8 _59;
  u8 _5a;
  u8 _5b;
  KPadUIInputState mPrevUIInputState;             // [this+0x5c]
};

static_assert(sizeof(KPadController) == 0x90);

class KPadWiiController : public KPadController {
public:
  KPadWiiController();
  virtual ~KPadWiiController() {};                // [vt+0x08]

  //! @brief [vt+0x0c]
  void calcInner(KPadRaceInputState* raceInputState,
                 KPadUIInputState* uiInputState) override;

  eControlSource getControlSource() override;     // [vt+0x10]
  bool isRumbleEnabled() override;                // [vt+0x14]
  void startMotor() override;                     // [vt+0x18]
  void stopMotor() override;                      // [vt+0x1c]
  void stopMotorHard() override;                  // [vt+0x20]
  void setDpdEnabled(bool enabled) override;      // [vt+0x28]
  bool isDpdEnabled() override;                   // [vt+0x2c]
  int getChan() override;                         // [vt+0x34]
  u32 getBatteryLevelAsync() override;            // [vt+0x40]
  void reset(bool driftIsAuto) override;          // [vt+0x44]

private:

  // Calc inputs for Classic
  void calcClassic(KPADUnifiedWpadStatus* kpadUnifiedWpadStatus,
                   KPadRaceInputState* raceInputState,
                   KPadUIInputState* uiInputState);

  // Convert race input to UI input for Wiimote
  void raceToUIInputCore(KPadUIInputState* dst, KPadRaceInputState* src);

  // Convert race input to UI input for Nunchuck
  void raceToUIInputFreestyle(KPadUIInputState* dst, KPadRaceInputState* src);

  // Callback used in `getBatteryLevelAsync`
  static void updateBatteryCallback(int chan, int result);

  // Inlined in `updateBatteryCallback`
  void updateBattery(int result);

public:
  KPADStatus mKpadStatuses[0x10];                 // [this+0x090]
  u8 mKpadStatusCount;                            // [this+0x8d0]
  u8 _8d1;
  u8 _8d2;
  u8 _8d3;
  int mChan;                                      // [this+0x8d4]
  int mType;                                      // [this+0x8d8]
  eControlSource mControlSource;                  // [this+0x8dc]
  WPADInfo mWpadInfo;                             // [this+0x8e0]
  u16 _8f8;
  u8 _8fa;
  u8 _8fb;
  u16 _8fc;
  u16 _8fe;
  int mWpadType;                                  // [this+0x900]
  bool mClassicIsInDrift;                         // [this+0x904]
  u8 _905;
  u16 _906;
  EGG::Vector2f mPointerPos;                      // [this+0x908]
  EGG::Vector2f mPointerHorizontal;               // [this+0x910]
  f32 mPointerDist;                               // [this+0x918]
  KPadWiiControllerData* mWiiControllerData;      // [this+0x91c]
};

static_assert(sizeof(KPadWiiController) == 0x920);

class KPadGCController : public KPadController {
public:
  KPadGCController();
  virtual ~KPadGCController() {}                  // [vt+0x08]

  //! @brief [vt+0x0c]
  void calcInner(KPadRaceInputState* raceInputState,
                 KPadUIInputState* uiInputState) override;

  eControlSource getControlSource() override;     // [vt+0x10]
  bool isRumbleEnabled() override;                // [vt+0x14]
  void startMotor() override;                     // [vt+0x18]
  void stopMotor() override;                      // [vt+0x1c]
  void stopMotorHard() override;                  // [vt+0x20]
  int getChan() override;                         // [vt+0x34]
  void reset(bool driftIsAuto) override;          // [vt+0x44]

public:
  PADStatus mPadStatus;                           // [this+0x90]
  int mChan;                                      // [this+0x9c]
  EGG::Vector2f mSubstick;                        // [this+0xa0]
  u16 _a8;
  bool _aa;
  u8 _ab;
  u16 _ac;
  u8 _ae;
  u8 _af;
};

static_assert(sizeof(KPadGCController) == 0xb0);

class KPadGhostController : public KPadController {
public:
  KPadGhostController();
  virtual ~KPadGhostController();                 // [vt+0x08]

  //! @brief [vt+0x0c]
  void calcInner(KPadRaceInputState* raceInputState,
                 KPadUIInputState* uiInputState) override;

  eControlSource getControlSource() override;     // [vt+0x10]
  double getStreamSize() override;                // [vt+0x24]
  void setDriftIsAuto(bool isAuto) override;      // [vt+0x38]
  void reset(bool driftIsAuto) override;          // [vt+0x44]

  bool hasGhostBuffer() const;
  void readGhostBuffer(u16* buttonsData, bool isAuto);

public:
  u16* mGhostBuffer;                              // [this+0x90]
  KPadGhostButtonsStream* mButtonsStreams[3];     // [this+0x94]
  u8 _a0;
  u8 _a1;
  u8 _a2;
  u8 _a3;
  u8 _a4;
  u8 _a5;
  bool _a6;
  u8 _a7;
};

static_assert(sizeof(KPadGhostController) == 0xa8);

class KPadAIController : public KPadController {
public:
  KPadAIController();
  virtual ~KPadAIController() {}                  // [vt+0x08]

  //! @brief [vt+0x0c] Copy `mAIRaceInputState` into `raceInputState`.
  //!
  void calcInner(KPadRaceInputState* raceInputState,
                 KPadUIInputState* uiInputState) override;

public:
  KPadRaceInputState mAIRaceInputState;           // [this+0x90]
};

static_assert(sizeof(KPadAIController) == 0xa8);

class KPadDummyController : public KPadController {
public:
  virtual ~KPadDummyController() {}               // [vt+0x08]

  //! @brief [vt+0x0c] Do nothing.
  //!
  void calcInner(KPadRaceInputState* raceInputState,
                 KPadUIInputState* uiInputState) override {}
};

////////// KPAD ////////////////////////

struct KPadControllerInfo {
  eControlSource mControlSource;
  struct Addr {
    u8 mBytes[6];

    void getDevAddr(int chan);
    bool operator==(const Addr& rhs) const;
  } mWiimoteAddr;
  u8 _0a;
  u8 _0b;
  int mChan;

  bool operator==(const KPadControllerInfo& rhs) const;
};

class KPad {
public:
  KPad();
  virtual ~KPad() {}                              // [vt+0x08]

  virtual void calc(bool isPaused);               // [vt+0x0c]
  virtual void reset();                           // [vt+0x10]
  // [vt+0x14]
  virtual void setInputState(KPadRaceInputState* raceInputState);
  virtual u16* getRecordedBuffer();               // [vt+0x18]
  virtual u32 getRecordedBufferSize();            // [vt+0x1c]
  virtual void initRumbleManagers();              // [vt+0x20]

  void setDriftIsAuto(u16 isAuto);

  void setController(KPadController* controller, KPadController* controller2);

  void startMotor();
  void stopMotor();
  void stopMotorHard();

public:
  KPadController* mController;                    // [this+0x04]
  KPadController* mController2;                   // [this+0x08]
  KPadController* mController3;                   // [this+0x0c]
  s32 _10; // Related to rumble
  s8 _14; // Related to rumble
  u8 _15;
  u8 _16;
  u8 _17;
  void* _18; // Related to rumble
  s8 _1c;
  u8 _1d;
  u8 _1e;
  u8 _1f;
  RumbleManager* mRumbleManager;                  // [this+0x20]
  RumbleManager* mRumbleManager2;                 // [this+0x24]
  KPadRaceInputState mRaceInputState;             // [this+0x28]
  KPadRaceInputState mPrevRaceInputState;         // [this+0x40]
  KPadUIInputState mUIInputState;                 // [this+0x58]
  KPadUIInputState mPrevUIPInputState;            // [this+0x8c]
  s16 _c0; // Is drift auto (?)
  u16 mInactivityFrames;                          // [this+0xc2]
  u16 mDisconnectedFrames;                        // [this+0xc4]
  bool _c6; // Is paused (?)
  u8 _c7;
  KPadControllerInfo mControllerInfo;             // [this+0xc8]
};

static_assert(sizeof(KPad) == 0xd8);

class KPadPlayer : public KPad {
public:
  virtual ~KPadPlayer();                          // [vt+0x08]

  void calc(bool isPaused) override;              // [vt+0x0c]
  void reset() override;                          // [vt+0x10]
  u16* getRecordedBuffer() override;              // [vt+0x18]
  u32 getRecordedBufferSize() override;           // [vt+0x1c]

  void startGhostProxy();
  void endGhostProxy();

  void setGhostController(KPadController* controller,
                          KPadController* controller2,
                          bool driftIsAuto);

public:
  u16* mGhostBuffer;                              // [this+0xd8]
  u16* mRecordedBuffer;                           // [this+0xdc]
  u32 mRecordedBufferSize;                        // [this+0xe0]
  bool mIsLocked;                                 // [this+0xe4]
  u8 _e5;
  u8 _e6;
  u8 _e7;
  KPadRecorder* mRecorder;                        // [this+0xe8]
};

static_assert(sizeof(KPadPlayer) == 0xec);

class KPadAI : public KPad {
public:
  virtual ~KPadAI() {};                           // [vt+0x08]

  // [vt+0x14]
  void setInputState(KPadRaceInputState* raceInputState) override;

public:
  KPadAIController mAIController;                 // [this+0xd8]
};

static_assert(sizeof(KPadAI) == 0x180);
} // namespace System
/* end "system/KPadController.hpp" */

namespace Kart {

class KartBody;
class KartPhysics;
class KartDynamics;
class KartSus;
class KartWheel;
class KartSusPhysics;
class KartWheelPhysics;
class KartPhysicsEngine;
class KartMove;
class KartSnd;
class KartAccessor_34;
class MaybeShadow;
class KartCollide;
class KartModel;
class KartAction;
class KartCamera;
class KartAccessor_54;
class KartBlink;
class KartAccessor_5c;
class KartEnemy;
class KartAccessor_44;
class KartAccessor_48;
class KartNetReceiver;
class KartNetSender;
class BoxColUnit;
class KartAccessor_50;
class KartAccessor_60;
// Used outside of KartAccessor
class KartHalfPipe;
class KartJump;
class KartState;
class KartInput;

struct KartAccessor {
  KartSettings* kartSettings;
  KartState* mKartState;
  KartBody* mBody;
  KartSus** mSus;
  KartWheel** mWheels;
  KartModel* mModel;
  KartPhysicsEngine* mPhysicsEngine;
  KartSnd* mSnd;
  MaybeShadow* mMaybeShadow;
  KartCamera* mCamera;
  KartMove* mMove;
  KartAction* mAction;
  KartCollide* mCollide;
  KartAccessor_34* m_34;
  KartEnemy* mEnemy;
  KartNetSender* mSender;
  KartNetReceiver* mReceiver;
  KartAccessor_44* m_44;
  KartAccessor_48* m_48;
  BoxColUnit* mEntity;
  KartAccessor_50* m_50;
  KartAccessor_54* m_54;
  KartBlink* mBlink;
  KartAccessor_5c* m_5c;
  KartAccessor_60* m_60;
};
static_assert(sizeof(KartAccessor) == 0x64);

class KartObjectProxy {
public:
  KartObjectProxy();

  inline KartSettings* kartSettings() { return mAccessor->kartSettings; }
  inline const KartSettings* kartSettings() const { return mAccessor->kartSettings; }
  KartPhysics* kartPhysics();
  const KartPhysics* kartPhysics() const;
  KartDynamics* kartDynamics();
  const KartDynamics* kartDynamics() const;
  KartBody* kartBody();
  const KartBody* kartBody() const;
  KartSus* kartSus(s32 idx);
  const KartSus* kartSus(s32 idx) const;
  KartWheel* kartWheel(s32 idx);
  const KartWheel* kartWheel(s32 idx) const;
  KartSusPhysics* kartSusPhysics(s32 idx);
  const KartSusPhysics* kartSusPhysics(s32 idx) const;
  KartWheelPhysics* kartWheelPhysics(s32 idx);
  const KartWheelPhysics* kartWheelPhysics(s32 idx) const;
  KartPhysicsEngine* kartPhysicsEngine();
  const KartPhysicsEngine* kartPhysicsEngine() const;
  KartMove* kartMove();
  const KartMove* kartMove() const;
  KartSnd* kartSnd();
  KartAccessor_34* kartAccessor_34();
  MaybeShadow* maybeShadow();
  HitboxGroup* hitboxGroup();
  const HitboxGroup* hitboxGroup() const;
  const HitboxGroup* wheelHitbox(s32 idx) const;
  const KartCollisionInfo* bodyColInfo() const;
  const KartCollisionInfo* wheelColInfo(s32 idx) const;
  KartCollide* kartCollide();
  const KartCollide* kartCollide() const;
  void shouldVanishPlayer(bool);

  // dunno why this specifically is inline, but that's what it appears
  KartState* kartState() { return mAccessor->mKartState; }
  const KartState* kartState() const { return mAccessor->mKartState; }

  KartParam* kartParam() const;
  KartStats* kartStats() const;
  BSP* bsp() const;
  BspHitbox* bspHitboxes() const;
  BspWheel* bspWheel(s32 idx) const;

  KartModel* kartModel();
  u8 getPlayerIdx() const;
  KartAction* kartAction();
  const KartAction* kartAction() const;
  bool hasCamera();
  void setCamera(KartCamera* camera);
  void empty();
  KartAccessor_54* kartAccessor_54();
  KartBlink* kartBlink();
  const KartBlink* kartBlink() const;
  KartAccessor_5c* kartAccessor_5c();
  KartEnemy* kartEnemy();
  KartAccessor_44* kartAccessor_44();
  KartAccessor_48* kartAccessor_48();
  KartNetSender* kartNetSender();
  KartNetReceiver* kartNetReceiver();
  BoxColUnit* kartEntity();
  KartAccessor_50* kartAccessor_50();
  KartAccessor_60* kartAccessor_60();
  const KartHalfPipe* kartHalfPipe();
  const KartJump* kartJump();

  const EGG::Vector3f& getPos() const;
  const EGG::Vector3f& getPrevPos() const;
  void setPos(const EGG::Vector3f &pos);
  const EGG::Matrix34f& getPose() const;
  const EGG::Matrix34f& getBodyRot() const;
  void setRot(const EGG::Quatf& rot);
  u16 getSuspCount();
  u16 getWheelCount();
  float getWheelCountRecip();
  float getWheelCountPlusOneRecip();
  const EGG::Vector3f& getWheelPos(u32 wheelIdx);
  bool wheelIdxHasFloorCollision(u32 wheelIdx);
  void setBodyAngle(f32 angle);
  void setStartBoostIdx(s32 idx);
  const EGG::Vector3f& getWheelEdgePos(u32 wheelIdx);
  System::KPad* getInput();
  bool isLocal();
  bool isCpu();
  bool isGhost();
  void getBodyForward(EGG::Vector3f& out);
  s32 getHopStickX();
  s32 getAppliedHopStickX();
  f32 getVehicleSpeed();
  void empty(s16 arg);
  void clearBoost();
  f32 getSpeedRatioCapped();
  f32 getSpeedRatio();
  f32 getBaseSpeed();
  s16 getDriftState();
  s16 getMtCharge();
  s16 getSmtCharge();
  s16 getMaxMtCharge();
  s16 getMaxSmtCharge();
  bool isDrivingIdle();
  s16 getBackwardsAllowCounter();
  void setScale(const EGG::Vector3f& scale);
  const EGG::Vector3f& getScale();
  // Tentative name
  bool inRespawn();
  // Unused, and the KartMove flags are not documented
  bool isSomeMoveFlagActive();
  bool isCpu() const;
  KartInput& getInput() const;

  static void InitList();
  static void SetupInList(KartAccessor* accessor);

private:
  inline KartObjectProxy(const KartObjectProxy&) {}
  static nw4r::ut::List sList;
  KartAccessor* mAccessor;
  nw4r::ut::Node mNode;
};

} // namespace Kart
/* end "kart/KartObjectProxy.hpp" */
/* "src\kart\KartState.hpp" line 7 "system/RKBitField.hpp" */

#pragma once

#define NBITS32 32

/* "src\system\RKBitField.hpp" line 5 "rk_types.h" */
/* end "rk_types.h" */

template <size_t N>
class RKBitField {
public:
    RKBitField() {
        for (int i = 0; i < sizeof(mFields) / sizeof(mFields[0]); ++i) {
            mFields[i] = 0;
        }
    }

    bool on(size_t n) const {
        return mFields[n / NBITS32] & (1 << (n % NBITS32));
    }

    void set(size_t n) { mFields[n / NBITS32] |= (1 << (n % NBITS32)); }
    void reset(size_t n) { mFields[n / NBITS32] &= ~(1 << (n % NBITS32)); }
    u32& field(size_t n) { return mFields[n]; }

private:
    u32 mFields[(((u32)(N) + 32 - 1) & ~( 32 - 1)) / NBITS32];
};
/* end "system/RKBitField.hpp" */
/* "src\kart\KartState.hpp" line 8 "system/RaceConfig.hpp" */
#pragma once

/* "src\system\RaceConfig.hpp" line 2 "host_system/ParameterFile.hpp" */
/*!
 * @file ParameterFile.hpp
 * @brief Contains reading code for an unused 'Parameter' file.
 */

#pragma once

/* "src\host_system\ParameterFile.hpp" line 7 "rk_types.h" */
/* end "rk_types.h" */
/* "src\host_system\ParameterFile.hpp" line 8 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */
/* "src\host_system\ParameterFile.hpp" line 9 "nw4r/ut/utList.hpp" */
/* end "nw4r/ut/utList.hpp" */

namespace System {

class ParameterFile {
public:
  ParameterFile(const char* path, u32 other);
  virtual ~ParameterFile();

  virtual void read(EGG::Heap* heap);
  s32 emptySub0();
  virtual void emptySub1();
  virtual void emptySub2();
  virtual void emptySub3();

  void appendData(char* str, u32 str_size, EGG::Heap* heap);

  template <typename T> void append(T& obj, EGG::Heap* heap) {
    appendData(reinterpret_cast<char*>(&obj), sizeof(obj), heap);
  }

private:
  class StringView {
  public:
    inline void set(char* begin, u32 size) {
      mData = begin;
      mSize = size;
    }

    inline const char* data() const { return mData; }
    inline char* data() { return mData; }
    inline u32 size() const { return mSize; }

    nw4r::ut::Node mNode;

  private:
    char* mData;
    u32 mSize;
  };

  inline StringView* nextString(StringView* string) {
    void* nextObj = nw4r::ut::List_GetNext(&mStrings, string);

    return reinterpret_cast<StringView*>(nextObj);
  }

  nw4r::ut::List mStrings; // 04
  u32 mTotalAllocated;     // 10
  const char* mPath;       // 14
  u32 _18;                 // 18
};

} // namespace System
/* end "host_system/ParameterFile.hpp" */
/* "src\system\RaceConfig.hpp" line 3 "system/Competition.hpp" */
#pragma once

/* "src\system\Competition.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */
/* "src\system\Competition.hpp" line 3 "decomp.h" */
/* end "decomp.h" */

namespace System {

// More info: https://wiki.tockdom.com/wiki/Mission_Mode#Objectives
enum MissionObjective {
  OBJECTIVE_MINITURBO,
  OBJECTIVE_LAPRUN01,
  OBJECTIVE_LAPRUN02,
  OBJECTIVE_DRIFT,
  OBJECTIVE_ITEMBOX,
  OBJECTIVE_ENEMYDOWN01,
  OBJECTIVE_ENEMYDOWN02,
  OBJECTIVE_ENEMYDOWN03,
  OBJECTIVE_COINGET01,
  OBJECTIVE_TOGATE01,
  OBJECTIVE_ROCKETSTART,
  OBJECTIVE_ITEMHIT,
  OBJECTIVE_WHEELIE,
  OBJECTIVE_SLIPSTREAM,
  OBJECTIVE_DEFAULT = -1
};

// The game mode ID used specifically for competitions.
// More info: https://wiki.tockdom.com/wiki/RKC_(File_Format)#Game_Modes
enum CompetitionObjective {
  COMPETITION_TIME_TRIAL,
  COMPETITION_VS_RACE,
  COMPETITION_ENEMYDOWN01 = 3,
  COMPETITION_ENEMYDOWN02,
  COMPETITION_COINGET01,
  COMPETITION_TOGATE01,
  COMPETITION_ROCKETSTART,
  COMPETITION_ITEMHIT,
  COMPETITION_LAPRUN01 = 11,
  COMPETITION_LAPRUN02
};

struct CharacterVehicleChoice {
  s8 characterId;
  s8 vehicleId;
};

struct RawRKCO {
  char rkcoMagic[4];
  u16 competitionType;
  u8 courseId;
  u8 engineClass;
  u8 numLaps;
  u8 field9_0x09;
  u16 vehicleRestriction;
  u16 cameraAngle;
  u16 minimapObject;
  u16 horizontalWallGlitch;
  u16 field14_0x12;
  u16 cannonFlag;
  u16 cpuCount;
  CharacterVehicleChoice cpuCombos[11];
  u8 controllerRestriction;
  u8 field19_0x2f;
  u16 objectFiles;
  u16 score;
  u8 introSetting;
  u8 field23_0x35;
  /* Maximum time allowed for the competition record to be uploaded to the rankings.
     See 80510ab8
  */
  u16 maxUploadTime;
  u16 field25_0x38;
  u16 field26_0x3a;
};

struct RawCompetitionFile {
  char rkctMagic[4];
  s32 dataLength;
  s32 headerLength;
  s32 field3_0xc;
  RawRKCO rkco;
  inline u16 getSize() { return min32(11, rkco.cpuCount); }
};

struct CompetitionWrapper {
  bool isValid;
  RawCompetitionFile* fileRaw;
  s32 competitionId;
  s32 state;
  wchar_t* titleText;
  s32 titleTextLength;
  bool competitionUnavailable;
  s32 field10_0x1c;
};

// Also known as "KMT Scenario Entry". See https://wiki.tockdom.com/wiki/Mission_Mode#mission_single.kmt
struct CompetitionSettings {
  u16 mrFile; /* Mission Run file in Mission Mode (e.g. 3 -> mr03.szs) */
  u16 objective;  /* See the MissionObjective enum */
  u8 courseId;
  u8 characterId;
  u8 vehicleId;
  u8 engineClass;
  u8 field5_0x8[36]; /* unknown padding */
  u16 timeLimit;
  u8 field_0x2e;
  u8 controllerRestriction;
  u32 scoreRequired;  /* Score required to beat the competition */
  u32 rankScores[5];  /* Scores required to get a rank (only meant for Mission Mode) */
  u16 cameraAngle;
  u16 minimapObject;
  u16 horizontalWallGlitch;
  u16 field11_0x4e;
  u16 cannonFlag;
  u8 field13_0x52[6]; /* unknown padding */
  u16 cpuCount;
  CharacterVehicleChoice cpuCombos[11]; /* one for each CPU */

  inline void cpuCombosFromFile(RawCompetitionFile* file) {
    for (u8 i = 0; i < file->getSize(); i++) {
      this->cpuCombos[i] = file->rkco.cpuCombos[i];
    }
  }

  inline void cpuCombosFromWrapper2(const CompetitionWrapper& wrapper) {
    this->cpuCombosFromFile(wrapper.fileRaw);
  }
  
  inline void cpuCombosFromWrapper(const CompetitionWrapper& wrapper) {
    this->cpuCombosFromWrapper2(wrapper);
  }
};

} // namespace System
/* end "system/Competition.hpp" */
/* "src\system\RaceConfig.hpp" line 4 "system/GhostFile.hpp" */
/* end "system/GhostFile.hpp" */
/* "src\system\RaceConfig.hpp" line 5 "system/Mii.hpp" */
/* end "system/Mii.hpp" */
/* "src\system\RaceConfig.hpp" line 6 "system/ResourceManager.hpp" */
/* end "system/ResourceManager.hpp" */
/* "src\system\RaceConfig.hpp" line 7 "system/KPadDirector.hpp" */
#pragma once

/* "src\system\KPadDirector.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\system\KPadDirector.hpp" line 4 "rk_common.h" */
/* end "rk_common.h" */

/* "src\system\KPadDirector.hpp" line 6 "decomp.h" */
/* end "decomp.h" */

/* "src\system\KPadDirector.hpp" line 8 "rvl/pad/pad.h" */
/* end "rvl/pad/pad.h" */

/* "src\system\KPadDirector.hpp" line 10 "system/KPadController.hpp" */
/* end "system/KPadController.hpp" */

namespace System {
// Temporary definition
struct RumbleManager {
  u8 _00[0x10];
};

class KPadDirector {
public:
  enum eControllerType {

    //! @brief Wiimote, Nunchuck or Classic
    CONTROLLER_TYPE_WII = 0,

    //! @brief Gamecube
    CONTROLLER_TYPE_GC = 1,

    CONTROLLER_TYPE_OTHER = 3,
  };

public:
  static KPadDirector* spInstance;

  static KPadDirector* createInstance();
  static void destroyInstance();

  static void syncDeviceCallback(int result);

  static eControllerType getControllerType(eControlSource controlSource);

public:
  KPadDirector();
  virtual ~KPadDirector() {}                      // [vt+0x08]

  void initialize();

  void resetPlayersActivityStatus();
  bool checkPlayerActivityStatus(u8 playerIdx,
                                 u16 maxInactiveFrames,
                                 u16 maxDisconnectedFrames);

  void reset();
  void reset2(); // inlined in reset

  void stopAllMotors();
  void stopAllMotors2(); // stop gc motors first instead of wii motors first...

  void readPads();

  void calcControllers(bool isPaused);
  void calc();

  bool setController(KPad* dest, eControllerType type,
                     u8 playerIdx, bool noSet);
  bool copyController(KPad* dest, KPad* source, bool noSet);

  bool initMasterController();
  bool setPlayerToMasterController(u8 playerIdx);
  void resetMasterController();

  bool initPlayerController(u8 playerIdx, bool noSet = false);
  bool setMasterToPlayerController(u8 playerIdx);
  void resetPlayerController(u8 playerIdx);
  void resetPlayerControllers();
  u32 initPlayerControllers();
  void setPlayerController(u8 playerIdx, eControlSource controlSource,
                           u8 controllerIdx);

  void setGhostController(u8 playerIdx);
  void setGhostController(u8 playerIdx, u16* ghostBuffer, bool driftIsAuto);

  void lockGhostProxies();
  void startGhostProxies();
  void endGhostProxy(u8 playerIdx);
  void endGhostProxies();

  u32 getPadStatus(u8 padIdx, PADStatus* dest = nullptr);

  void loadRumbleSettings();
  void unloadRumbleSettings();

  void syncDeviceCallbackImpl(int result); // inlined in syncDeviceCallback
  void startSync();
  void stopSync();

  void enableDpds(bool* prevStates);
  void restoreDpds(bool* prevStates);

public:
  KPadPlayer mPlayers[4];                         // [this+0x0004]
  KPadAI mAIs[MAX_PLAYER_COUNT];                  // [this+0x03b4]
  KPad mMaster;                                   // [this+0x15b4]
  bool _168c;
  u8 _168d;
  u8 _168e;
  u8 _168f;
  KPadDummyController mDummyController;           // [this+0x1690]
  KPadWiiController mWiiControllers[4];           // [this+0x1720]
  KPadGCController mGCControllers[4];             // [this+0x3ba0]
  KPadGhostController mGhostControllers[4];       // [this+0x3e60]
  RumbleManager mRumbleManager;                   // [this+0x4100]
  u8 _4110[0x10];
  PADStatus mPadStatuses[4];                      // [this+0x4120]
  u32 _4150;
  bool mIsPaused;                                 // [this+0x4154]
  bool mIsMirror;                                 // [this+0x4155]
  u8 _4156;
  u8 _4157;
  s32 _4158; // WPAD sync related
};

static_assert(sizeof(KPadDirector) == 0x415c);
} // namespace System
/* end "system/KPadDirector.hpp" */
/* "src\system\RaceConfig.hpp" line 8 "system/InitScene.hpp" */
#pragma once

/* "src\system\InitScene.hpp" line 2 "host_system/RKScene.hpp" */
#pragma once

/* "src\host_system\RKScene.hpp" line 2 "egg/core/eggExpHeap.hpp" */
/* end "egg/core/eggExpHeap.hpp" */
/* "src\host_system\RKScene.hpp" line 3 "egg/core/eggScene.hpp" */
/*!
 * @file
 * @brief TODO
 */

#pragma once

/* "lib\egg\core\eggScene.hpp" line 7 "egg/core/eggDisposer.hpp" */
/* end "egg/core/eggDisposer.hpp" */
/* "lib\egg\core\eggScene.hpp" line 8 "egg/core/eggHeap.hpp" */
/* end "egg/core/eggHeap.hpp" */
/* "lib\egg\core\eggScene.hpp" line 9 "rk_types.h" */
/* end "rk_types.h" */

namespace EGG {

class SceneManager;

// HACK: Only the first instance of this symbol will be kept
#ifndef EGGSCENE_INLINEBODY
#define EGGSCENE_INLINEBODY ;
#else
#undef EGGSCENE_INLINEBODY
#define EGGSCENE_INLINEBODY                                                    \
  {}
#endif

class Scene : public Disposer {
public:
  virtual ~Scene(); //! [vt+0x08] Virtual destructor.

  virtual void calc() EGGSCENE_INLINEBODY                      //! [vt+0x0C]
      virtual void draw() EGGSCENE_INLINEBODY                  //! [vt+0x10]
      virtual void enter() EGGSCENE_INLINEBODY                 //! [vt+0x14]
      virtual void exit() EGGSCENE_INLINEBODY                  //! [vt+0x18]
      virtual void reinit() EGGSCENE_INLINEBODY                //! [vt+0x1C]
      virtual void incoming_childDestroy() EGGSCENE_INLINEBODY //! [vt+0x20]
      virtual void outgoing_childCreate() EGGSCENE_INLINEBODY  //! [vt+0x24]

      //! @brief Constructor
      Scene();

private:
  // -- vt + inherited mContainHeap from Disposer --
  // int _08;    // TODO get name from SceneManager usage
  // Scene* _0C; // TODO get name from SceneManager usage

  Heap* _10; // something like mCreatorHeap? set to Heap::sCurrentHeap in ct
  Heap* mHeapMem1;  //!< [+0x14]
  Heap* mHeapMem2;  //!< [+0x18]
  Heap* mHeapDebug; //!< [+0x1C]

  Scene* pParentScene; //!< [+0x20] name from @see SceneManager::createScene
  Scene* pChildScene;  //!< [+0x24] If non null, destroyed too in destroyScene.
                      //!< childscene?. name from @see SceneManager::createScene

  int mID;                 //!< [+0x28]
  SceneManager* pSceneMgr; //!< [+0x2C] @see SceneManager::createScene

public:
  // inlines. actually above exit and below enter
  inline void setSceneMgr(SceneManager* mgr) { this->pSceneMgr = mgr; }
  inline void setParentScene(Scene* scene) { this->pParentScene = scene; }
  inline void setSceneID(int ID) { this->mID = ID; }
  inline void setChildScene(Scene* scene) { pChildScene = scene; }

  inline const Scene* getParentScene() const { return pParentScene; }
  inline Scene* getParentScene() { return pParentScene; }

  inline int getSceneID() const { return mID; }

  inline const Heap* getHeap() const { return _10; }
  inline Heap* getHeap() { return _10; }

  inline const Heap* getHeap_Mem1() const { return mHeapMem1; }
  inline Heap* getHeap_Mem1() { return mHeapMem1; }

  inline const Scene* getChildScene() const { return pChildScene; }
  inline Scene* getChildScene() { return pChildScene; }

  inline const SceneManager* getSceneMgr() const { return pSceneMgr; }
  inline SceneManager* getSceneMgr() { return pSceneMgr; }

  inline const Heap* getHeap_Mem2() const { return mHeapMem2; }
  inline Heap* getHeap_Mem2() { return mHeapMem2; }

  // not yet found in symbol maps, but needed
  inline const Heap* getHeap_Debug() const { return mHeapDebug; }
  inline Heap* getHeap_Debug() { return mHeapDebug; }
};

} // namespace EGG
/* end "egg/core/eggScene.hpp" */

// TODO: These likely align with the resource archives in Scene\UI

//! Unique game scene IDs
enum RKSceneID {
  SCENE_UNK3 = 3,
  SCENE_UNK6 = 6,
  SCENE_UNK7 = 7,
  SCENE_UNK8 = 8,
  SCENE_UNK9 = 9,
  SCENE_UNK10 = 10,
  SCENE_UNK11 = 11,

  // --- <SceneCreatorREL>
  RK_SCENE_ID_GAME_START = 0, //!< Called when REL first loaded; "Title" might
                              //!< be a more fitting name*
  RK_SCENE_ID_MAIN_MENU = 1,  //!< "メニューシーン" -> "Menu Scene"
  RK_SCENE_ID_RACE = 2,       //!< "レースシーン" -> "Race Scene"

  RK_SCENE_ID_MULTI = 4, //!< "地球儀シーン" -> "Globe Scene"

  // --- <SceneCreatorStatic>
  RK_SCENE_ID_BOOTSTRAP =
      5, //!< Root scene loaded immediately after initializing the system.
  // --- </SceneCreatorStatic>

  RK_SCENE_ID_FLAG_OPEN = 12 //!< "フラグオープンシーン" -> "Flag Open Scene"
  // --- </SceneCreatorREL>
};

//! Certain heap allocations are tracked to a given memory budgeting category.
enum RKHeapTag {
  RK_HEAP_TAG_DEFAULT = 0x0,
  RK_HEAP_TAG_RACE_DATA = 0x1,
  RK_HEAP_TAG_MISC_SINGLETON = 0x2, // Rendering?
  RK_HEAP_TAG_3 = 0x3,
  RK_HEAP_TAG_RACE_GEO_OBJ = 0x4,
  RK_HEAP_TAG_RACE_JMAP_AND_MDL = 0x5,
  RK_HEAP_TAG_MENU = 0x6,
  RK_HEAP_TAG_EFFECT = 0x7,
  RK_HEAP_TAG_AUDIO = 0x8,
  RK_HEAP_TAG_9 = 0x9,
  RK_HEAP_TAG_RES = 0xA,
  RK_HEAP_TAG_HBM = 0xB,
  RK_HEAP_TAG_12 = 0xC,
  RK_HEAP_TAG_NETWORKING = 0xD
};

struct HeapCollection {
  enum eHeapId { HEAP_ID_MEM1, HEAP_ID_MEM2, HEAP_ID_DEBUG, HEAP_ID_NUM };
  EGG::ExpHeap* mpHeaps[HEAP_ID_NUM];
  EGG::ExpHeap::GroupSizeRecord mRecords[HEAP_ID_NUM];

  void setGroupIdAll(s32 id); // RKHeapTag

  inline HeapCollection() {
    mpHeaps[HeapCollection::HEAP_ID_MEM1] = NULL;
    mpHeaps[HeapCollection::HEAP_ID_MEM2] = NULL;
    mpHeaps[HeapCollection::HEAP_ID_DEBUG] = NULL;
  }
};

class RKScene : public EGG::Scene {
public:
  virtual ~RKScene() override {}
  inline RKScene() { setHeaps(); }
  inline void dummy(EGG::ExpHeap*);
  inline void setHeaps() {
    EGG::ExpHeap* a[3];

    a[0] = downcast(getA());
    a[1] = downcast(getB());
    a[2] = downcast(getC());
    setm1(a[0]);
    setm2(a[1]);
    setd(a[2]);
  }
  inline EGG::Heap* getA() {
    return mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_MEM1];
  }
  inline EGG::Heap* getB() {
    return mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_MEM2];
  }
  inline EGG::Heap* getC() {
    return mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_DEBUG];
  }
  inline EGG::ExpHeap* getDbgHeap() {
    return downcast(mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_DEBUG]);
  }
  inline void setm1(EGG::ExpHeap* a) {
    mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_MEM1] = a;
  }
  inline void setm2(EGG::ExpHeap* a) {
    mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_MEM2] = a;
  }
  inline void setd(EGG::ExpHeap* a) {
    mHeapCollection.mpHeaps[HeapCollection::HEAP_ID_DEBUG] = a;
  }
  // Perhaps not the best spot
  inline EGG::ExpHeap* downcast(EGG::Heap* pHeap) {
    if (pHeap && pHeap->getHeapKind() == EGG::Heap::HEAP_KIND_EXPANDED)
      return reinterpret_cast<EGG::ExpHeap*>(pHeap);
    else
      return 0;
  }
  HeapCollection mHeapCollection; // 0x30
  // 0xc3c
  unk8 _c3c[0xc70 - 0xc3c];
};
/* end "host_system/RKScene.hpp" */

namespace System {

// Incorrect name, but is a placeholder for RaceConfigPlayer::appendParamFile
class InitScene : public RKScene {
  virtual ~InitScene();
  virtual void calc();

public:
  static InitScene* spInstance;
};

} // namespace System
/* end "system/InitScene.hpp" */
/* "src\system\RaceConfig.hpp" line 9 "system/Rating.hpp" */
#pragma once

/* "src\system\Rating.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

namespace System {

class Rating {
public:
  Rating() { mPoints = 5000; }
  virtual ~Rating() {}
  u16 getPoints() const { return mPoints; }

  static f32 calc(f32 x, s32 unused);
  static f32 calcSpline(f32 x, s32 termIdx);
  static f32 calcPoints(s16 difference, bool isPos);
  s16 calcPosPoints(const Rating& opponent) const;
  s16 calcNegPoints(const Rating& opponent) const;
  void updatePoints(s32 points);

private:
  u16 mPoints;
};

} // namespace System
/* end "system/Rating.hpp" */

/* "src\system\RaceConfig.hpp" line 11 "rk_types.h" */
/* end "rk_types.h" */
/* "src\system\RaceConfig.hpp" line 12 "rk_common.h" */
/* end "rk_common.h" */

/* "src\system\RaceConfig.hpp" line 14 "decomp.h" */
/* end "decomp.h" */

namespace System {

enum CupId {
  MUSHROOM_CUP,
  FLOWER_CUP,
  STAR_CUP,
  SPECIAL_CUP,
  SHELL_CUP,
  BANANA_CUP,
  LEAF_CUP,
  LIGHTNING_CUP,
};

class RaceConfigEx {
public:
  inline RaceConfigEx() {}
};

class RaceConfig : public RaceConfigEx, public ParameterFile {
public:
  class Player {
  public:
    enum Type {
      TYPE_REAL_LOCAL,
      TYPE_CPU,
      TYPE_UNUSED,
      TYPE_GHOST,
      TYPE_REAL_ONLINE,
      TYPE_NONE,
    };

    Player();
    virtual ~Player();

    void appendParamFile(RaceConfig* raceConfig);
    s32 computeGpRank() const;
    void reset(s8 pos);

    CharacterId getCharacter();
    Mii& getMii();
    const Type getPlayerType() const;

    BattleTeam getTeam();
    u8 getUnkPos();
    VehicleId getVehicle();

    void setCharacter(CharacterId character);
    void setMii(const Mii& mii);
    void setPlayerType(Type playerType);
    void setPrevFinishPos(s8 pos);
    void setUnkPos(s8 pos);
    void setVehicle(VehicleId vehicle);

    unk8 _04;
    s8 mLocalPlayerNum;
    s8 mPlayerInputIdx;
    VehicleId mVehicleId;
    CharacterId mCharacterId;
    Type mPlayerType;
    Mii mMii;
    BattleTeam mTeam;
    s32 mControllerId;
    unk32 _d4;
    u16 mPreviousScore;
    u16 mGpScore;
    u16 _dc;
    s16 mGpRankScore;
    unk8 _e0;
    u8 mPrevFinishPos;
    u8 mFinishPos;
    Rating mRating;
    s8 _ec;
  };

  struct Settings {
    enum GameMode {
      GAMEMODE_GRAND_PRIX,
      GAMEMODE_VS_RACE,
      GAMEMODE_TIME_TRIAL,
      GAMEMODE_BATTLE,
      GAMEMODE_MISSION_TOURNAMENT,
      GAMEMODE_GHOST_RACE,
      GAMEMODE_UNKNOWN,
      GAMEMODE_PRIVATE_VS,
      GAMEMODE_PUBLIC_VS,
      GAMEMODE_PUBLIC_BATTLE,
      GAMEMODE_PRIVATE_BATTLE,
      GAMEMODE_AWARDS,
      GAMEMODE_CREDITS,
    };

    enum CameraMode {
      CAMERA_MODE_GAMEPLAY_NO_INTRO,
      CAMERA_MODE_REPLAY,
      CAMERA_MODE_TITLE_ONE_PLAYER,
      CAMERA_MODE_TITLE_TWO_PLAYER,
      CAMERA_MODE_TITLE_FOUR_PLAYER,
      CAMERA_MODE_GAMEPLAY_INTRO,
      CAMERA_MODE_LIVE_VIEW,
      CAMERA_MODE_GRAND_PRIX_WIN,
      CAMERA_MODE_SOLO_VS_WIN,
      CAMERA_MODE_TEAM_VS_WIN,
      CAMERA_MODE_BATTLE_WIN,
      CAMERA_MODE_UNK_11,
      CAMERA_MODE_LOSS,
    };

    enum ModeFlags {
      MODE_FLAG_MIRROR = 1,
      MODE_FLAG_TEAMS = 2,
      MODE_FLAG_COMPETITION = 4,
    };

    inline Settings& operator=(const Settings& other) {
      mCourseId = other.mCourseId;
      mEngineClass = other.mEngineClass;
      mGameMode = other.mGameMode;
      mCameraMode = other.mCameraMode;
      mBattleType = other.mBattleType;
      mCpuMode = other.mCpuMode;
      mItemMode = other.mItemMode;
      mHudPlayerIds[0] = other.mHudPlayerIds[0];
      mHudPlayerIds[1] = other.mHudPlayerIds[1];
      mHudPlayerIds[2] = other.mHudPlayerIds[2];
      mHudPlayerIds[3] = other.mHudPlayerIds[3];
      mCupId = other.mCupId;
      mRaceNumber = other.mRaceNumber;
      mLapCount = other.mLapCount;
      mModeFlags = other.mModeFlags;
      mSeed1 = other.mSeed1;
      mSeed2 = other.mSeed2;
      return *this;
    }

    CourseId mCourseId;
    u32 mEngineClass; // probably an enum
    GameMode mGameMode;
    CameraMode mCameraMode;
    u32 mBattleType;
    u32 mCpuMode;
    u32 mItemMode;
    s8 mHudPlayerIds[4];
    CupId mCupId;
    u8 mRaceNumber;
    u8 mLapCount;
    ModeFlags mModeFlags;
    u32 mSeed1;
    u32 mSeed2;
  };

  class Scenario {
  public:
    Scenario(RawGhostFile* ghost);
    virtual ~Scenario();

    Scenario& copy(const Scenario& other);

    void appendParamFile(RaceConfig* raceConfig);
    void clear();
    void computePlayerCounts(u8& playerCount, u8& hudCount,
                             u8& localPlayerCount);
    BattleTeam computeWinningTeam();
    void copyPrevPositions();
    void initCompetitionSettings();
    void initControllers(u8 controllerCount);
    bool initGhost(u8 playerIdx, s8 playerInputIdx);
    void initPlayers(u8 playerCount);
    void initRace(Scenario* scenario);
    void initRng();
    bool isTeamMode();
    void postInitControllers(Scenario* scenario);
    void resetPlayers();
    u8 update();

    Settings::CameraMode getCameraMode();
    const Player& getPlayer(u8 idx) const;
    Player& getPlayer(u8 idx);
    inline const Player::Type getPlayerType(u8 idx) const { return mPlayers[idx].mPlayerType; }
    inline BattleTeam getPlayerTeam(u8 idx) { return mPlayers[idx].mTeam; }

    inline bool isOnline(Settings::GameMode mode) {
      bool ret = false;
      switch ((Settings::GameMode)(u32)mode) {
      case Settings::GAMEMODE_PRIVATE_VS:
      case Settings::GAMEMODE_PUBLIC_VS:
      case Settings::GAMEMODE_PUBLIC_BATTLE:
      case Settings::GAMEMODE_PRIVATE_BATTLE:
        ret = true;
      }
      return ret;
    }

    u8 mPlayerCount;
    u8 mHudCount;
    u8 mLocalPlayerCount;
    u8 mHudCount2; // ?
    Player mPlayers[MAX_PLAYER_COUNT];
    Settings mSettings;
    CompetitionSettings mCompetitionSettings;
    RawGhostFile* mGhost;
  };

  RaceConfig();
  ~RaceConfig() override;

  void clear();
  void init();
  void initRace();
  bool isLiveView(u8 hudPlayerIdx);
  bool isTimeAttackReplay();
  void loadNextCourse();
  u8 update();
  s16 updateRating(u8 playerIdx);

  s8 getHudPlayerId(u8 playerIdx);
  s32 getLocalPlayerCount(u8 playerIdx);

  void setGhost(RawGhostFile* ghost);

  static const u8 getRacePlayerCount();
  static RaceConfig* createInstance();
  static void destroyInstance();

  static RaceConfig* spInstance;

  Scenario mRaceScenario;
  Scenario mMenuScenario;
  Scenario mAwardsScenario;
  RawGhostFile mGhosts[2];
};

} // namespace System
/* end "system/RaceConfig.hpp" */
/* "src\kart\KartState.hpp" line 9 "system/RaceManager.hpp" */
#pragma once

/* "src\system\RaceManager.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\system\RaceManager.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\system\RaceManager.hpp" line 6 "KPadDirector.hpp" */
/* end "KPadDirector.hpp" */
/* "src\system\RaceManager.hpp" line 7 "GhostFile.hpp" */
/* end "GhostFile.hpp" */
/* "src\system\RaceManager.hpp" line 8 "CourseMap.hpp" */
#pragma once

/* "src\system\CourseMap.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\system\CourseMap.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\system\CourseMap.hpp" line 6 "stddef.h" */
/* end "stddef.h" */

/* "src\system\CourseMap.hpp" line 8 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "src\system\CourseMap.hpp" line 9 "egg/math/eggQuat.hpp" */
/* end "egg/math/eggQuat.hpp" */

namespace System {

struct KmpSectionHeader {
  s32 sectionMagic;
  u16 entryCount;
  const s8 extraValue;
};

// TODO: Cleanup
template <typename T, typename TData> class MapdataAccessorBase {
public:
  T** entries;                           //!< [+0x00]
  u16 numEntries;                        //!< [+0x04]
  const KmpSectionHeader* sectionHeader; //!< [+0x08]

  /*const TData *cdata(size_t i) const {
      if (i < 0 || i > numEntries) {
          return nullptr;
      }
      return entryAccessors[i]->m_data;
  }*/
  MapdataAccessorBase(const KmpSectionHeader* header)
      : entries(nullptr), numEntries(0), sectionHeader(header) {}
  T* get(u16 i) const {
    return i < this->numEntries ? this->entries[i] : nullptr;
  }
  s8 getExtraValue() const;
  u16 size() const { return numEntries; }

  inline void init(const TData* start, u16 count) {
    if (count != 0) {
      numEntries = count;
      entries = new T*[count];
    }
    for (u16 i = 0; i < count; i++) {
      entries[i] = new T(&start[i]);
    }
  }
};
// The template will always be the same size
static_assert(sizeof(MapdataAccessorBase<unk, unk>) == 0xc);

// Despite the rest of the file being in alphabetical order, MapdataArea classes
// have been moved just above the accessor classes due to vtable ordering

// We also have to move MapdataPointInfo above MapdataGeoObj
class MapdataPointInfo {
public:
  struct SData {
    struct Point {
      EGG::Vector3f pos;
      u16 settings[2];
    };

    u16 pointCount;
    u8 settings[2];
    Point points[];
  };

  MapdataPointInfo(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataPointInfo) == 0x4);

class MapdataCamera {
public:
  struct SData {
    u8 cameraType;
    u8 cameraNext;
    u8 cameraShake;
    u8 pathID;
    u16 pathSpeed;
    u16 fovYSpeed;
    u16 viewSpeed;
    u8 startFlag;
    u8 movieFlag;
    EGG::Vector3f position;
    EGG::Vector3f rotation;
    f32 fovYStart;
    f32 fovVYEnd;

    EGG::Vector3f viewStart;
    EGG::Vector3f viewEnd;

    f32 time;
  };

  MapdataCamera(const SData* data) : mpData(data) {}
  u8 getCameraType() const;

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataCamera) == 0x4);

class MapdataCannonPoint {
public:
  struct SData {
    EGG::Vector3f position;
    EGG::Vector3f rotation;
    u16 id;
    u16 shootEffect;
  };

  MapdataCannonPoint(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataCannonPoint) == 0x4);

class MapdataCheckPath {
public:
  struct SData {
    u8 start;
    u8 size;

    u8 last[6];
    u8 next[6];
  };

  MapdataCheckPath(const SData* data);

private:
  SData* mpData;
  u8 _04[0x0c - 0x04];
};
static_assert(sizeof(MapdataCheckPath) == 0xc);

class MapdataCheckPoint;
struct LinkedCheckpoint {
  MapdataCheckPoint* checkpoint;
  EGG::Vector2f p0diff;
  EGG::Vector2f p1diff;
  f32 distance;
};
class MapdataCheckPoint {
public:
  struct SData {
    EGG::Vector2f left;
    EGG::Vector2f right;
    u8 jugemIndex;
    u8 lapCheck;
    u8 prevPt;
    u8 nextPt;
  };
  enum Completion {
    Completion_0,
    Completion_1,
    Completion_2,
  };
  MapdataCheckPoint(const SData* data);
  Completion checkSectorAndDistanceRatio(const EGG::Vector3f& pos,
                                         f32* distanceRatio) const;
  bool isPlayerFlagged(s32 playerIdx) const { return mFlags & 1 << playerIdx; }
  void setPlayerFlags(s32 playerIdx) { mFlags |= 1 << playerIdx; }
  void resetFlags() { mFlags = 0; }
  SData* data() const { return mpData; }
  s32 nextCount() const { return mNextCount; }
  s32 prevCount() const { return mPrevCount; }
  s32 id() const { return mId; }
  MapdataCheckPoint* prevPoint(s32 i) const { return mpPrevPoints[i]; }
  const LinkedCheckpoint& nextPoint(s32 i) const { return mNextPoints[i]; }

private:
  bool checkSector(const LinkedCheckpoint& next, const EGG::Vector2f& p0,
                   const EGG::Vector2f& p1) const;
  bool checkDistanceRatio(const LinkedCheckpoint& next, const EGG::Vector2f& p0,
                          const EGG::Vector2f& p1, f32* distanceRatio) const;
  Completion checkSectorAndDistanceRatio_(const LinkedCheckpoint& next,
                                          const EGG::Vector2f& p0,
                                          const EGG::Vector2f& p1,
                                          f32* distanceRatio) const;
  SData* mpData;
  u16 mNextCount;
  u16 mPrevCount;
  EGG::Vector2f mMidpoint;
  EGG::Vector2f mDir;
  u16 mFlags;
  u16 mId;
  u8 _1c[0x20 - 0x1c];
  MapdataCheckPoint* mpPrevPoints[6];
  LinkedCheckpoint mNextPoints[6];
};
static_assert(sizeof(MapdataCheckPoint) == 0xc8);

class MapdataEnemyPath {
public:
  struct SData {
    u8 start;
    u8 size;
    u8 last[6];
    u8 next[6];
    u8 battle_params[2];
  };

  MapdataEnemyPath(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
  u8 _04[0x0c - 0x04];
};
static_assert(sizeof(MapdataEnemyPath) == 0xc);

class MapdataEnemyPoint {
public:
  struct SData {
    EGG::Vector3f position;
    f32 deviation;
    u8 parameters[4];
  };

  MapdataEnemyPoint(const SData* data) : _08(nullptr), _0c(nullptr), _14(-1) {
    mpData = data;
  }
  virtual ~MapdataEnemyPoint();

private:
  static bool isNonPrivateBattle();

  const SData* mpData;
  unk* _08;
  unk* _0c;
  u8 _10[0x10 - 0x0c];
  u8 _14;
};
static_assert(sizeof(MapdataEnemyPoint) == 0x18);

class MapdataGeoObj {
public:
  struct SData {
    u16 id;
    EGG::Vector3f translation;
    EGG::Vector3f rotation;
    EGG::Vector3f scale;
    s16 pathId;
    u16 settings[8];
    u16 presenceFlag;
  };

  // NOTE: We cannot modify eggVector.hpp without the build failing
  // The dtor is causing a mismatch so this will have to do for now
  struct Vec3 {
    f32 x, y, z;

    inline Vec3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
  };

  MapdataGeoObj(const SData* data) : mpData(data) {
    // Writes to stack and does nothing
    Vec3 _(mpData->translation.x, mpData->translation.y, mpData->translation.z);
  }

  MapdataPointInfo* getPointInfo() const;

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataGeoObj) == 0x4);

class MapdataItemPath {
public:
  struct SData {
    u8 start;
    u8 size;

    u8 last[6];
    u8 next[6];

    u16 _0e; // Required padding
  };

  MapdataItemPath(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataItemPath) == 0x4);

class MapdataItemPoint {
public:
  struct SData {
    EGG::Vector3f position;
    f32 deviation;
    u16 parameters[2];
  };

  MapdataItemPoint(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
  u8 _04[0x14 - 0x04];
};
static_assert(sizeof(MapdataItemPoint) == 0x14);

class MapdataJugemPoint {
public:
  struct SData {
    EGG::Vector3f position;
    EGG::Vector3f rotation;
    u16 id;
    s16 range;
  };

  MapdataJugemPoint(const SData* data);
  virtual ~MapdataJugemPoint();

private:
  SData* mpData;
  u8 _08[0x30 - 0x08];
};
static_assert(sizeof(MapdataJugemPoint) == 0x30);

class MapdataMissionPoint {
public:
  struct SData {
    EGG::Vector3f position;
    EGG::Vector3f rotation;
    u16 id;
  };

  MapdataMissionPoint(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataMissionPoint) == 0x4);

class MapdataStage {
public:
  struct SData {
    u8 mLapCount;     // unused
    u8 mPolePosition; // should only be 0 and 1, but is not a bool
    u8 mStartConfig;  // start position player packing 0: normal, 1: tight
    bool mFlareToggle;
    u32 mFlareColor; // RGB format
    // Pre Revision 2321: End of structure
    u8 mFlareAlpha;
  };

  MapdataStage(const SData* data) : mpData(data) {}
  u8 getStartConfig() const;
  u8 getFlareAlpha() const;
  u32 getFlareColor() const;
  bool flareToggleEnabled() const;

private:
  const SData* mpData;
};
static_assert(sizeof(MapdataStage) == 0x4);

class MapdataStartPoint {
public:
  struct SData {
    EGG::Vector3f position;
    EGG::Vector3f rotation;
    // Pre Revision 1830: End of structure
    s16 playerIndex;
  };

  MapdataStartPoint(const SData* data) : mpData(data) {}

private:
  const SData* mpData;
  s8 mEnemyPoint;
};
static_assert(sizeof(MapdataStartPoint) == 0x8);

class MapdataAreaBase {
public:
  struct SData {
    u8 shape;
    u8 type;
    s8 cameraIdx;
    u8 priority;
    EGG::Vector3f position;
    EGG::Vector3f rotation;
    EGG::Vector3f scale;
    u16 parameters[2];
    // Pre Revision 2200: End of structure
    u8 railID;
    u8 eneLinkID;
  };

  MapdataAreaBase(const SData* data);
  virtual bool isInsideShape(const EGG::Vector3f& pos) const = 0;

  s32 getRouteId() const;
  MapdataPointInfo* getPointInfo() const;
  bool isInside(const EGG::Vector3f& pos) const;
  void setIndex(u16 idx);

protected:
  const SData* mpData;
  EGG::Vector3f mXAxis;
  EGG::Vector3f mYAxis;
  EGG::Vector3f mZAxis;
  EGG::Vector3f mDims;
  // Only used in MapdataAreaCylinder
  f32 mEllipseXRadiusSq;
  f32 mEllipseAspectRatio;
  // Sphere enclosing area for more efficient check if point in area
  f32 mBoundingSphereRadiusSq;
  // Index in MapdataAreaAccessor array
  s16 mIndex;
};
static_assert(sizeof(MapdataAreaBase) == 0x48);

class MapdataAreaBox : public MapdataAreaBase {
public:
  MapdataAreaBox(const SData* data);
  virtual bool isInsideShape(const EGG::Vector3f& pos) const;
};

class MapdataAreaCylinder : public MapdataAreaBase {
public:
  MapdataAreaCylinder(const SData* data);
  virtual bool isInsideShape(const EGG::Vector3f& pos) const;
};

class MapdataAreaAccessor {
public:
  MapdataAreaAccessor(const KmpSectionHeader* header);
  u16 size() const { return numEntries; }

  MapdataAreaBase* get(u16 i) const;
  MapdataAreaBase* getByPriority(u16 i) const {
    if (i < numEntries && this->byPriority) {
      return this->byPriority[i];
    }
    return nullptr;
  }

  MapdataAreaBase** entries;
  u16 numEntries;
  virtual ~MapdataAreaAccessor();
  const KmpSectionHeader* sectionHeader;

private:
  MapdataAreaBase** byPriority;
};
static_assert(sizeof(MapdataAreaAccessor) == 0x14);
// Ensure the vtable does not exist at offset 0x0
// (It should exist at offset 0x8)
static_assert(offsetof(MapdataAreaAccessor, entries) == 0x0);

class MapdataCameraAccessor
    : public MapdataAccessorBase<MapdataCamera, MapdataCamera::SData> {
public:
  MapdataCameraAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataCamera, MapdataCamera::SData>(header) {
    init((const MapdataCamera::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }

  s8 getExtraValue() const;
};

class MapdataCannonPointAccessor
    : public MapdataAccessorBase<MapdataCannonPoint,
                                 MapdataCannonPoint::SData> {
public:
  MapdataCannonPointAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataCannonPoint, MapdataCannonPoint::SData>(
            header) {
    init((const MapdataCannonPoint::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataCheckPathAccessor
    : public MapdataAccessorBase<MapdataCheckPath, MapdataCheckPath::SData> {
private:
  f32 _0c;
};
static_assert(sizeof(MapdataCheckPathAccessor) == 0x10);

class MapdataCheckPointAccessor
    : public MapdataAccessorBase<MapdataCheckPoint, MapdataCheckPoint::SData> {
private:
  u8 _0c[0x14 - 0x0c];
};
static_assert(sizeof(MapdataCheckPointAccessor) == 0x14);

class MapdataEnemyPathAccessor
    : public MapdataAccessorBase<MapdataEnemyPath, MapdataEnemyPath::SData> {
public:
  MapdataEnemyPathAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataEnemyPath, MapdataEnemyPath::SData>(header) {
    init((const MapdataEnemyPath::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataEnemyPointAccessor
    : public MapdataAccessorBase<MapdataEnemyPoint, MapdataEnemyPoint::SData> {
public:
  MapdataEnemyPointAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataEnemyPoint, MapdataEnemyPoint::SData>(
            header) {
    init((const MapdataEnemyPoint::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataGeoObjAccessor
    : public MapdataAccessorBase<MapdataGeoObj, MapdataGeoObj::SData> {
public:
  MapdataGeoObjAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataGeoObj, MapdataGeoObj::SData>(header) {
    init((const MapdataGeoObj::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataItemPathAccessor
    : public MapdataAccessorBase<MapdataItemPath, MapdataItemPath::SData> {
public:
  MapdataItemPathAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataItemPath, MapdataItemPath::SData>(header) {
    init((const MapdataItemPath::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataItemPointAccessor
    : public MapdataAccessorBase<MapdataItemPoint, MapdataItemPoint::SData> {
public:
  MapdataItemPointAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataItemPoint, MapdataItemPoint::SData>(header) {
    init((const MapdataItemPoint::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataJugemPointAccessor
    : public MapdataAccessorBase<MapdataJugemPoint, MapdataJugemPoint::SData> {
public:
  MapdataJugemPointAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataJugemPoint, MapdataJugemPoint::SData>(
            header) {
    init((const MapdataJugemPoint::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }

  MapdataJugemPoint* get(u16 i) const;
};

class MapdataMissionPointAccessor
    : public MapdataAccessorBase<MapdataMissionPoint,
                                 MapdataMissionPoint::SData> {
public:
  MapdataMissionPointAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataMissionPoint, MapdataMissionPoint::SData>(
            header) {
    init((const MapdataMissionPoint::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataPointInfoAccessor
    : public MapdataAccessorBase<MapdataPointInfo, MapdataPointInfo::SData> {
public:
  // We need the init function defined before the constructor
  void init(u16 entryCount) {
    if (entryCount != 0) {
      numEntries = entryCount;
      entries = new MapdataPointInfo*[entryCount];
    }
    if (numEntries != 0) {
      u16 i = 0;
      const MapdataPointInfo::SData* route =
          (const MapdataPointInfo::SData*)sectionHeader + 2;
      for (; i < numEntries; i++) {
        entries[i] = new MapdataPointInfo(route);
        route = route + route->pointCount * 4 + 1;
      }
    }
  }

  // TODO: scheduling conflicts in source
  MapdataPointInfoAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataPointInfo, MapdataPointInfo::SData>(header) {
    init(sectionHeader->entryCount);
  }
};

class MapdataStageAccessor
    : public MapdataAccessorBase<MapdataStage, MapdataStage::SData> {
public:
  MapdataStageAccessor(const KmpSectionHeader* header)
      : MapdataAccessorBase<MapdataStage, MapdataStage::SData>(header) {
    init((const MapdataStage::SData*)(sectionHeader + 1),
         sectionHeader->entryCount);
  }
};

class MapdataStartPointAccessor
    : public MapdataAccessorBase<MapdataStartPoint, MapdataStartPoint::SData> {
public:
  MapdataStartPointAccessor(const KmpSectionHeader* header);

  MapdataStartPoint* get(u16 i) const;
};

class MapdataFileAccessor {
public:
  struct SData {
    u32 magic;
    u32 fileSize;
    u16 numSections;
    u16 headerSize;
    u32 revision;
    s32 offsets[];
  };

  MapdataFileAccessor(const SData* data);
  u32 getVersion() const;
  const KmpSectionHeader* findSection(u32 sectionName) const;

private:
  const SData* mpData;
  u32* mpSectionDef;
  u32 mVersion;
  u32 mSectionDefOffset;
};
static_assert(sizeof(MapdataFileAccessor) == 0x10);

class CourseMap {
public:
  static CourseMap* createInstance();
  static void destroyInstance();
  static inline CourseMap* instance() { return spInstance; }
  static void* loadFile(s32 archiveIdx, const char* filename);

  inline u32 getVersion() const { return mpCourse->getVersion(); }

  MapdataAreaBase* getArea(u16 i) const;
  MapdataAreaBase* getAreaByPriority(u16 i) const;
  MapdataCannonPoint* getCannonPoint(u16 i) const;
  MapdataCamera* getCamera(u16 i) const;
  MapdataCheckPoint* getCheckPoint(u16 i) const;
  MapdataCheckPath* getCheckPath(u16 i) const;
  MapdataEnemyPath* getEnemyPath(u16 i) const;
  MapdataEnemyPoint* getEnemyPoint(u16 i) const;
  MapdataGeoObj* getGeoObj(u16 i) const;
  MapdataItemPoint* getItemPoint(u16 i) const;
  MapdataItemPath* getItemPath(u16 i) const;
  MapdataJugemPoint* getJugemPoint(u16 i) const;
  MapdataMissionPoint* getMissionPoint(u16 i) const;
  MapdataPointInfo* getPointInfo(u16 i) const;
  MapdataStage* getStage() const;
  MapdataStartPoint* getStartPoint(u16 i) const;

  inline MapdataEnemyPathAccessor* getEnemyPathAccessor() { return mpEnemyPath; }

  u16 getAreaCount() const;
  u16 getCameraCount() const;
  u16 getEnemyPointCount() const;
  u16 getItemPointCount() const;
  u16 getJugemPointCount() const;
  u16 getStartPointCount() const;

  /*template <typename T, typename TAccessor>
  TAccessor* parse(u32 sectionName);*/
  MapdataAreaAccessor* parseAreas(u32 sectionName);
  MapdataCameraAccessor* parseCameras(u32 sectionName);
  MapdataCannonPointAccessor* parseCannonPoints(u32 sectionName);
  MapdataEnemyPathAccessor* parseEnemyPaths(u32 sectionName);
  MapdataEnemyPointAccessor* parseEnemyPoints(u32 sectionName);
  MapdataGeoObjAccessor* parseGeoObjs(u32 sectionName);
  MapdataItemPathAccessor* parseItemPaths(u32 sectionName);
  MapdataItemPointAccessor* parseItemPoints(u32 sectionName);
  MapdataJugemPointAccessor* parseJugemPoints(u32 sectionName);
  MapdataStartPointAccessor* parseKartpoints(u32 sectionName);
  MapdataMissionPointAccessor* parseMissionPoints(u32 sectionName);
  MapdataPointInfoAccessor* parsePointInfo(u32 sectionName);
  MapdataStageAccessor* parseStage(u32 sectionName);

private:
  CourseMap();
  virtual ~CourseMap();

  static CourseMap* spInstance;

  MapdataFileAccessor* mpCourse;

  MapdataStartPointAccessor* mpStartPoint;
  MapdataEnemyPathAccessor* mpEnemyPath;
  MapdataEnemyPointAccessor* mpEnemyPoint;
  MapdataItemPathAccessor* mpItemPath;
  MapdataItemPointAccessor* mpItemPoint;
  MapdataCheckPathAccessor* mpCheckPath;
  MapdataCheckPointAccessor* mpCheckPoint;
  MapdataPointInfoAccessor* mpPointInfo;
  MapdataGeoObjAccessor* mpGeoObj;
  MapdataAreaAccessor* mpArea;
  MapdataCameraAccessor* mpCamera;
  MapdataJugemPointAccessor* mpJugemPoint;
  MapdataCannonPointAccessor* mpCannonPoint;
  MapdataStageAccessor* mpStageInfo;
  MapdataMissionPointAccessor* mpMissionPoint;

  void* mpGoalCamera;
  void* mpType9Camera;
  void* mpOpeningPanCamera;
  unk _50;
};

} // namespace System
/* end "CourseMap.hpp" */
/* "src\system\RaceManager.hpp" line 9 "RaceConfig.hpp" */
/* end "RaceConfig.hpp" */
/* "src\system\RaceManager.hpp" line 10 "ElineControlManager.hpp" */

#pragma once

/* "src\system\ElineControlManager.hpp" line 3 "ElineController.hpp" */

#pragma once

/* "src\system\ElineController.hpp" line 3 "CourseMap.hpp" */
/* end "CourseMap.hpp" */

namespace System {
// TODO: TU 0x8052d270-0x8052d46c
class ElineController {
  ElineController* next;
  s16 controllerFrameCounter;
  s16 pathIdx;
  s16 controllerDurationFrames;
  bool isFinalNode;
};
}
/* end "ElineController.hpp" */

namespace System {
// TODO: TU 0x8052d46c-0x8052d96c
class ElineControlManager {
public:
  ElineControlManager();

  ElineController** controllers;
  u16 controllerCount;
};
}
/* end "ElineControlManager.hpp" */
/* "src\system\RaceManager.hpp" line 11 "util/Random.hpp" */
#pragma once

/* "src\util\Random.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

namespace Util {

class Random {
public:
  Random();

  void reseed();

  Random(u32 seed);

  virtual ~Random();

  u32 nextU32();

  u32 nextU32(u32 range);

  f32 nextF32();

  f32 nextF32(f32 range);

private:
  static const f32 mul;

  u64 mX;
  u64 mSeed;
};

} // namespace Util
/* end "util/Random.hpp" */
/* "src\system\RaceManager.hpp" line 12 "ResourceManager.hpp" */
/* end "ResourceManager.hpp" */
/* "src\system\RaceManager.hpp" line 13 "RaceMode.hpp" */
#pragma once

/* "src\system\RaceMode.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

namespace System {
class RaceManager;

struct RaceMode {
    virtual u32 canEndRace();
    RaceManager* raceManager;
};

class KrtFile;

struct RaceModeGrandPrix: public RaceMode {
    KrtFile* krtFile[1];

    u32 canEndRace();
    RaceModeGrandPrix(RaceManager* raceManager_);
};
}
/* end "RaceMode.hpp" */

namespace System {
enum RaceStage {
  INTRO_CAMERA=0 /* Course preview */,
  COUNTDOWN=1    /* Includes starting pan */,
  RACE=2,
  FINISHED_RACE=3
};

// TODO: Maybe defines/bitfield and not enum?
enum RaceManagerPlayerFlags {
  IN_RACE=1,
  FINISHED=2,
  DRIVING_WRONG_WAY=4,
  DISCONNECTED=16,
  COMING_LAST_ANIMATION=64
};

struct KmgFileRaw {
  char magic[4]; /* RKMG in ASCII */
  u32 fileSize; /* in bytes */
  s32 field2_0x8;
  void* coinRunnersOff; /* relative to 0x10 */
  s16 balloonBattleTimeLimits[10][11];
  u16 field5_0xec[10][11];
  s16 enemyHitScore;
  s16 enemyDefeatScore;
  s16 allBalloonLossScore;
  s16 hitByEnemyScore;
  s16 teammateHitScore;
  s16 hitByTeammateScore;
  s16 field12_0x1d4;
  s16 field13_0x1d6;
  s16 field14_0x1d8;
  s16 field15_0x1da;
  s16 coinRunnersTimeLimits[10][11];
  u16 field17_0x2b8[10][11];
  u16 startCoinCounts[10][11];
  u16 maxCoinCounts[10][11];
  u16 field20_0x54c[10][11];
  u16 field21_0x628[10][11];
  unk8 unk[0x712-0x704];
  s16 fallOffCoinLoss;
  s16 hitCoinLoss;
  s16 coinLossPercent; /* ?? Copied from wiki */
};
static_assert(sizeof(KmgFileRaw) == 0x718);

class KmgFile {
public:
  KmgFile(void* file) { fromRaw(file); }
  void fromRaw(void* file);
  virtual ~KmgFile();
  s16 getBattleCourseId(CourseId courseId);

  KmgFileRaw* data;
};
static_assert(sizeof(KmgFile) == 0x8);

// Maybe its own header file
class TimerManagerBase {
public:
  TimerManagerBase() { reset(); }
  virtual ~TimerManagerBase();
  virtual void reset();
  virtual void update();

protected:
  Time timer1;
  Time timer2;
  Time timer3;
  Util::Random random;
  s8 field26_0x40;
  bool raceHasStarted;
  bool timerIsReversed;
  u32 raceDurationMillis;
  unk8 unk48[0x50-0x48];
};

class TimerManager : public TimerManagerBase {
public:
  TimerManager() : TimerManagerBase() {}
  virtual ~TimerManager() override;
  virtual void reset() override;
  virtual void update() override;
  inline void setLimit(u16 minutes, u8 seconds) {
    this->timer3.set2(minutes, seconds, 0, true);
    this->timerIsReversed = true;
    this->timer2.set2(minutes, seconds, 0, true);
    this->raceDurationMillis = (seconds+60*minutes)*1000;
  }
};
static_assert(sizeof(TimerManager) == 0x50);

/** 
 * currentBit is a 1 that rotates arounds the region defined by mask every frame. Could be slipstream related?
 * Overall a weird timer which rotates a single bit around a u32
 * */
class MovingMask {
public:
    MovingMask(u32);
    int mask;
    int currentBit;
};

class RaceManagerPlayer {
public:
  RaceManagerPlayer(u8 idx, u8 lapCount);
  void updateGpRankScore();
  virtual ~RaceManagerPlayer();

  unk32 field_0x4;
  s8 idx;
  u16 checkpointId;
  float raceCompletion;
  float raceCompletionMax;
  float checkpointFactor;
  float checkpointStartLapCompletion;
  float lapCompletion;
  s8 position;
  s8 respawn;
  u16 battleScore;
  s16 currentLap;
  s8 maxLap;
  s8 currentKcp;
  s8 maxKcp;
  u32 frameCounter;
  u32 framesInFirstPlace;
  s32 unk34;
  RaceManagerPlayerFlags flags;
  Time* lapFinishTimes;
  Time* raceFinishTime;
  u32 somethingRaceEndMessageOnline;
  KPadPlayer* kpadPlayer;
  unk8 unk_4c_50[0x50-0x4c];
  u16 playersAheadFlags;
  s8 field36_0x52;
  s8 finishingPosition;
};
static_assert(sizeof(RaceManagerPlayer) == 0x54);

struct KrtFile {
    u32 magic;
    u32 rankTimeDeltaFactor;
    u16 numEntries;
    u16 headerSize;
    u16 entries[32][4];
};

class RaceMode; // todo in another file
class RaceManager {
public:
  virtual ~RaceManager();
  RaceManager();

  static RaceManager* createInstance();
  static void destroyInstance();
  static RaceManager* spInstance;
  static u8 getLapCount();

  RaceMode* initGamemode(RaceConfig::Settings::GameMode mode);
  RaceMode* createCompetitionMode();
  u16 getBattleTimeLimit();
  KrtFile** getKrtFile();

  Util::Random* random1;
  Util::Random* random2;
  RaceManagerPlayer** players;
  RaceMode* raceMode;
  TimerManager* timerManager;
  s8* player_id_in_each_position;
  s8 finished_player_count;
  s8 disconnectedPlayerCount;
  s16 introTimer;
  u32 timer; /* Begins counting when race countdown starts */
  s8 battleKtptStart;
  s8 field12_0x25;
  RaceStage stage;
  bool introWasSkipped;
  bool spectatorMode;
  bool canCountdownStart;
  bool cutSceneMode;
  bool lapCountingIsEnabled;
  MovingMask movingMask;
  KmgFile* kmgFile;
  ElineControlManager* eline_control_manager;
  float dpWaterHeightCheck;
  bool dpDisableLowerRespawns;
};
static_assert(sizeof(RaceManager) == 0x4c);
}
/* end "system/RaceManager.hpp" */

namespace Kart {

enum KartFlags {
  KART_FLAG_HOPPING = 3,
  KART_FLAG_ALL_WHEELS_COLLISION = 15,
  KART_FLAG_STICKY_ROAD = 16,
  KART_FLAG_TOUCHING_GROUND = 18,
  KART_FLAG_AUTO_DRIFT = 19,
  KART_FLAG_AIR_START = 23,
  KART_FLAG_LARGE_FLIP_HIT = 25,
  KART_FLAG_IN_BULLET = 28,
  KART_FLAG_JUMPPAD = 30,
  KART_FLAG_HIT_ITEM_OR_OBJ = 32,
  KART_FLAG_CANNON_START = 35,
  KART_FLAG_IN_CANNON = 36,
  KART_FLAG_HALFPIPE_RAMP = 41,
  KART_FLAG_AT_SUSP_LIMIT = 51,
  /// Used for bouncy mushrooms
  KART_FLAG_JUMPPAD_VELY_INCREASE = 55,
  KART_FLAG_REJECT_ROAD = 59,
  KART_FLAG_DRIFTING_ON_GROUND = 61,
  KART_FLAG_HALFPIPE_RAMP_LOCAL = 0x43,
  KART_FLAG_WHEELIE_ROT = 0x44,
  KART_FLAG_SKIP_WHEEL_CALC = 0x45,
  KART_FLAG_DISABLE_Y_SUS_FORCE = 0x56,
  KART_FLAG_HALFPIPE_MIDAIR = 0x57,
  KART_FLAG_COL_INVISIBILITY = 0x59,
  KART_FLAG_IN_A_BULLET = 0x5b,
  KART_FLAG_STH_61 = 0x61,
  KART_FLAG_STH_WALL_COL = 0x63,
  KART_FLAG_STH_KILLER = 0x6a,
  KART_FLAG_CPU = 0x80,
  KART_FLAG_LOCAL = 0x81,
  KART_FLAG_ONLINE_LOCAL = 0x82,
  KART_FLAG_ONLINE_REMOTE = 0x83,
  KART_FLAG_AUTOMATIC_DRIFT = 0x84,
  KART_FLAG_GHOST = 0x86,
  KART_FLAG_SET_SPEED_ZERO = 0x89,
  KART_FLAG_DEMO_LOSS = 0x8b,
  KART_FLAG_HAS_STOPPED = 0x8c
};

class KartState {
public:
  KartState(KartSettings* settings);
  virtual ~KartState();
  void init();
  void reset();
  void resetOob();
  void updateWipe();
  void startWipe(int wipeState);
  void resetCollisionFlags();
  void empty();
  void resetGroundFlags();
  void setCollisionFlag();
  void clearCollisionFlag();
  void applyStartBoost(s32 idx);
  void calcStartBoost();
  void updateCollisions();

  bool on(size_t n) const {
    return mFlags.on(n);
  }
  void set(size_t n) { mFlags.set(n); }
  void reset(size_t n) { mFlags.reset(n); }
  u32& field(size_t n) { return mFlags.field(n); }

  void setCannonPointId(s32 id) { mCannonPointId = id; }
  void setBoostRampType(s32 type) { mBoostRampType = type; }
  void setJumpPadType(s32 type) { mJumpPadType = type; }
  void setHalfpipeInvisibilityTimer(s32 timer) { mHalfpipeInvisibilityTimer = timer; }
  void setStartBoostIdx(s32 idx) { mStartBoostIdx = idx; }

private:
  RKBitField<160> mFlags;
  KartObjectProxy* mProxy;
  u32 mAirtime;
  u8 _20[0x24 - 0x20];
  f32 _24;
  EGG::Vector3f mTop;
  EGG::Vector3f _34;
  EGG::Vector3f _40;
  EGG::Vector3f _4c;
  u32 _58;
  u32 _5c;
  u8 _60[0x6c - 0x60];
  u32 mHwgTimer;
  u32 _70;
  s32 mBoostRampType;
  s32 mJumpPadType;
  f32 _7c;
  u32 mCannonPointId;
  u16 _84;
  s16 mHalfpipeInvisibilityTimer;
  EGG::Vector2f mStick;
  int mWipeState;
  s16 mWipeFrame;
  u8 _96[2];
  f32 _98;
  f32 mStartBoostCharge;
  s32 mStartBoostIdx;
  s16 _a4;
  s16 _a6;
  EGG::Vector3f _a8;
  u8 _b4[0xc0 - 0xb4];
};
static_assert(sizeof(KartState) == 0xc0);

} // namespace Kart
/* end "KartState.hpp" */

/* "src\kart\KartState.cpp" line 5 "KartCollide.hpp" */
#pragma once

/* "src\kart\KartCollide.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartCollide.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartCollide.hpp" line 6 "KartObjectProxy.hpp" */
/* end "KartObjectProxy.hpp" */
/* "src\kart\KartCollide.hpp" line 7 "KartHitbox.hpp" */
/* end "KartHitbox.hpp" */
/* "src\kart\KartCollide.hpp" line 8 "KartMove.hpp" */
#pragma once

/* "src\kart\KartMove.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartMove.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartMove.hpp" line 6 "kart/KartObjectProxy.hpp" */
/* end "kart/KartObjectProxy.hpp" */

namespace Kart {

// TODO: implement
class KartHalfPipe;
class KartJump;

enum PadType {
  PAD_TYPE_NONE        = 0x0,
  PAD_TYPE_BOOST_PANEL = 0x1,
  PAD_TYPE_BOOST_RAMP  = 0x2,
  PAD_TYPE_JUMP_PAD    = 0x4,
};

class KartMove : public KartObjectProxy {
public:
  enum DrivingDirection {
    DRIVING_DIRECTION_IDLE = 2,
  };

  virtual ~KartMove();
  // signatures not final
  virtual void createComponents();
  virtual void setTurnParams();
  virtual void init();
  virtual void activateStar();
  virtual void activateMega();
  virtual void activateGesso();
  virtual void clear();
  virtual void initOob();
  virtual void vf2c();
  virtual void vf30();
  virtual f32 getLeanRot();
  virtual bool canWheelie();
  // ...more

  s16 getMaxMtCharge();
  s16 getMaxSmtCharge();
  s32 getAppliedHopStickX();
  void setScale(const EGG::Vector3f scale);
  void empty(s32 arg);
  void clearBoost();

  f32 baseSpeed() const { return mBaseSpeed; }
  f32 speed() const { return mSpeed; }
  void setSpeed(f32 speed) { mSpeed = speed; }
  const EGG::Vector3f& dir() const { return mDir; }
  f32 speedRatioCapped() const { return mSpeedRatioCapped; }
  f32 speedRatio() const { return mSpeedRatio; }
  s32 hopStickX() const { return mHopStickX; }
  s16 driftState() const { return mDriftState; }
  s16 mtCharge() const { return mMtCharge; }
  s16 smtCharge() const { return mSmtCharge; }
  const EGG::Vector3f& scale() const { return mScale; }
  s16 someTimer() const { return _someTimer; }
  f32 totalScale() const { return mTotalScale; }
  f32 hitboxScale() const { return mHitboxScale; }
  s16 respawnTimer() const { return mRespawnTimer; }
  DrivingDirection drivingDirection() const { return mDrivingDirection; }
  s16 backwardsAllowCounter() const { return mBackwardsAllowCounter; }
  void setPadType(u32 padType) { mPadType |= padType; }
  u16 flags() const { return mFlags; }
  const KartJump* kartJump() { return mJump; }
  const KartHalfPipe* kartHalfPipe() { return mHalfPipe; }

private:
  u8 _00c[0x014 - 0x010];
  f32 mBaseSpeed;
  u8 _018[0x020 - 0x018];
  f32 mSpeed;
  u8 _024[0x5c - 0x24];
  EGG::Vector3f mDir;
  u8 _068[0x0b0 - 0x68];
  f32 mSpeedRatioCapped;
  f32 mSpeedRatio;
  u8 _0b8[0x0cc - 0x0b8];
  s32 mHopStickX;
  u8 _0d0[0x0fc - 0x0d0];
  s16 mDriftState;
  s16 mMtCharge;
  s16 mSmtCharge;
  u8 _102[0x164 - 0x102];
  EGG::Vector3f mScale;
  f32 mTotalScale;
  f32 mHitboxScale;
  u8 _170[0x238 - 0x178];
  s16 _someTimer;
  s16 mRespawnTimer;
  u8 _23c[0x248 - 0x23c];
  DrivingDirection mDrivingDirection;
  s16 mBackwardsAllowCounter;
  u8 _24e[0x250 - 0x24e];
  u32 mPadType;
  // TODO
  u16 mFlags;
  u8 _256[0x258 - 0x256];
  KartJump* mJump;
  KartHalfPipe* mHalfPipe;
  u8 _260[0x294 - 0x260];
};
static_assert(sizeof(KartMove) == 0x294);

} // namespace Kart
/* end "KartMove.hpp" */
/* "src\kart\KartCollide.hpp" line 9 "KartState.hpp" */
/* end "KartState.hpp" */
/* "src\kart\KartCollide.hpp" line 10 "KartBody.hpp" */

#pragma once

/* "src\kart\KartBody.hpp" line 3 "KartPart.hpp" */
/* end "KartPart.hpp" */
/* "src\kart\KartBody.hpp" line 4 "KartPhysics.hpp" */
#pragma once

/* "src\kart\KartPhysics.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartPhysics.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartPhysics.hpp" line 6 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "src\kart\KartPhysics.hpp" line 7 "egg/math/eggQuat.hpp" */
/* end "egg/math/eggQuat.hpp" */
/* "src\kart\KartPhysics.hpp" line 8 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */

/* "src\kart\KartPhysics.hpp" line 10 "KartHitbox.hpp" */
/* end "KartHitbox.hpp" */
/* "src\kart\KartPhysics.hpp" line 11 "KartDynamics.hpp" */
#pragma once

/* "src\kart\KartDynamics.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartDynamics.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartDynamics.hpp" line 6 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */
/* "src\kart\KartDynamics.hpp" line 7 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "src\kart\KartDynamics.hpp" line 8 "egg/math/eggQuat.hpp" */
/* end "egg/math/eggQuat.hpp" */

namespace Kart {

class KartDynamics {
public:
  virtual ~KartDynamics() {}
  virtual void stabilize();
  virtual void forceUpright();

  //KartDynamics();
  void setDefault();
  // clears state
  void reset();
  void init();
  // set inertia from cuboid with dimensions m (mass 1) and n (mass 12)
  void setBspParams(const EGG::Vector3f& m, const EGG::Vector3f& n, bool skipInertia, float angVel0Factor);
  void setInertia(const EGG::Vector3f& m, const EGG::Vector3f& n);
  void updateInertiaTensorInverse();
  void composeQuat(EGG::Quatf& dst, const EGG::Quatf& q1, const EGG::Vector3f& v);
  void calc(float dt, float maxSpeed, int air);
  void applyWrenchScaled(const EGG::Vector3f& r, const EGG::Vector3f& F, float bumpDeviation);
  void applyTorqueWorld(const EGG::Vector3f& r, const EGG::Vector3f& F);
  void addTorque(const EGG::Vector3f&);
  void addForce(const EGG::Vector3f&);
  void getAngAcc(EGG::Vector3f& out, const EGG::Vector3f& v);
  void applySuspensionWrench(const EGG::Vector3f& p, const EGG::Vector3f& Flinear, const EGG::Vector3f& Frot, bool ignoreX);
  void applyWrench(const EGG::Vector3f& r, const EGG::Vector3f& F);

  // inertia matrix
  EGG::Matrix34f inertiaTensor;
  EGG::Matrix34f invInertiaTensor;

  f32 angVel0Factor;
  // kart position
  EGG::Vector3f pos;
  // kart linear velocity due to dynamic interactions
  EGG::Vector3f externalVel;
  EGG::Vector3f acceleration;
  // external velocity in body frame (unused?)
  EGG::Vector3f externalVelBody;
  EGG::Vector3f _98;
  // kart angular velocity due to dynamic interactions
  EGG::Vector3f angVel0;
  EGG::Vector3f movingRoadVel;
  // kart angular velocity due to moving road?
  EGG::Vector3f angVel1;
  EGG::Vector3f movingWaterVel;
  // total vehicle speed (externalVel + internalVel + movingRoadVel + movingWaterVel)
  EGG::Vector3f speed;
  f32 speedNorm;
  EGG::Vector3f angVel2;
  // kart rotation with an without extra and special rot
  EGG::Quatf mainRot;
  EGG::Quatf fullRot;
  // forces acted on the vehicle ()
  EGG::Vector3f totalForce;
  EGG::Vector3f totalTorque;
  // rotation form stunts?
  EGG::Quatf specialRot;
  // rotation from object collision animations?
  EGG::Quatf extraRot;
  f32 gravity;
  // kart linear velocity due to engine power
  EGG::Vector3f internalVel;

  EGG::Vector3f up;
  u8 _168[0x170-0x164];
  bool _forceUpright;
  bool noGravity;
  // sets external velocity in the Y direction to 0 if going upwards. Used when hit by item or object
  bool isHit;
  // forces external velocity in the Y direction to 0. Never used?
  bool force0xVelY;
  bool inBullet;
  f32 stabilizationFactor;
  f32 speedFix;
  // used for stabilization
  EGG::Vector3f upInterpolated;
  EGG::Vector3f _18c;
  EGG::Vector3f _198;
  f32 angVel0YFactor;
  // model scale for some reason affects max speed limit
  // e.g. you can reach speeds higher than 120km/h in a mega
  EGG::Vector3f scale;
};

class KartDynamicsKart : public KartDynamics {
public:
  KartDynamicsKart();
  virtual ~KartDynamicsKart() {}
};

class KartDynamicsBike : public KartDynamicsKart {
public:
  virtual ~KartDynamicsBike();
  virtual void stabilize() override;
  virtual void forceUpright() override;
};

} // ns
/* end "KartDynamics.hpp" */

namespace Kart {
class KartPhysics {
public:
  virtual ~KartPhysics();

  KartPhysics(bool isBike);

  void reset();
  void calc(f32 dt, f32 maxSpeed, const EGG::Vector3f& scale, u32 airtime);
  void updateDynamicsSpecialRot(const EGG::Quatf& rot);
  void addForce(const EGG::Vector3f& f);
  void applyWrench(const EGG::Vector3f& r, const EGG::Vector3f& f);

  void addInstantaneousSpecialRot(const EGG::Quatf& q);
  void addInstantaneousExtraRot(const EGG::Quatf& q);
  void addDecayingSpecialRot(const EGG::Quatf& q);
  void addDecayingExtraRot(const EGG::Quatf& q);
  void addMainRot(const EGG::Quatf& q);

  void setMovingRoadVel(const EGG::Vector3f& vel, f32 rate);
  void decayMovingRoadVel(f32 airRate, f32 normalRate, bool touchingGround);
  void setMovingWaterVel(const EGG::Vector3f& vel, f32 rate);
  void shiftDecayMovingWaterVel(const EGG::Vector3f& amount, f32 rate);
  void decayMovingWaterVel(f32 airRate, f32 normalRate, bool touchingGround);

  void updatePose();
  void updateAxes();
  // Zeros decaying rotations (e.g. to cancel trick or itemhit rotation when entering cannon)
  void resetPendingOrientations();

  #define UPDATE_AXES_INLINE {\
    float _00 = this->pose(0, 0); \
    float _10 = this->pose(1, 0); \
    float _20 = this->pose(2, 0); \
    float _01 = this->pose(0, 1); \
    float _11 = this->pose(1, 1); \
    float _21 = this->pose(2, 1); \
    float _02 = this->pose(0, 2); \
    float _12 = this->pose(1, 2); \
    float _22 = this->pose(2, 2); \
    this->xAxis.x = _00; \
    this->xAxis.y = _10; \
    this->xAxis.z = _20; \
    this->yAxis.x = _01; \
    this->yAxis.y = _11; \
    this->yAxis.z = _21; \
    this->zAxis.x = _02; \
    this->zAxis.y = _12; \
    this->zAxis.z = _22; \
  }

public:
  KartDynamics* mpDynamics;
  HitboxGroup* mpHitboxGroup;

  EGG::Vector3f up;
  EGG::Vector3f pos;
  // rotation from stunts
  // instantaneous is the extra rot of the current trick.
  // Decaying is used when a trick is ended early (low trick) to smoothly decay the rotation back to normal
  EGG::Quatf decayingSpecialRot;
  EGG::Quatf instantaneousSpecialRot;
  EGG::Quatf specialRot;
  // rotation from e.g. item interactions
  EGG::Quatf decayingExtraRot;
  EGG::Quatf instantaneousExtraRot;
  EGG::Quatf extraRot;

  EGG::Vector3f movingRoadVel;
  EGG::Vector3f movingWaterVel;
  // the following 4 poses/orientation fields do not include wheelieing
  // vehicle pose
  EGG::Matrix34f pose;
  // vehicle orientation axes
  EGG::Vector3f xAxis;
  EGG::Vector3f yAxis;
  EGG::Vector3f zAxis;

  EGG::Vector3f speed;
  f32 _fc;
};
static_assert(sizeof(KartPhysics) == 0x100);
}
/* end "KartPhysics.hpp" */

namespace Kart {
class KartBody : public KartPart {
public:
  void requireSinkDepth(f32 sinkDepth);

  KartPhysics* getPhysics() { return mpPhysics; }
  const KartPhysics* getPhysics() const { return mpPhysics; }
  f32 getSinkDepth() const { return sinkDepth; }
private:
  KartPhysics* mpPhysics;
  f32 _94;
  f32 _98;
  f32 sinkDepth;
  u8 _90[0x224 - -0xa0];
};
}
/* end "KartBody.hpp" */
/* "src\kart\KartCollide.hpp" line 11 "KartDynamics.hpp" */
/* end "KartDynamics.hpp" */
/* "src\kart\KartCollide.hpp" line 12 "field/CourseColManager.hpp" */
#pragma once

/* "src\field\CourseColManager.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\field\CourseColManager.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\field\CourseColManager.hpp" line 6 "RKGndCol.hpp" */
#pragma once

/* "src\field\RKGndCol.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\field\RKGndCol.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\field\RKGndCol.hpp" line 6 "KCollision.hpp" */

#pragma once

/* "src\field\KCollision.hpp" line 3 "rk_types.h" */
/* end "rk_types.h" */

/* "src\field\KCollision.hpp" line 5 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

namespace Field {
struct KCollisionHeader {
  u32 pos_data_offset;
  u32 nrm_data_offset;
  u32 prism_data_offset;
  u32 block_data_offset;
  f32 prism_thickness;
  EGG::Vector3f area_min_pos;
  u32 area_x_width_mask;
  u32 area_y_width_mask;
  u32 area_z_width_mask;
  u32 block_width_shift;
  u32 area_x_blocks_shift;
  u32 area_xy_blocks_shift;
  f32 sphere_radius;
};

struct KCollisionPrism {
  // inlined after KCollisionOctree ctor I think ~KCollisionPrism() {}

  f32 height;
  u16 pos_i;
  u16 fnrm_i;
  u16 enrm1_i;
  u16 enrm2_i;
  u16 enrm3_i;
  u16 attribute;
};

#define KCL_ATTRIBUTE_TYPE(x) ((x) & 0x1f)
#define KCL_ATTRIBUTE_VARIANT(x) (((x) >> 5) & 0x7)
#define KCL_ATTRIBUTE_SINK_DEPTH(x) (((x) >> 0xb) & 0x3)
#define KCL_TYPE_BIT(x) (1 << (x))
#define KCL_ATTRIBUTE_TYPE_BIT(x) KCL_TYPE_BIT(KCL_ATTRIBUTE_TYPE(x))

// KCL attribute types
typedef enum {
  COL_TYPE_ROAD = 0,
  COL_TYPE_SLIPPERY_ROAD = 1,
  COL_TYPE_WEAK_OFF_ROAD = 2,
  COL_TYPE_OFF_ROAD = 3,
  COL_TYPE_HEAVY_OFF_ROAD = 4,
  COL_TYPE_SLIPPERY_ROAD_2 = 5,
  COL_TYPE_BOOST_PAD = 6,
  COL_TYPE_BOOST_RAMP = 7,
  COL_TYPE_JUMP_PAD = 8,
  COL_TYPE_ITEM_ROAD = 9,

  COL_TYPE_SOLID_OOB = 0xa,
  COL_TYPE_MOVING_WATER = 0xb,

  COL_TYPE_WALL = 0xc,
  COL_TYPE_INVISIBLE_WALL = 0xd,
  COL_TYPE_ITEM_WALL = 0xe,
  COL_TYPE_WALL_2 = 0xf,

  COL_TYPE_FALL_BOUNDARY = 0x10,
  COL_TYPE_CANNON_TRIGGER = 0x11,
  COL_TYPE_FORCE_RECALCULATE_ROUTE = 0x12,
  COL_TYPE_HALFPIPE_RAMP = 0x13,
  COL_TYPE_PLAYER_WALL = 0x14,
  COL_TYPE_MOVING_ROAD = 0x15,
  COL_TYPE_STICKY_ROAD = 0x16,
  COL_TYPE_ROAD2 = 0x17,
  COL_TYPE_SOUND_TRIGGER = 0x18,
  COL_TYPE_WEAK_WALL = 0x19,
  COL_TYPE_EFFECT_TRIGGER = 0x1a,
  COL_TYPE_ITEM_STATE_MODIFIER = 0x1b,

  COL_TYPE_HALFPIPE_INVISIBLE_WALL = 0x1c,
  COL_TYPE_ROTATING_ROAD = 0x1d,
  COL_TYPE_SPECIAL_WALL = 0x1e,
  COL_TYPE_INVISIBLE_WALL2 = 0x1f,

  COL_TYPE_COUNT
} KColType;

#define KCL_TYPE_DIRECTIONAL (\
    KCL_TYPE_BIT(COL_TYPE_FALL_BOUNDARY) | \
    KCL_TYPE_BIT(COL_TYPE_SOUND_TRIGGER) | \
    KCL_TYPE_BIT(COL_TYPE_FORCE_RECALCULATE_ROUTE) | \
    KCL_TYPE_BIT(COL_TYPE_EFFECT_TRIGGER) | \
    KCL_TYPE_BIT(COL_TYPE_CANNON_TRIGGER))

#define KCL_TYPE_SOLID_SURFACE ( 0xffffffff & (\
    ~KCL_TYPE_BIT(COL_TYPE_FALL_BOUNDARY) & \
    ~KCL_TYPE_BIT(COL_TYPE_CANNON_TRIGGER) & \
    ~KCL_TYPE_BIT(COL_TYPE_FORCE_RECALCULATE_ROUTE) & \
    ~KCL_TYPE_BIT(COL_TYPE_SOUND_TRIGGER) & \
    ~KCL_TYPE_BIT(COL_TYPE_WEAK_WALL) & \
    ~KCL_TYPE_BIT(COL_TYPE_EFFECT_TRIGGER) & \
    ~KCL_TYPE_BIT(COL_TYPE_ITEM_STATE_MODIFIER)))

#define KCL_TYPE_FLOOR (\
    KCL_TYPE_BIT(COL_TYPE_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_SLIPPERY_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_WEAK_OFF_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_OFF_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_HEAVY_OFF_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_SLIPPERY_ROAD_2) | \
    KCL_TYPE_BIT(COL_TYPE_BOOST_PAD) | \
    KCL_TYPE_BIT(COL_TYPE_BOOST_RAMP) | \
    KCL_TYPE_BIT(COL_TYPE_JUMP_PAD) | \
    KCL_TYPE_BIT(COL_TYPE_ITEM_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_SOLID_OOB) | \
    KCL_TYPE_BIT(COL_TYPE_MOVING_WATER) | \
    KCL_TYPE_BIT(COL_TYPE_HALFPIPE_RAMP) | \
    KCL_TYPE_BIT(COL_TYPE_MOVING_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_STICKY_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_ROAD2) | \
    KCL_TYPE_BIT(COL_TYPE_ROTATING_ROAD))

#define KCL_TYPE_OFFROAD_ANY (\
    KCL_TYPE_BIT(COL_TYPE_WEAK_OFF_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_OFF_ROAD) | \
    KCL_TYPE_BIT(COL_TYPE_HEAVY_OFF_ROAD))

// no halfpipe invisible wall?
#define KCL_TYPE_DRIVER_WALL (\
    KCL_TYPE_BIT(COL_TYPE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_INVISIBLE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_WALL_2 ) | \
    KCL_TYPE_BIT(COL_TYPE_PLAYER_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_SPECIAL_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_INVISIBLE_WALL2))

#define KCL_TYPE_WALL (\
    KCL_TYPE_BIT(COL_TYPE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_INVISIBLE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_ITEM_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_WALL_2 ) | \
    KCL_TYPE_BIT(COL_TYPE_PLAYER_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_HALFPIPE_INVISIBLE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_SPECIAL_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_INVISIBLE_WALL2))

#define KCL_TYPE_PLAYER_WALL_CAT1 (\
    KCL_TYPE_BIT(COL_TYPE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_INVISIBLE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_WALL_2 ) | \
    KCL_TYPE_BIT(COL_TYPE_PLAYER_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_SPECIAL_WALL))

#define KCL_TYPE_PLAYER_WALL_CAT2 (\
    KCL_TYPE_BIT(COL_TYPE_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_WALL_2 ) | \
    KCL_TYPE_BIT(COL_TYPE_PLAYER_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_SPECIAL_WALL) | \
    KCL_TYPE_BIT(COL_TYPE_INVISIBLE_WALL2))

#define KCL_TRICKABLE_MASK   0x2000
#define KCL_REJECT_ROAD_MASK 0x4000
#define KCL_SOFT_WALL_MASK   0x8000

#define KCL_BOOST_PAD_MASK (1 << COL_TYPE_BOOST_PAD)
#define KCL_BOOST_RAMP_MASK (1 << COL_TYPE_BOOST_RAMP)
#define KCL_JUMP_PAD_MASK (1 << COL_TYPE_JUMP_PAD)
#define KCL_HALFPIPE_RAMP_MASK (1 << COL_TYPE_HALFPIPE_RAMP)
#define KCL_CANNON_TRIGGER_MASK (1 << COL_TYPE_CANNON_TRIGGER)
#define KCL_STICKY_ROAD_MASK (1 << COL_TYPE_STICKY_ROAD)
#define KCL_MOVING_ROAD_MASK (1 << COL_TYPE_MOVING_ROAD)
#define KCL_MOVING_WATER_MASK (1 << COL_TYPE_MOVING_WATER)
}
/* end "KCollision.hpp" */

namespace Field {
class RKGndCol {
public:
  RKGndCol(const KCollisionHeader& header);
  ~RKGndCol();
  void computeBbox();
  /* Given the KCL representation of a prism, this function can compute the prism vertex
   positions. Vertex1 is already known, and this function computes vertex2 if enrm is enrm2 and
   vertex 3 if enrm is enrm 1 */
  static EGG::Vector3f getVertex(f32 height, const EGG::Vector3f& vertex1, const EGG::Vector3f& fnrm,
		  const EGG::Vector3f& enrm3, const EGG::Vector3f& enrm) __attribute__((never_inline));
  // finds block that contains position
  u16* searchBlock(const EGG::Vector3f& pos);

  typedef void (RKGndCol::*PrismListVisitor) (u16*);
  void searchMultiBlock(const EGG::Vector3f& pos, f32 radius, PrismListVisitor prismListVisitor);

  // Perform lookup and set sphere-octree-collision detection parameters
  void lookupPoint(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask);
  void lookupSphere(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, f32 radius);
  void lookupPointCached(const EGG::Vector3f& p1, const EGG::Vector3f& p2, u32 typeMask);
  void lookupSphereCached(const EGG::Vector3f& p1, const EGG::Vector3f& p2, u32 typeMask, f32 radius);

  // Perform prism-sphere/point collision check on looked up prisms
  bool checkPointCollision(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
  bool checkSphereCollision(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);

  void narrowScopeLocal(const EGG::Vector3f&, f32 radius, u32 typeMask, u32 unused);

  f32 getPrismThickness() const { return this->prism_thickness; }
  u16 getPrismCache(u32 i) const { return this->prismCache[i]; }
  bool cacheEmpty() const { return this->prismCache[0] == 0; }
  const EGG::Vector3f& getBboxLow() const { return this->bboxLow; }
  const EGG::Vector3f& getBboxHigh() const { return this->bboxHigh; }

private:
  inline bool prismCacheNotEmpty() const { return prismCache != prismCacheTop; }
  void searchMultiBlockRecursiveAll(u8* prismArray, u32 index, PrismListVisitor prismListVisitor, s32, s32, s32, s32, s32, s32);
  void searchMultiBlockRecursive(u8* prismArray, u32 index, PrismListVisitor prismListVisitor);
  bool checkSphereSingle(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
  bool checkSphere(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
  bool checkSphereMovement(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
  bool checkPointMovement(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
  bool checkPoint(f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
  void narrowPolygon_EachBlock(u16* prismArray);

  EGG::Vector3f* pos_data;
  EGG::Vector3f* nrm_data;
  KCollisionPrism* prism_data;
  u8* block_data;
  f32 prism_thickness;
  EGG::Vector3f area_min_pos;
  u32 area_x_width_mask;
  u32 area_y_width_mask;
  u32 area_z_width_mask;
  u32 block_width_shift;
  u32 area_x_blocks_shift;
  u32 area_xy_blocks_shift;
  f32 sphere_radius;

  // --- Sphere-octree collision detection parameters
  EGG::Vector3f pos;
  // I think this is for support of directional collision checking (wall is only one way solid)
  // Pretty much a collision is triggered only when the movement vector has an acute angle with the prism face normal
  EGG::Vector3f prevPos;
  EGG::Vector3f movement; // pos - prevPos
  f32 radius;
  // This mask can be used to only count collision with certain KCL attribute base types. The n-th bit in this mask signifies if KCL of base type n will count towards collision
  u32 typeMask;
  // Iterator for the array of prisms to be checked by e.g. checkSphere. It gets set after searchBlock/searchMultiBlock lookup
  u16* prismArrayIt;

  s32 prismCount;
  KCollisionPrism* prisms;
  EGG::Vector3f bboxLow;
  EGG::Vector3f bboxHigh;

  // prismCache is the list of prisms that are verified that are colliding by e.g. checkSphere (so not really a cache tbh)
  u16 prismCache[0x100];
  // Pointer to the end of prismCache
  u16* prismCacheTop;
  // Cached lookup result (prismArrayIt)
  u16* cachedPrismArrayIt;
  // Cached query parameters (used in checks if cache should be used)
  EGG::Vector3f cachedPos;
  f32 cachedRadius;
};
}
/* end "RKGndCol.hpp" */
/* "src\field\CourseColManager.hpp" line 7 "CollisionInfo.hpp" */

#pragma once

/* "src\field\CollisionInfo.hpp" line 3 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */
/* "src\field\CollisionInfo.hpp" line 4 "egg/math/eggMath.hpp" */
/* end "egg/math/eggMath.hpp" */

namespace Field {
struct SoftWallColInfo {
  EGG::Vector3f bboxLow;
  EGG::Vector3f bboxHigh;
  // bboxLow + bboxHigh. This is the offset that needs to be added to a colliding sphere so
  // it barely does not collide with any prisms (becomes tangent to at least on of them)
  // This is used e.g. to place the wheels tangentially to the ground instead of them appearing to be "sinking"
  // when landing
  // ref: 0x805998c0
  EGG::Vector3f tangentOff;
  f32 dist;
  EGG::Vector3f fnrm;

  void update(f32 now_dist, const EGG::Vector3f& offset, const EGG::Vector3f& fnrm) {
    nw4r::math::VEC3Minimize(&this->bboxLow, &this->bboxLow, &offset);
    nw4r::math::VEC3Maximize(&this->bboxHigh, &this->bboxHigh, &offset);

    bool updateNrm;
    if (now_dist > this->dist) {
      this->dist = now_dist;
      updateNrm = true;
    } else {
      updateNrm = false;
    }
    if (updateNrm) {
      this->fnrm = fnrm;
    }
  }
};

struct DrivableColInfo;
struct ColInfoPartial {
  EGG::Vector3f bboxLow;
  EGG::Vector3f bboxHigh;
  EGG::Vector3f tangentOff;

  void calcTangentOff() {
    nw4r::math::VEC3Add(&this->tangentOff, &this->bboxLow, &this->bboxHigh);
  }
};

// TU 0x807c2660
struct ColInfo : public ColInfoPartial {
  // closest drivable road normal
  EGG::Vector3f floorNrm;
  // closest wall normal
  EGG::Vector3f wallNrm;
  EGG::Vector3f _3c;
  // distance to closest road
  f32 floorDist;
  // distance to closest wall
  f32 wallDist;
  f32 _50;
  f32 colPerpendicularity;
  DrivableColInfo* drivableColInfo;

  void createDrivableColInfo();
  void transformInfo(const ColInfo& colInfoLoca, const EGG::Matrix34f& mtx, const EGG::Vector3f& param4);

  void updateFloor(f32 dist, const EGG::Vector3f& fnrm) {
    bool updateNrm;
    if (dist > this->floorDist) {
      this->floorDist = dist;
      updateNrm = true;

    } else {
      updateNrm = false;
    }
    if (updateNrm) {
      this->floorNrm = fnrm;
    }
  }
  void updateWall(f32 dist, const EGG::Vector3f& fnrm) {
    bool updateNrm;
    if (dist > this->wallDist) {
      this->wallDist = dist;
      updateNrm = true;
    } else {
      updateNrm = false;
    }
    if (updateNrm) {
      this->wallNrm = fnrm;
    }
  }

  void update(f32 now_dist, const EGG::Vector3f& offset, const EGG::Vector3f& fnrm, u32 kclAttributeTypeBit) {
    nw4r::math::VEC3Minimize(&this->bboxLow, &this->bboxLow, &offset);
    nw4r::math::VEC3Maximize(&this->bboxHigh, &this->bboxHigh, &offset);

    if ((kclAttributeTypeBit & KCL_TYPE_FLOOR) != 0) {
      this->updateFloor(now_dist, fnrm);
    } else if ((kclAttributeTypeBit & KCL_TYPE_WALL) != 0) {
      if (EGG::Mathf::isNonNegative(this->wallDist)) {
        f32 perpendicularity = 1.0f - VEC3Dot(&this->wallNrm, &fnrm);
        bool updatePerp;
        if (perpendicularity > this->colPerpendicularity) {
          this->colPerpendicularity = perpendicularity;
          updatePerp = true;
        } else {
          updatePerp = false;
        }
        if (updatePerp && this->colPerpendicularity > 1.0f) {
          this->colPerpendicularity = 1.0f;
        }
      }

      this->updateWall(now_dist, fnrm);
    }
  }
};
}
/* end "CollisionInfo.hpp" */
/* "src\field\CourseColManager.hpp" line 8 "CollisionEntries.hpp" */
#pragma once

/* "src\field\CollisionEntries.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

#define COL_ENTRY_COUNT 64

namespace Field {
bool findClosestCollisionEntry(u32* typeMask, u32 type);
bool findClosestCollisionEntry(u32* typeMask, u32 type, u16 attribute);
void resetCollisionEntries(u32* typeMask);
void pushCollisionEntry(f32 dist, u32* typeMask, u32 kclAttributeBit, u16 attribute);
void setCurrentColAttributeField(u32* typeMask, u32 value, u16 shift, u16 mask);
void setCurrentColBlightIdx(u32* typeMask, u32 value);
void setCurrentColVariant(u32* typeMask, u32 value);
void setCurrentColWheelDepth(u32* typeMask, u32 value);
void setCurrentColTrickable(u32* typeMask, u32 value);
void setCurrentColRejectRoad(u32* typeMask, u32 value);
void setCurrentColSoftWall(u32* typeMask, u32 value);

inline bool lookupCollisionEntry(u32* typeMask, u32 type) {
  if ((*typeMask & type) != 0) return findClosestCollisionEntry(typeMask, type);
  return false;
}

struct CollisionEntry {
  u32 typeMask;
  u16 attribute;
  f32 dist;
};

extern CollisionEntry collisionEntries[COL_ENTRY_COUNT];
extern s32 collisionEntryCount;
extern CollisionEntry* closestCollisionEntry;
extern u32* typeMaskPtr;
}
/* end "CollisionEntries.hpp" */
/* "src\field\CourseColManager.hpp" line 9 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */
/* "src\field\CourseColManager.hpp" line 10 "egg/math/eggMath.hpp" */
/* end "egg/math/eggMath.hpp" */

namespace Field {
typedef bool (RKGndCol::*CollisionCheckFunc) (f32* distOut, EGG::Vector3f* fnrmOut, u16* attributeOut);
/**
 * Manager for course KCL
 */
class CourseColManager {
public:
  static CourseColManager* spInstance;
  static void createInstance();
  static void destroyInstance();

  CourseColManager();
  ~CourseColManager();

  void init(const KCollisionHeader& header);
  f32 setThickness(RKGndCol* colMgr);
  void setSoftWallColInfo(SoftWallColInfo* swColInfo) { this->softWallColInfo = swColInfo; }
  SoftWallColInfo* getSoftWallColInfo() const { return this->softWallColInfo; }
  void setLocalMtx(EGG::Matrix34f* mtx) { this->localMtx = mtx; }
  void scaledNarrowScopeLocal(RKGndCol* maybeColMgr, const EGG::Vector3f& pos, u32 typeMask, f32 scale, f32 radius, u32 unused);

  // public collision query functions
  // Naming:
  // -Point/-Sphere - Point or sphere collision algorithm
  // -Cached        - Use previously looked up prisms
  // -Partial/-Full - Fill partial or full collision information
  // -Push          - Push collision entry to global collision array
  bool checkPointPartial(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale);
  bool checkPointPartialPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale);
  bool checkPointFull(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale);
  bool checkPointFullPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale);

  bool checkPointCachedPartial(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale);
  bool checkPointCachedPartialPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale);
  bool checkPointCachedFull(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale);
  bool checkPointCachedFullPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale);

  bool checkSpherePartial(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale, f32 radius);
  bool checkSpherePartialPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale, f32 radius);
  bool checkSphereFull(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale, f32 radius);
  bool checkSphereFullPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale, f32 radius);

  bool checkSphereCachedPartial(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale, f32 radius);
  bool checkSphereCachedPartialPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 scale, f32 radius);
  bool checkSphereCachedFull(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale, f32 radius);
  bool checkSphereCachedFullPush(RKGndCol* colMgr, const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 scale, f32 radius);

private:
  bool doCheckWithPartialInfo(RKGndCol* colMgr, CollisionCheckFunc collisionCheckFunc, ColInfoPartial* colInfoPartial, u32* typeMask);
  bool doCheckWithPartialInfoPush(RKGndCol* colMgr, CollisionCheckFunc collisionCheckFunc, ColInfoPartial* colInfoPartial, u32* typeMask);
  bool doCheckWithFullInfo(RKGndCol* colMgr, CollisionCheckFunc collisionCheckFunc, ColInfo* colInfoPartial, u32* typeMask);
  bool doCheckWithFullInfoPush(RKGndCol* colMgr, CollisionCheckFunc collisionCheckFunc, ColInfo* colInfoPartial, u32* typeMask);
  bool doCheckMaskOnly(RKGndCol* colMgr, CollisionCheckFunc collisionCheckFunc, u32* typeMaskOut) {
    bool hasCol = false;
    f32 dist;
    u16 attribute;

    while((colMgr->*collisionCheckFunc)(&dist, nullptr, &attribute)) {
      if (this->softWallColInfo != nullptr && (attribute & KCL_SOFT_WALL_MASK) != 0) {
        hasCol = true;
      } else {
        u32 kclAttributeTypeBit = KCL_ATTRIBUTE_TYPE_BIT(attribute);
          
        if (typeMaskOut != nullptr) {
          *typeMaskOut |= kclAttributeTypeBit;
        }
        hasCol = true;
      }
    }

    return hasCol;
  }
  bool doCheckMaskOnlyPush(RKGndCol* colMgr, CollisionCheckFunc collisionCheckFunc, u32* typeMaskOut) {
    bool hasCol = false;
    f32 dist;
    u16 attribute;

    while((colMgr->*collisionCheckFunc)(&dist, nullptr, &attribute)) {
      if (this->softWallColInfo != nullptr && (attribute & KCL_SOFT_WALL_MASK) != 0) {
        hasCol = true;
      } else {
        u32 kclAttributeTypeBit = KCL_ATTRIBUTE_TYPE_BIT(attribute);
          
        if (typeMaskOut != nullptr) {
          pushCollisionEntry(dist, typeMaskOut, kclAttributeTypeBit, attribute);
        }
        hasCol = true;
      }
    }

    return hasCol;
  }

  // KCL handle
  RKGndCol* colMgr;
  f32 kclScale;
  SoftWallColInfo* softWallColInfo;
  // pose of entity being checked for collision with course
  EGG::Matrix34f* localMtx;
};
}
/* end "field/CourseColManager.hpp" */
/* "src\kart\KartCollide.hpp" line 13 "field/CourseModel.hpp" */
#pragma once

/* "src\field\CourseModel.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\field\CourseModel.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\field\CourseModel.hpp" line 6 "CourseColManager.hpp" */
/* end "CourseColManager.hpp" */
/* "src\field\CourseModel.hpp" line 7 "geo2/ObjDrivableManager.hpp" */
#pragma once

/* "src\geo2\ObjDrivableManager.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\geo2\ObjDrivableManager.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\geo2\ObjDrivableManager.hpp" line 6 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

/* "src\geo2\ObjDrivableManager.hpp" line 8 "geo/ObjDrivable.hpp" */

#pragma once

/* "src\geo\ObjDrivable.hpp" line 3 "ObjBase.hpp" */

#pragma once

/* "src\geo\ObjBase.hpp" line 3 "rk_types.h" */
/* end "rk_types.h" */

namespace GeoObj {

/// has its update function called each frame
#define GEOOBJ_KIND_UPDATE 1
/// has its update function called each frame
#define GEOOBJ_KIND_DEBUG_DRAW 2
#define GEOOBJ_KIND_4 4

class ObjBase {
public:
  // signatures TBA
  virtual ~ObjBase();
  virtual void setup();
  /// Use GX for custom drawing on the screen
  virtual void drawDebug();
  /// calculates model position
  virtual void calc();
  virtual void vf18();
  /// updates model matrices
  virtual void update();
  virtual void init() = 0;

  virtual void getId();
  virtual void getName();
  virtual u32 getKindFlags();
  virtual void getOrigin();
  virtual void getResources();
  virtual void getModelName();
  virtual void getLowModelName();
  virtual void getShadowModelName();

  virtual void loadGraphics();
  virtual void loadResources();
  virtual void loadResources2(); // overload?
  virtual void loadShadowModel();
  virtual void initSoundActor();
  virtual void initRenderGroup();
  virtual void loadAnims();
  virtual void loadCollision() = 0;
  virtual void loadRoute();
  virtual void initModels();

  virtual void updateModelMatrix();
  virtual void updateShadow();
  virtual void updateCollision() = 0;
  virtual void updateModelScale();
  virtual void updateShadowScale();

  virtual void vf80();
  virtual void vf84();
  virtual void vf88();
  virtual void vf8c();

  virtual void disableCollision();
  virtual void enableCollision();

  virtual void getDrawInfo();
  virtual void getPosition();
  virtual void calcCollision();
  virtual void isLodDisabled();
  virtual void vfa8();
  virtual void vfac();
  virtual void getDrawType();
 
  u8 _4[0xa4 - 0x4];
  u32 managerIdx;
};
}
/* end "ObjBase.hpp" */

/* "src\geo\ObjDrivable.hpp" line 5 "field/CourseColManager.hpp" */
/* end "field/CourseColManager.hpp" */

namespace GeoObj {
class ObjDrivable : public ObjBase {
public:
  virtual ~ObjDrivable();

  // signatures TBA
  virtual void vfb4() = 0;
  virtual void initCollision();
  virtual void registerBoxColUnit();

  virtual bool checkPointPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut) = 0;
  virtual bool checkPointPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut) = 0;
  virtual bool checkPointFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut) = 0;
  virtual bool checkPointFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut) = 0;

  virtual bool checkSpherePartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;
  virtual bool checkSpherePartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;
  virtual bool checkSphereFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;
  virtual bool checkSphereFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;

  virtual bool narrowScopeLocal(const EGG::Vector3f& pos, f32 radius, u32 typeMask, u32 unused) = 0;

  virtual bool checkPointCachedPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut) = 0;
  virtual bool checkPointCachedPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut) = 0;
  virtual bool checkPointCachedFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut) = 0;
  virtual bool checkPointCachedFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut) = 0;

  virtual bool checkSphereCachedPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;
  virtual bool checkSphereCachedPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;
  virtual bool checkSphereCachedFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;
  virtual bool checkSphereCachedFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start) = 0;

  virtual void vf104();
  virtual void vf108();
  virtual void vf10c();
  virtual void vf110();
  virtual void vf114();
  virtual void vf118();
  virtual void vf11c();
};
}
/* end "geo/ObjDrivable.hpp" */
/* "src\geo2\ObjDrivableManager.hpp" line 9 "geo/BoxColManager.hpp" */
#pragma once

/* "src\geo\BoxColManager.hpp" line 2 "geo/BoxColUnit.hpp" */
#pragma once

/* "src\geo\BoxColUnit.hpp" line 2 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

#define BOXCOL_FLAG_DRIVER 0x1
#define BOXCOL_FLAG_ITEM 0x2
#define BOXCOL_FLAG_OBJECT_TYPE_1 0x4
#define BOXCOL_FLAG_OBJECT_TYPE_2 0x8
#define BOXCOL_FLAG_DRIVABLE 0x10
#define BOXCOL_FLAG_100 0x100
#define BOXCOL_FLAG_DISABLED 0x200
#define BOXCOL_FLAG_STATIC 0x400
#define BOXCOL_FLAG_CHANGE_SIZE 0x800


/**
 * An item inside a BoxColManager.
 *
 * A box described by its BoxColUnit::position and BoxColUnit::radius. @see BoxColManager for details
 */
struct BoxColUnit {
  BoxColUnit();
  ~BoxColUnit();

  void set(const EGG::Vector3f* pos, u32 flags, void* userData, float radius,
           float thickness);
  void makeDynamic();
  void resizeSphere(float radius, float thickness);

  void _80786F98();
  void _80786FA8();

  /*
  MKDS:
    s16 segmentRightEndpoint;
    s16 segmentLeftEndpoint;
    fx32 zMax;
    fx32 zMin;
    const VecFx32* position;
    fx32 boundingSphereRadius;
    u16 flags;
    void* object;
  */
  const EGG::Vector3f* position;
  f32 radius;
  f32 range;
  u32 flags; // Value of BoxColFlag
  void* userData;
  u16 rightPointID;
  u16 leftPointID;
  f32 xMax;
  f32 xMin;
};
/* end "geo/BoxColUnit.hpp" */
/* "src\geo\BoxColManager.hpp" line 3 "geo/ObjDrivable.hpp" */
/* end "geo/ObjDrivable.hpp" */
/* "src\geo\BoxColManager.hpp" line 4 "egg/core/eggDisposer.hpp" */
/* end "egg/core/eggDisposer.hpp" */

extern "C" const float flt_808A47EC;
// extern const float flt_808A47EC;

struct BoxColRightPoint {
  /*
  MKDS:
    u8 leftEndpoint; // left endpoint idx of this segment
    u8 minLeftEndpoint; // from all segments overlapping this x, the left most
                        // left-endpoint idx s16 xPos;
    s16 xPos;
  */
  f32 xPos;
  u8 leftPoint;
  u8 minLeftPoint;
};

struct BoxColLeftPoint {
  /*
  MKDS:
    u8 rightEndpoint; // right endpoint idx of this segment
    u8 colEntryId; // col entry corresponding to this segment
    s16 xPos;
  */
  f32 xPos;
  u8 rightPoint;
  u8 unitID;
};

/**
 * An efficient container data structure for quick spatial accessing of game objects and collision checking.
 *
 * Internally it is a 1D quadtree. Each object in this structure is called a "box unit" and is characterized
 * by its center position and halfwidth. Every collidable object in the game has its bounding box computed so
 * that it can be quickly checked for collision with other units, without proceding to more expensive operations
 * (such as octree collision checking in the case of courses/KCL objects).
 * The quadtree partitions the space based on the object's Z coordinate and width into 4 quadrants
 * (hence quadtree). The object's "left point" is point.z-radius and its 
 * right point point.z+radius. For each node, the 4 children's left and right points have a specific behavior 
 * when compared to their parent's (< and <, < and >, > and <, > and >). Hence when checking for a collision of
 * a box, we can iterate the quadtree so that we avoid iterating box units that have right point > the queried
 * box's left point and left point < the queried box's right point.
 *
 * Additionally it contains iterators for iterating different types of box units
 */
class BoxColManager : public EGG::Disposer {
public:
  static BoxColManager* spInstance;

  bool isSphereInSpatialCache(const EGG::Vector3f& pos, float radius, u32 flag) const;
  void initIterators(const EGG::Vector3f& pos, f32 radius, u32 boxColFlag);
  void resetIterators();
  GeoObj::ObjDrivable* nextDrivable();

private:
  // right point of each box unit in the pool
  BoxColRightPoint* mRightPoints;
  // left point of each box unit in the pool
  BoxColLeftPoint* mLeftPoints;
  // flat array of all units
  BoxColUnit* mpUnitPool;
  // pointer array of colliding units after a bounding box search query
  BoxColUnit** mppUnits;
  s32 mUnitIDs[256];
  // total number of units
  u32 mNumUnits;
  // iterators used when iterating 
  u32 mNextUnitID;
  u32 mNextPlayerID;
  u32 mNextItemID;
  u32 mNextObjectID;
  u32 mNextDrivableID;
  // number of results of the last box query
  u32 mMaxID;
  u32 _0x43c;
  f32 someX;
  u32 UNK_444;
  f32 someZ;
  f32 someDist;
  u32 someFlag;
};
/* end "geo/BoxColManager.hpp" */
/* "src\geo2\ObjDrivableManager.hpp" line 10 "field/DrivableColInfo.hpp" */

#pragma once

/* "src\field\DrivableColInfo.hpp" line 3 "rk_types.h" */
/* end "rk_types.h" */

/* "src\field\DrivableColInfo.hpp" line 5 "geo/ObjDrivable.hpp" */
/* end "geo/ObjDrivable.hpp" */

// TODO: Split its own TU. Not well understood what this does
namespace Field {
struct DrivableColInfo {
  u32 flags;
  GeoObj::ObjDrivable* drivable;
  f32 _8[3];

  GeoObj::ObjDrivable* getDrivable() const {
    if ((flags & 0x100) != 0) return drivable;
    else return nullptr;
  }

  u32 unk_807bd930();
  u32 unk_807bd954();
};
}
/* end "field/DrivableColInfo.hpp" */
/* "src\geo2\ObjDrivableManager.hpp" line 11 "field/CourseColManager.hpp" */
/* end "field/CourseColManager.hpp" */

namespace GeoObj {
class ObjDrivableManager {
public:
  static ObjDrivableManager* spInstance;
  static ObjDrivableManager* createInstance();
  static void destroyInstance();

  ObjDrivableManager();
  virtual ~ObjDrivableManager();

  void initObjs();
  /// Draws debug shapes for objects if the need to. Unused, but potentially used during development, since some objects implement such functionallity
  /// (for example ObakeBlock). It would be interesting to see what those drawings look like
  void debugDraw();
  /// Updates all objects if the need to
  void update();
  /// Adds drivable to list
  s32 push(ObjDrivable* obj);

  // Collision funcs
  void narrowScopeLocal(const EGG::Vector3f& pos, f32 radius, u32 colTypeMask, u32 unused);

  bool checkPointPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut) NEVER_INLINE;
  bool checkPointPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut) NEVER_INLINE;
  bool checkPointFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut) NEVER_INLINE;
  bool checkPointFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut) NEVER_INLINE;

  bool checkSpherePartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start) NEVER_INLINE;
  bool checkSpherePartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start) NEVER_INLINE;
  bool checkSphereFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start) NEVER_INLINE;
  bool checkSphereFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start) NEVER_INLINE;

  bool checkPointCachedPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut);
  bool checkPointCachedPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut);
  bool checkPointCachedFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut);
  bool checkPointCachedFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut);

  bool checkSphereCachedPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereCachedPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereCachedFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereCachedFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, Field::ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start);

private:
  u16 objCount;
  ObjDrivable** objs;
  u16 needUpdateCount;
  ObjDrivable** needUpdate;
  u16 drawDebugCount;
  ObjDrivable** drawDebug;
  u32 _1c;
};
}
/* end "geo2/ObjDrivableManager.hpp" */
/* "src\field\CourseModel.hpp" line 8 "system/ResourceManager.hpp" */
/* end "system/ResourceManager.hpp" */
/* "src\field\CourseModel.hpp" line 9 "system/RKResource.hpp" */

#pragma once

/* "src\system\RKResource.hpp" line 3 "rk_types.h" */
/* end "rk_types.h" */

// Very preliminary
namespace System {
class RKResource {
public:
    static bool resourceExists(u32 resId, const char*);
};

class DrawModel {
public:
  virtual ~DrawModel();	
};
}
/* end "system/RKResource.hpp" */

/* "src\field\CourseModel.hpp" line 11 "nw4r/g3d/g3d_resfile.h" */

#pragma once

/* "lib\nw4r\g3d\g3d_resfile.h" line 3 "nw4r/g3d/g3d_rescommon.hpp" */
// Source:
// https://github.com/doldecomp/ogws/blob/82dbeac2267170fc5cef7e67a6d8c31c5ff45d69/include/nw4r/g3d/g3d_rescommon.h
// Decompiled by kiwi515, GibHaltmannKill.

#pragma once

/* "lib\nw4r\g3d\g3d_rescommon.hpp" line 6 "rk_types.h" */
/* end "rk_types.h" */

#define NW4R_G3D_CREATE_RES_NAME_DATA(VAR, VAL)                                \
  ResNameData ResNameData_##VAR = {sizeof(VAL) - 1, VAL}

#define FIFO_ACCESS_BP 0x61
#define FIFO_ACCESS_CP 0x8
#define FIFO_ACCESS_XF 0x10

namespace nw4r {
namespace g3d {

template <typename T> class ResCommon {
  T* mPtr;

public:
  inline ResCommon(void* vptr) : mPtr(static_cast<T*>(vptr)) {}
  inline ResCommon(const void* vptr) : mPtr(static_cast<T*>(vptr)) {}

  inline T& ref() const { return *mPtr; }
  inline T* ptr() const { return mPtr; }
  inline bool IsValid() const { return mPtr; }

  template <typename TPtr> inline const TPtr* ofs_to_ptr_raw(s32 ofs) const {
    return (const TPtr*)((u8*)mPtr + ofs);
  }

  template <typename TPtr> inline TPtr* ofs_to_ptr(s32 ofs) {
    if (ofs)
      return (TPtr*)((u8*)mPtr + ofs);

    return NULL;
  }

  template <typename TPtr> inline const TPtr* ofs_to_ptr(s32 ofs) const {
    if (ofs)
      return (const TPtr*)((u8*)mPtr + ofs);

    return NULL;
  }

  template <typename TObj> inline TObj ofs_to_obj(s32 ofs) const {
    if (ofs)
      return (u8*)mPtr + ofs;

    return NULL;
  }
};

struct ResNameData {
  u32 mLength;
  char mName[0x1C];
};

struct ResName {
  ResCommon<const ResNameData> mRes;

  inline ResName(const void* vptr) : mRes(vptr) {}

  inline u32 GetLength() const { return mRes.ref().mLength; }

  inline const char* GetName() const { return mRes.ref().mName; }

  bool operator==(ResName) const;
};

struct ResBlockHeaderData
{
  char kind[4];
  u32  size;
};

namespace detail {
typedef u8 CPCmd[6];
typedef u8 BPCmd[5];

inline void ResWrite_u8(u8* res, u8 arg) { *res = arg; }

inline void ResWrite_u16(u8* res, u16 arg) {
  ResWrite_u8(res + 0, arg >> 8);
  ResWrite_u8(res + 1, arg >> 0);
}

inline void ResWrite_u32(u8* res, u32 arg) {
  ResWrite_u8(res + 0, arg >> 24);
  ResWrite_u8(res + 1, arg >> 16);
  ResWrite_u8(res + 2, arg >> 8);
  ResWrite_u8(res + 3, arg >> 0);
}

inline u8 ResRead_u8(const u8* res) { return *res; }

inline u32 ResRead_u32(const u8* res) {
  int ret = ResRead_u8(res) << 24;
  ret |= ResRead_u8(res + 1) << 16;
  ret |= ResRead_u8(res + 2) << 8;
  ret |= ResRead_u8(res + 3);
  return ret;
}

inline void ResReadBPCmd(const u8* res, u32* out) {
  *out = ResRead_u32(res + 1);
}

inline void ResReadCPCmd(const u8* res, u32* out) {
  *out = ResRead_u32(res + 2);
}

void ResWriteBPCmd(u8*, u32);
void ResWriteBPCmd(u8*, u32, u32);
void ResWriteCPCmd(u8*, u8, u32);
void ResWriteXFCmd(u8*, u16, u32);
void ResWriteSSMask(u8*, u32);

} // namespace detail
} // namespace g3d
} // namespace nw4r
/* end "nw4r/g3d/g3d_rescommon.hpp" */
/* "lib\nw4r\g3d\g3d_resfile.h" line 4 "nw4r/g3d/g3d_resdict.h" */

#pragma once

/* "lib\nw4r\g3d\g3d_resdict.h" line 3 "rk_types.h" */
/* end "rk_types.h" */

namespace nw4r { namespace g3d {

struct ResDicData
{
  u32 size;
  u32  numData;
  struct ResDicNodeData
  {
    u16 ref;
    u16 flag;
    u16 idxLeft;
    u16 idxRight;
    s32 ofsString;
    s32 ofsData;
  }
  data[1]; // There are numData + 1 pieces of data
};

}} // nw4r::g3d
/* end "nw4r/g3d/g3d_resdict.h" */

namespace nw4r { namespace g3d {

struct ResFileHeaderData
{
    char signature[4];
    u16  byteOrder;
    u16  version;
    u32  fileSize;
    u16  headerSize;
    u16  dataBlocks;
};


// Folder names stored in the top level dictionary
#define NW4R_G3D_FOLDER_MODELS        "3DModels(NW4R)"
#define NW4R_G3D_FOLDER_PLTTS         "Palettes(NW4R)"
#define NW4R_G3D_FOLDER_TEXTURES      "Textures(NW4R)"
#define NW4R_G3D_FOLDER_ANM_CHR       "AnmChr(NW4R)"
#define NW4R_G3D_FOLDER_ANM_VIS       "AnmVis(NW4R)"
#define NW4R_G3D_FOLDER_ANM_CLR       "AnmClr(NW4R)"
#define NW4R_G3D_FOLDER_ANM_TEXPAT    "AnmTexPat(NW4R)"
#define NW4R_G3D_FOLDER_ANM_TEXSRT    "AnmTexSrt(NW4R)"
#define NW4R_G3D_FOLDER_ANM_SHP       "AnmShp(NW4R)"
#define NW4R_G3D_FOLDER_ANM_SCN       "AnmScn(NW4R)"
#define NW4R_G3D_FOLDER_EXTERNAL      "External"


struct ResTopLevelDictData
{
    ResBlockHeaderData header;   // "root"
    ResDicData         topLevel;
};

struct ResFileData
{
    ResFileHeaderData   fileHeader;
    ResTopLevelDictData dict;
};

class ResMdl;
class ResPltt;
class ResTex;
class ResAnmChr;
class ResAnmVis;
class ResAnmClr;
class ResAnmTexPat;
class ResAnmTexSrt;
class ResAnmShp;
class ResAnmScn;

class ResFile : public ResCommon<ResFileData>
{
public:
  explicit ResFile(void *p=nullptr) : ResCommon<ResFileData>(p) {}

  ResMdl GetResMdl(const char *) const;
  ResMdl GetResMdl(int) const;
  ResMdl GetResMdl(u32) const; //inlined

  ResPltt GetResPltt(const char *) const;
  ResPltt GetResPltt(ResName) const;
  ResPltt GetResPltt(int) const;
  ResPltt GetResPltt(u32) const; //inlined
  
  ResTex GetResTex(const char *) const;
  ResTex GetResTex(ResName) const;
  ResTex GetResTex(int) const;
  ResTex GetResTex(u32) const; //inlined
  
  ResAnmChr GetResAnmChr(const char *) const;
  ResAnmChr GetResAnmChr(int) const;
  ResAnmChr GetResAnmChr(u32) const; //inlined
  
  ResAnmVis GetResAnmVis(const char *) const;
  ResAnmVis GetResAnmVis(int) const;
  ResAnmVis GetResAnmVis(u32) const; //inlined
  
  ResAnmClr GetResAnmClr(const char *) const;
  ResAnmClr GetResAnmClr(int) const;
  ResAnmClr GetResAnmClr(u32) const; //inlined
  
  ResAnmTexPat GetResAnmTexPat(const char *) const;
  ResAnmTexPat GetResAnmTexPat(int) const;
  ResAnmTexPat GetResAnmTexPat(u32) const; //inlined
  
  ResAnmTexSrt GetResAnmTexSrt(const char *) const;
  ResAnmTexSrt GetResAnmTexSrt(int) const;
  ResAnmTexSrt GetResAnmTexSrt(u32) const; //inlined
  
  ResAnmShp GetResAnmShp(const char *) const;
  ResAnmShp GetResAnmShp(int) const;
  ResAnmShp GetResAnmShp(u32) const; //inlined
  
  ResAnmScn GetResAnmScn(const char *) const;
  ResAnmScn GetResAnmScn(int) const;
  ResAnmScn GetResAnmScn(u32) const; //inlined
  
  u32 GetResMdlNumEntries() const; //inlined
  u32 GetResPlttNumEntries() const; //inlined
  u32 GetResTexNumEntries() const; //inlined
  u32 GetResAnmChrNumEntries() const; //inlined
  u32 GetResAnmVisNumEntries() const; //inlined
  u32 GetResAnmClrNumEntries() const; //inlined
  u32 GetResAnmTexPatNumEntries() const; //inlined
  u32 GetResAnmTexSrtNumEntries() const; //inlined
  u32 GetResAnmShpNumEntries() const; //inlined
  u32 GetResAnmScnNumEntries() const;
  
  bool Bind(ResFile);
  void Release();
  void Init();
  void Terminate();
  bool CheckRevision() const;
};
}} // nw4r::g3d
/* end "nw4r/g3d/g3d_resfile.h" */

namespace Field {
class CourseModel {
public:
  static CourseModel* spInstance;
  static void createInstance();
  static void destroyInstance();

  CourseModel();
  ~CourseModel();
  static void loadModels(bool isCourse, nw4r::g3d::ResFile& resFile, System::DrawModel** drawModel, const char* modelPath, char* modelName, u32 flags);
  void setSoftWallColInfo(SoftWallColInfo* softWallColInfo);

  // collision query funcs
  void narrowScopeLocal(const EGG::Vector3f& pos, f32 radius, u32 typeMask, u32 unused);

  bool checkPointPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut);
  bool checkPointPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut);
  bool checkPointFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut);
  bool checkPointFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut);

  bool checkSpherePartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSpherePartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start);

  bool checkPointCachedPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut);
  bool checkPointCachedPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut);
  bool checkPointCachedFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut);
  bool checkPointCachedFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut);

  bool checkSphereCachedPartial(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereCachedPartialPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfoPartial* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereCachedFull(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start);
  bool checkSphereCachedFullPush(const EGG::Vector3f& pos, const EGG::Vector3f& prevPos, u32 typeMask, ColInfo* colInfo, u32* typeMaskOut, f32 radius, u32 start);

private:
  System::DrawModel* courseModel;
  System::DrawModel* vrcornModel;
  nw4r::g3d::ResFile courseRes;
  nw4r::g3d::ResFile vrcornRes;
  SoftWallColInfo* softWallColInfo;
};
}
/* end "field/CourseModel.hpp" */
/* "src\kart\KartCollide.hpp" line 14 "field/CollisionEntries.hpp" */
/* end "field/CollisionEntries.hpp" */

namespace Kart {
class KartCollideAreaBase : public KartObjectProxy {
public:
  virtual ~KartCollideAreaBase();
  virtual void init();
  virtual void vf10();
  virtual void vf14();

private:
  u8 _10[0x38 - 0x10];
};
static_assert(sizeof(KartCollideAreaBase) == 0x38);

// 0x80593fa4. Not understood well at all
class KartCollideArea : public KartCollideAreaBase {
public:
  KartCollideArea();
  virtual ~KartCollideArea();
  virtual void init() override;
  virtual void vf10() override;
  virtual void vf14() override;

private:
  u8 _38[0x40 - 0x38];
};
static_assert(sizeof(KartCollideArea) == 0x40);

class IKartCollide {
public:
  virtual void processBody(KartCollisionInfo& kartColInfo, const Hitbox& hitbox, const Field::ColInfo& colInfo, u32* colTypeMask) = 0;
  virtual void processWheels(KartCollisionInfo& kartColInfo, const Hitbox& hitbox, const Field::ColInfo& colInfo, u32* colTypeMask) = 0;
};

#define SURF_FLAG_WALL 		      0x1
#define SURF_FLAG_SOLID_OOB 	      0x2
#define SURF_FLAG_UNK_4 	      0x4
#define SURF_FLAG_UNK_8 	      0x8
// KCL boost ramps
#define SURF_FLAG_BOOST_RAMP 	      0x10
#define SURF_FLAG_GROUND_OFFROAD      0x20
#define SURF_FLAG_OFFROAD 	      0x40
// "boost panel" here includes KCL boost ramps
#define SURF_FLAG_GROUND_BOOST_PANEL  0x80
#define SURF_FLAG_BOOST_PANEL 	      0x100
#define SURF_FLAG_HALFPIPE_RAMP       0x200
#define SURF_FLAG_TRICKABLE 	      0x800
#define SURF_FLAG_NOT_TRICKABLE       0x1000
#define SURF_FLAG_FALL_BOUNDARY_SHORT 0x2000
#define SURF_FLAG_MOVING_ROAD 	      0x8000
#define SURF_FLAG_HALFPIPE_END 	      0x10000

class KartCollide : public IKartCollide, public KartObjectProxy {
public:
  KartCollide();
  virtual void processBody(KartCollisionInfo& kartColInfo, const Hitbox& hitbox, const Field::ColInfo& colInfo, u32* colTypeMask) override;
  virtual void processWheels(KartCollisionInfo& kartColInfo, const Hitbox& hitbox, const Field::ColInfo& colInfo, u32* colTypeMask) override;
  virtual ~KartCollide() {}
  //virtual void _unused();
  
  void init();
  void updateBbox();
  void processMovingWater(KartCollisionInfo& kartColInfo, u32* colTypeMask) NEVER_INLINE;
  void processFloor(KartCollisionInfo& kartColInfo, const Hitbox& hitbox, const Field::ColInfo& colInfo, u32* colTypeMask, bool isWheel);
  void checkNeighborhood(KartCollisionInfo& kartColInfo, const Hitbox& hitbox, const Field::ColInfo& colInfo);
  void updateHitboxes();
  bool processWall(KartCollisionInfo& kartColInfo, const Field::ColInfo& colInfo, u32* colTypeMask);
  void processCannon(u32* kclTypeMask);
  void applySomeFloorMoment(KartDynamics* kartDynamics, HitboxGroup* hitboxGroup,
		  const EGG::Vector3f& forward, const EGG::Vector3f& dir, const EGG::Vector3f& speed,
		  f32 rateForward, f32 rateLateral, bool zeroUp, bool zeroPlane, bool affectAngVel);
  void calcWheelCollision(s8 playerIdx, u32 wheelIdx, KartDynamics* kartDynamics, HitboxGroup* hitboxGroup, const EGG::Vector3f& colForce,
		  const EGG::Vector3f& wheelPos, f32 radius);

  const EGG::Vector3f& getMovement() const { return movement; }
  f32 get1c() const { return _1c; }

public:
  KartCollideArea* kartCollideArea;
  f32 boundingRadius;
  /// Collision between two players can't occur more often than every 10 frames, counted by this timer
  s16 playerBumpTimer;
  f32 _1c;
  EGG::Vector3f _20;
  /// Surface effects are determined by this flag
  u32 surfaceFlags;
  EGG::Vector3f tangentOff;
  EGG::Vector3f movement;
  s16 respawnTimer;
  /// Counts 3 frames of consecutive allowed collision with solid OOB
  s16 solidOobTimer;
  s16 someLightningTimer;
  f32 _50;
  f32 suspBottomHeightSoftWall;
  s16 someSoftWallTimer;
  f32 suspBottomHeightNonSoftWall;
  s16 someNonSoftWallTimer;
  s16 someAngVel3FrameTimer;
  f32 someYawAngVel;
  f32 _68;
  s16 oobAreaIdx;
  f32 _70;
};
}
/* end "KartCollide.hpp" */
/* "src\kart\KartState.cpp" line 6 "KartDynamics.hpp" */
/* end "KartDynamics.hpp" */
/* "src\kart\KartState.cpp" line 7 "KartMove.hpp" */
/* end "KartMove.hpp" */
/* "src\kart\KartState.cpp" line 8 "KartPhysics.hpp" */
/* end "KartPhysics.hpp" */
/* "src\kart\KartState.cpp" line 9 "KartWheel.hpp" */
/* end "KartWheel.hpp" */
/* "src\kart\KartState.cpp" line 10 "KartWheelPhysics.hpp" */
#pragma once

/* "src\kart\KartWheelPhysics.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\KartWheelPhysics.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\KartWheelPhysics.hpp" line 6 "KartObjectProxy.hpp" */
/* end "KartObjectProxy.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 7 "KartHitbox.hpp" */
/* end "KartHitbox.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 8 "KartPhysicsEngine.hpp" */

#pragma once

/* "src\kart\KartPhysicsEngine.hpp" line 3 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "src\kart\KartPhysicsEngine.hpp" line 4 "KartObjectProxy.hpp" */
/* end "KartObjectProxy.hpp" */

namespace Kart {
extern f32 sinkDepthFactor;

class KartPhysicsEngine : public KartObjectProxy {
public:
  void registerSuspLimits(const EGG::Vector3f& travelVector);

  inline f32 getYScale() const { return yScale; }
private:
  u8 _0[0x60 - 0xc];
  f32 yScale;
  u8 _64[0x9c - 0x64];
};
}
/* end "KartPhysicsEngine.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 9 "KartDynamics.hpp" */
/* end "KartDynamics.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 10 "KartState.hpp" */
/* end "KartState.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 11 "KartCollide.hpp" */
/* end "KartCollide.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 12 "BSP.hpp" */
/* end "BSP.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 13 "RKGeom.hpp" */
#pragma once

/* "src\kart\RKGeom.hpp" line 2 "rk_types.h" */
/* end "rk_types.h" */

/* "src\kart\RKGeom.hpp" line 4 "decomp.h" */
/* end "decomp.h" */

/* "src\kart\RKGeom.hpp" line 6 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */

namespace RKGeom {
void projUnit(EGG::Vector3f&, const EGG::Vector3f &v0, const EGG::Vector3f &v1);
void rejUnit(EGG::Vector3f& dst, const EGG::Vector3f &v0, const EGG::Vector3f &v1);
void projAndRej(EGG::Vector3f& proj, EGG::Vector3f& rej, const EGG::Vector3f &v0, const EGG::Vector3f &v1);

// template maybe?
void f32_interpolate(f32 t, f32& dst, const f32& f1, const f32& f2);
void vec_interpolate(f32 t, EGG::Vector3f& dst, const EGG::Vector3f& f1, const EGG::Vector3f& f2);
}
/* end "RKGeom.hpp" */

/* "src\kart\KartWheelPhysics.hpp" line 15 "egg/math/eggVector.hpp" */
/* end "egg/math/eggVector.hpp" */
/* "src\kart\KartWheelPhysics.hpp" line 16 "egg/math/eggMatrix.hpp" */
/* end "egg/math/eggMatrix.hpp" */

namespace Kart {
enum KartWheelType {
  KART_WHEEL_KART_LEFT,
  KART_WHEEL_KART_RIGHT,
  KART_WHEEL_BIKE,
};

class KartWheelPhysics;
class KartSusPhysics : public KartObjectProxy {
public:
  virtual ~KartSusPhysics() {}

  KartSusPhysics(u32 wheelIdx, KartWheelType wheelType, s32 bspWheelIdx);
  void reset();
  void init();
  void setInitialState();
  void calc(const EGG::Vector3f& forward, const EGG::Vector3f& vehicleMovement);
  void calcCollision(const EGG::Vector3f& gravity, const EGG::Matrix34f& mtx, f32 dt);

private:
public:
  BspWheel* bspWheel;
  KartWheelPhysics* wheelPhysics;
private:
  KartWheelType wheelType;
  u32 bspWheelIdx;
  u32 wheelIdx;
  // topmost point of the suspension the wheel can reach
  EGG::Vector3f suspTop;
  // bsp max suspension travel after vehicle scale is applied
  f32 maxTravelScaled;
  bool hasFloorCol;
  s16 _36;
  f32 _38;
  EGG::Vector3f downDir;
};
static_assert(sizeof(KartSusPhysics) == 0x48);

class KartWheelPhysics : public KartObjectProxy {
public:
  virtual ~KartWheelPhysics() {}

  KartWheelPhysics(u32 wheelIdx, s32 bspWheelIdx);
  void init();
  void setBsp();
  void reset();
  // inlined at SusPhysics::calcCollision
  void setColState(f32 dt, f32 travel, const EGG::Vector3f& colForce);
  void setInitialState();
  void calcCollision(const EGG::Vector3f& bottom, const EGG::Vector3f& topmostPos);
  void calc(const EGG::Vector3f& down, const EGG::Vector3f& vehicleMovement);
  void updateEffectiveRadius();
  // inlined in SusPhysics::calc
  void unk80599dc0(const EGG::Vector3f& front);

  bool hasFloorCollision() const;
  const EGG::Vector3f& getCollisionFloorNrm() const;
  const KartCollisionInfo& getKartCollisionInfo() const;

  f32 getSusTravel() const { return susTravel; }
  void setWheelPos(const EGG::Vector3f& wheelPos) { this->wheelPos = wheelPos; }
  inline f32 getYScale() { return kartPhysicsEngine()->getYScale(); }
  inline const HitboxGroup* getHitbox() const { return hitboxGroup; }
  inline HitboxGroup* getHitbox() { return hitboxGroup; }

private:
public:
  u32 wheelIdx;
  u32 bspWheelIdx;
  BspWheel* bspWheel;
  HitboxGroup* hitboxGroup;
  // Positions wrt world unless specified otherwise
  // wheel center position
  EGG::Vector3f wheelPos;
  EGG::Vector3f prevWheelPos;
  // previous wheel offset wrt current suspension top
  EGG::Vector3f prevWheelOffset;
  f32 susTravel;
  EGG::Vector3f colVel;
  EGG::Vector3f speed;
  // position of the bottom part of the wheel (where it contacts the ground)
  EGG::Vector3f wheelEdgePos;
  // Tires get squished a little on hard floor collisions
  f32 effectiveRadius;
  f32 targetEffectiveRadius;
  f32 isAtSuspLimit;
  // topmost point of the suspension the wheel can reach
  EGG::Vector3f suspTop;
};
static_assert(sizeof(KartWheelPhysics) == 0x84);
}
/* end "KartWheelPhysics.hpp" */

extern EGG::Vector3f lbl_802A4100;
extern EGG::Vector3f RKSystem_ey;

static inline EGG::Vector3f zeroY(const EGG::Vector3f& v) {
  EGG::Vector3f r = v;
  r.y = 0.0f;
  return r;
}
extern "C" void* lbl_1_bss_4218;
extern "C" s16 lbl_1_data_3958[6] = {0x00B4, 0x0000, 0x0000, 0x000A, 0x4220, 0x0000};
extern "C" f32 lbl_1_data_3918[4] = {0.02f, 0.002f, 0.96f, 0.02f};

struct StartBoostEntry {
  f32 threshold;
  s16 count;
  s16 _pad;
};
extern "C" StartBoostEntry lbl_1_data_3928[6] = {
    {0.85f, 0, 0},  {0.88f, 10, 0}, {0.905f, 20, 0},
    {0.925f, 30, 0}, {0.94f, 45, 0}, {0.95f, 70, 0},
};
extern "C" void PlayerSub10_applyStartBoost(void*, s16);
extern "C" {
void fn_1_80068(Kart::KartObjectProxy*, s32, s32, f32);
void* fn_1_803EC(Kart::KartObjectProxy*);
void fn_1_809A8(Kart::KartObjectProxy*, s32);
void fn_1_80C90(Kart::KartObjectProxy*, s32, s32, s32);
s32 fn_1_80DF4(Kart::KartObjectProxy*);
s32 fn_1_80E0C(Kart::KartObjectProxy*);
void fn_1_354D84(void*);
void PlayerZipper_end(const void*, s32);
void PlayerTrick_end(void*);
void PlayerSub10_endTrick(void*);
EGG::Vector3f* playerPointers_getSpeed(Kart::KartObjectProxy*);
s32 PlayerPointers_isBike(Kart::KartObjectProxy*);
s32 Raceinfo_isAtLeastStage(void*, s32);
}

//https://decomp.me/scratch/7prZZ
namespace Kart {
extern bool isPlayerOnlineLocal;
extern bool isPlayerOnlineRemote;

MARK_FLOW_CHECK(0x805943b4);
KartState::KartState(KartSettings* settings) {
  using namespace System;

  mAirtime = 0;
  _24 = 0.0f;
  mCannonPointId = 0;
  mStartBoostIdx = 0;
  mTop.setZero();
  mProxy = new KartObjectProxy;

  RaceConfig::Player::Type playerType = RaceConfig::spInstance->mRaceScenario.mPlayers[settings->playerIdx].mPlayerType;
  switch (playerType) {
  case RaceConfig::Player::TYPE_REAL_LOCAL:
    set(KART_FLAG_LOCAL);
    break;
  case RaceConfig::Player::TYPE_CPU:
    set(KART_FLAG_CPU);
    break;
  case RaceConfig::Player::TYPE_GHOST:
    set(KART_FLAG_GHOST);
    break;
  }

  if (isPlayerOnlineLocal) {
    set(KART_FLAG_ONLINE_LOCAL);
  } else if (isPlayerOnlineRemote) {
    set(KART_FLAG_ONLINE_REMOTE);
  }

  KPadController* controller = RaceManager::spInstance->players[settings->playerIdx]->kpadPlayer->mController;
  bool isAuto;
  if (!controller) {
    isAuto = false;
  } else {
    isAuto = controller->mDriftIsAuto;
  }

  if (isAuto) {
    set(KART_FLAG_AUTOMATIC_DRIFT);
  }

  if (RaceConfig::spInstance->mRaceScenario.mSettings.mGameMode == RaceConfig::Settings::GAMEMODE_AWARDS &&
      RaceConfig::spInstance->mRaceScenario.mSettings.mCameraMode == RaceConfig::Settings::CAMERA_MODE_LOSS) {
    set(KART_FLAG_SET_SPEED_ZERO);
    set(KART_FLAG_DEMO_LOSS);
  }
}

void KartState::init() {
  reset();
  mWipeState = -1;
  mWipeFrame = -1;
}

void KartState::reset() {
  mFlags.field(3) = 0;
  mFlags.field(2) = 0;
  mFlags.field(1) = 0;
  mFlags.field(0) = 0;
  mAirtime = 0;
  _24 = 0.0f;
  mTop.setZero();
  _40.setZero();
  _58 = 0;
  _5c = 0;
  mHwgTimer = 0;
  _70 = 0;
  mBoostRampType = -1;
  mJumpPadType = -1;
  _84 = 0;
  mStartBoostCharge = 0.0f;
  mStick.y = 0.0f;
  mStick.x = 0.0f;
  _a4 = 0;
  _4c = _a8 = lbl_802A4100;
  _a6 = 0;
}

void KartState::resetOob() {
  mWipeState = -1;
  mWipeFrame = -1;
}

void KartState::updateWipe() {
  if (mWipeState == -1) {
    return;
  }
  mWipeFrame++;
  f32 ratio = (f32)mWipeFrame / (f32)lbl_1_data_3958[mWipeState];
  _98 = ratio;
  if (1.0f < ratio) {
    _98 = 1.0f;
  }
  if (mWipeFrame > lbl_1_data_3958[mWipeState]) {
    mWipeState = -1;
  }
}

void KartState::startWipe(int wipeState) {
  mWipeState = wipeState;
  mWipeFrame = 0;
}

void KartState::resetCollisionFlags() {
  field(0) &= 0xFE7F9C78;
  field(1) &= 0xFFFFEFFF;
  field(2) &= 0x3FBFEFFF;
  mStick.y = 0.0f;
  mStick.x = 0.0f;
}

void KartState::empty() {}

void KartState::resetGroundFlags() {
  field(1) &= 0xF7F7FDFF;
  field(2) &= 0xFFFFFBF7;
}

void KartState::setCollisionFlag() {
  field(4) |= 0x20;
}

void KartState::clearCollisionFlag() {
  field(4) &= ~0x20;
}

void KartState::applyStartBoost(s32 idx) {
  PlayerSub10_applyStartBoost(mProxy->kartMove(), lbl_1_data_3928[idx].count);
}

void KartState::calcStartBoost() {
  if (on(104)) {
    f32 delta = lbl_1_data_3918[0] - lbl_1_data_3918[1];
    delta *= mStartBoostCharge;
    mStartBoostCharge += lbl_1_data_3918[0] - delta;
  } else {
    mStartBoostCharge *= lbl_1_data_3918[2];
  }

  if (0.0f > mStartBoostCharge) {
    mStartBoostCharge = 0.0f;
  } else if (1.0f < mStartBoostCharge) {
    mStartBoostCharge = 1.0f;
  }

  (double)0;
  *(f32*)((u8*)mProxy->kartMove() + 0x224) = mStartBoostCharge * 10.0f;
}

void KartState::updateCollisions() {
  using namespace System;
  KartObjectProxy* proxy = mProxy;

  u32 flags0 = proxy->kartState()->field(0);
  s32 var_r28 = (flags0 >> 18) & 1;
  proxy->kartState()->field(0) = flags0 & 0xFFFBE39F;
  bool var_r27 = (flags0 & 0x60) != 0;

  if (mHwgTimer != 0) {
    mHwgTimer -= 1;
    _70 += 1;
    if (mHwgTimer == 0) {
      _70 = 0;
      field(3) &= ~0xA;
    }
  }

  s32 var_r25 = 0;
  mTop.z = 0.0f;
  mTop.y = 0.0f;
  mTop.x = 0.0f;
  s32 var_r24 = 0;

  KartCollide* collide = proxy->kartCollide();
  if (collide->someSoftWallTimer > 0) {
    if (collide->someNonSoftWallTimer > 0) {
      if ((collide->suspBottomHeightSoftWall / (f32)collide->someSoftWallTimer) -
              (collide->suspBottomHeightNonSoftWall / (f32)collide->someNonSoftWallTimer) <
          ((f32*)lbl_1_data_3918)[18]) {
        var_r24 = 1;
      } else {
        field(3) &= 0xFFFFFFEF;
      }
    } else {
      var_r24 = 1;
    }
  }

  s32 var_r23 = 0;
  EGG::Vector3f accum;
  accum.z = 0.0f;
  s32 var_r22 = 0;
  s32 var_r19 = 0;
  accum.y = 0.0f;
  accum.x = 0.0f;
  while (var_r19 < (s32)proxy->getWheelCount()) {
    KartWheelPhysics* wheel = proxy->kartWheel(var_r19)->getPhysics();
    const KartCollisionInfo* colInfo = &wheel->getKartCollisionInfo();
    if (wheel->hasFloorCollision()) {
      mTop.x += colInfo->floorNrm.x;
      mTop.y += colInfo->floorNrm.y;
      mTop.z += colInfo->floorNrm.z;
      if (var_r25 == 0) {
        var_r25 = (colInfo->flags >> 3) & 1;
      }
      var_r23++;
    }
    if (var_r24 != 0 && (colInfo->flags & 0x200)) {
      var_r22++;
      accum.x += colInfo->softWallNrm.x;
      accum.y += colInfo->softWallNrm.y;
      accum.z += colInfo->softWallNrm.z;
    }
    var_r19++;
  }

  if (var_r23 > 0) {
    proxy->kartState()->field(0) |= 0x800;
    if (var_r23 == (s32)proxy->getWheelCount()) {
      proxy->kartState()->field(0) |= 0x1000;
    }
  }

  HitboxGroup* hg = proxy->kartPhysics()->mpHitboxGroup;
  if (hg->getKartCollisionInfo().flags & 1) {
    proxy->kartState()->field(0) |= 0x400;
    mTop.x += hg->getKartCollisionInfo().floorNrm.x;
    mTop.y += hg->getKartCollisionInfo().floorNrm.y;
    mTop.z += hg->getKartCollisionInfo().floorNrm.z;
    if (var_r25 == 0) {
      var_r25 = (hg->getKartCollisionInfo().flags >> 3) & 1;
    }
    if (proxy->kartState()->field(1) & 0x400) {
      PlayerZipper_end(proxy->kartHalfPipe(), 1);
    }
  }

  s32 var_r24_2 = 0;
  if (var_r24 != 0 && (hg->getKartCollisionInfo().flags & 0x200)) {
    var_r24_2 = 1;
    var_r22++;
    accum.x += hg->getKartCollisionInfo().wallNrm.x;
    accum.y += hg->getKartCollisionInfo().wallNrm.y;
    accum.z += hg->getKartCollisionInfo().wallNrm.z;
  }

  s32 var_r4 = 0;
  if ((hg->getKartCollisionInfo().flags & 0x80) && (mHalfpipeInvisibilityTimer > 0)) {
    var_r4 = 1;
  }
  mHalfpipeInvisibilityTimer -= 1;
  if (mHalfpipeInvisibilityTimer < 0) {
    mHalfpipeInvisibilityTimer = 0;
  }
  _a4 -= 1;
  if (_a4 < 0) {
    _a4 = 0;
  }

  u32 f = hg->getKartCollisionInfo().flags;
  s32 var_r21 = 0;
  if ((f & 0x42) && var_r4 == 0) {
    if (f & 2) {
      proxy->kartState()->field(0) |= 0x40;
    }
    if (hg->getKartCollisionInfo().flags & 0x40) {
      proxy->kartState()->field(0) |= 0x20;
    }
    if (!var_r27) {
      proxy->kartState()->field(0) |= 0x4000;
      if ((fn_1_80DF4(proxy) == 0x1E) && (fn_1_80E0C(proxy) == 0)) {
        s32 var_r0 = 1;
        s32 var_r7 = 1;
        s32 var_r8 = 1;
        s32 var_r9 = 1;
        s32 var_r10 = 1;
        s32 var_r5;
        u32 f8 = proxy->kartState()->field(1);
        var_r5 = f8 & 0x102;
        if (var_r5 == 0) {
          var_r5 = proxy->kartState()->field(2) & 0x020C6000;
          if (var_r5 == 0) {
            var_r10 = 0;
          }
        }
        if (var_r10 == 0) {
          var_r5 = proxy->kartState()->field(0) & 0x10;
          if (var_r5 == 0) {
            var_r9 = 0;
          }
        }
        if (var_r9 == 0) {
          var_r5 = proxy->kartState()->field(4) & 0x80;
          if (var_r5 == 0) {
            var_r8 = 0;
          }
        }
        if (var_r8 == 0) {
          var_r5 = 0x80000019;
          if (!(f8 & 0x80000019)) {
            var_r7 = 0;
          }
        }
        if (var_r7 == 0) {
          var_r5 = proxy->kartState()->field(2);
          if (!(var_r5 & 0x0A008000)) {
            var_r0 = 0;
          }
        }
        if ((var_r0 == 0) && !(proxy->kartState()->field(4) & 8)) {
          fn_1_809A8(proxy, 1);
          u8 playerIdx = proxy->getPlayerIdx();
          RaceConfig* rc = RaceConfig::spInstance;
          RaceManager* rm = RaceManager::spInstance;
          s32 gameMode = rc->mRaceScenario.mSettings.mGameMode;
          if (gameMode == 3) {
            s32 battleType = rc->mRaceScenario.mSettings.mBattleType;
            if (battleType == 0) {
              ((void (*)(void*, s32))(*(void***)rm->raceMode)[0x38 / 4])(rm->raceMode, playerIdx);
            } else if (battleType == 1) {
              ((void (*)(void*, s32))(*(void***)rm->raceMode)[0x34 / 4])(rm->raceMode, playerIdx);
            }
          } else if (gameMode == 9 || gameMode == 10) {
            s32 battleType = rc->mRaceScenario.mSettings.mBattleType;
            if (battleType == 0) {
              ((void (*)(void*, s32))(*(void***)rm->raceMode)[0x38 / 4])(rm->raceMode, playerIdx);
            } else if (battleType == 1) {
              ((void (*)(void*, s32))(*(void***)rm->raceMode)[0x34 / 4])(rm->raceMode, playerIdx);
            }
          }
          void* r4_6 = proxy->kartSettings()->gpStats;
          if (r4_6 != NULL) {
            *(s32*)((u8*)r4_6 + 0x10) += 1;
          }
        }
      }
    }
    _a4 = 2;
    _a8.x = hg->getKartCollisionInfo().wallNrm.x;
    _a8.y = hg->getKartCollisionInfo().wallNrm.y;
    _a8.z = hg->getKartCollisionInfo().wallNrm.z;
    if (field(3) & 0x20) {
      _a8.x = _34.x;
      _a8.y = _34.y;
      _a8.z = _34.z;
    }
    if (!(*(u32*)((u8*)lbl_1_bss_4218 + 0x28) & 0x20) && (mHwgTimer == 0) &&
        !(proxy->kartCollide()->surfaceFlags & 0x2000) &&
        (hg->getKartCollisionInfo().movement.y > 1.0f)) {
      EGG::Vector3f sp20 = hg->getKartCollisionInfo().movement;
      sp20.normalise();
      if ((((sp20.z * RKSystem_ey.z) + ((sp20.x * RKSystem_ey.x) + (sp20.y * RKSystem_ey.y))) > 0.8f) &&
          (((RKSystem_ey.z * hg->getKartCollisionInfo().wallNrm.z) +
            ((RKSystem_ey.x * hg->getKartCollisionInfo().wallNrm.x) + (RKSystem_ey.y * hg->getKartCollisionInfo().wallNrm.y))) >
           0.85f) &&
          ((EGG::Vector3f::dot(zeroY(sp20), zeroY(hg->getKartCollisionInfo().wallNrm)) < 0.0f) ||
           (proxy->kartCollide()->_68 == 1.0f))) {
        hg->getKartCollisionInfo().wallNrm.y = 0.0f;
        hg->getKartCollisionInfo().wallNrm.normalise();
        _a8.x = hg->getKartCollisionInfo().wallNrm.x;
        _a8.y = hg->getKartCollisionInfo().wallNrm.y;
        _a8.z = hg->getKartCollisionInfo().wallNrm.z;
        f32 temp_f5 = hg->getKartCollisionInfo().wallNrm.x;
        f32 temp_f4 = hg->getKartCollisionInfo().wallNrm.z;
        accum.x = temp_f5;
        accum.z = temp_f4;
        accum.y = 0.0f;
        if (EGG::Mathf::sqrt((temp_f4 * temp_f4) + ((temp_f5 * temp_f5) + (0.0f * 0.0f))) < 0.05f) {
          accum.x = sp20.x;
          accum.z = sp20.z;
          accum.y = 0.0f;
        }
        var_r21 = 1;
      }
    }
  }

  if ((hg->getKartCollisionInfo().flags & 4) && (field(1) & 0x200) &&
      !(proxy->kartCollide()->surfaceFlags & 0x10000)) {
    proxy->kartState()->field(1) |= 0x1000;
  }

  if ((var_r22 > 0) || (var_r21 != 0)) {
    field(3) |= 2;
    _34.x = accum.x;
    _34.y = accum.y;
    _34.z = accum.z;
    _34.normalise();
    s32 var_r27_2 = 0;
    if ((var_r22 > 0) && (PlayerPointers_isBike(proxy) == 1)) {
      var_r27_2 = 1;
    }
    if ((var_r22 > 0) && !(field(0) & 0x80000)) {
      field(3) |= 0x10;
    }
    if (var_r21 != 0) {
      field(3) |= 0x20;
    }
    if ((var_r24_2 != 0) || (var_r21 != 0) || (var_r27_2 != 0)) {
      field(3) |= 8;
      mHwgTimer = ((s32*)lbl_1_data_3918)[17];
      if (var_r21 != 0) {
        mHwgTimer = ((s32*)lbl_1_data_3918)[17] * 2;
      }
    }
  }

  field(0) &= 0xFFFF7FFF;
  field(1) &= 0xFFFFFFFB;
  _a6 -= 1;
  if (_a6 < 0) {
    _a6 = 0;
  }

  if ((var_r23 > 0) || (hg->getKartCollisionInfo().flags & 1)) {
    mTop.normalise();
    u32 temp_r4_7 = field(3) & 0xFFFFFFBF;
    _4c.x = mTop.x;
    _4c.y = mTop.y;
    _4c.z = mTop.z;
    field(0) |= 0x40000;
    field(3) = temp_r4_7;
    if (!(proxy->kartState()->field(1) & 1)) {
      field(3) = temp_r4_7 & ~0x880;
    }
    if (Raceinfo_isAtLeastStage(RaceManager::spInstance, 2) != 0) {
      if (!(proxy->kartCollide()->surfaceFlags & 0x20) &&
          (proxy->kartCollide()->surfaceFlags & 0x40)) {
        fn_1_80068(proxy, 8, 1, 1.0f);
      }
      if (!(proxy->kartCollide()->surfaceFlags & 0x80) &&
          (proxy->kartCollide()->surfaceFlags & 0x100)) {
        fn_1_80068(proxy, 4, 1, 1.0f);
      }
    }
    if ((proxy->kartState()->field(1) & 0x400) && !(proxy->kartState()->field(2) & 0x800000)) {
      PlayerZipper_end(proxy->kartHalfPipe(), 1);
      if (!(proxy->kartState()->field(0) & 0x10)) {
        proxy->kartState()->field(2) |= 0x80000000;
      }
    }
    if (var_r25 != 0) {
      _a6 = 3;
    }
    if ((s16)_a6 > 0) {
      field(1) |= 0x40000000;
    } else {
      field(1) &= 0xBFFFFFFF;
    }
    if (!(proxy->kartState()->field(0) & 0x40000000)) {
      field(1) &= 0xFFFFF7FF;
    }
    if (var_r28 == 0) {
      proxy->kartState()->field(0) |= 0x200;
      EGG::Vector3f* speed = playerPointers_getSpeed(proxy);
      f32 temp_f31 = (mTop.z * speed->z) + ((mTop.x * speed->x) + (mTop.y * speed->y));
      if (temp_f31 < -22.0f) {
        proxy->kartState()->field(2) |= 0x40000000;
        f32 var_f1 = fabsf(temp_f31 * ((f32*)lbl_1_data_3918)[3]);
        if (1.0f < var_f1) {
          var_f1 = 1.0f;
        }
        fn_1_80068(proxy, 2, 1, var_f1);
      }
      if (!(proxy->kartState()->field(0) & 0x10)) {
        if (temp_f31 < -7.0f) {
          proxy->kartState()->field(2) |= 0x80000000;
        }
        fn_1_354D84(fn_1_803EC(proxy));
        if (mAirtime > 0x3C) {
          fn_1_80068(proxy, 2, 1, 1.0f);
        }
      }
    }
    if ((field(1) & 0x40) && (*(s16*)((u8*)proxy->kartJump() + 0x38) <= 0)) {
      PlayerSub10_endTrick(proxy->kartMove());
      proxy->kartDynamics()->_forceUpright = 1;
      PlayerTrick_end(*(void**)((u8*)proxy->kartMove() + 0x258));
    }
    mAirtime = 0;
  } else {
    if (var_r28 != 0) {
      proxy->kartState()->field(0) |= 0x800000;
    }
    u32 temp_r0_7 = mAirtime + 1;
    mAirtime = temp_r0_7;
    if (temp_r0_7 > 0x14) {
      proxy->kartState()->field(0) |= 0x8000;
      if (mAirtime == 0x14) {
        fn_1_80C90(proxy, 5, 0, 1);
      }
      f32 temp_f2 = playerPointers_getSpeed(proxy)->y;
      if ((temp_f2 - _7c) < 0.0f) {
        field(1) |= 4;
      }
      _7c = temp_f2;
    }
  }

  proxy->kartWheelPhysics(0);
  proxy->getPos();
}

KartState::~KartState() {}
}